import { Component, createRef } from "react";
import PropTypes from "prop-types";

// ─── DATA ────────────────────────────────────────────────────────────────────

const AUTHORS = {
  1: {
    id: 1,
    name: "Frank Herbert",
    photo: "https://upload.wikimedia.org/wikipedia/en/thumb/8/8e/Dune_Cover_ISBN_0441172717.jpg/220px-Dune_Cover_ISBN_0441172717.jpg",
    bio: "Frank Herbert was an American science-fiction author best known for the Dune series. His works explore ecology, religion, politics, and human consciousness with extraordinary depth.",
    topBooks: ["Dune", "Dune Messiah", "Children of Dune"],
  },
  2: {
    id: 2,
    name: "J.R.R. Tolkien",
    photo: "https://upload.wikimedia.org/wikipedia/en/thumb/8/8e/Dune_Cover_ISBN_0441172717.jpg/220px-Dune_Cover_ISBN_0441172717.jpg",
    bio: "John Ronald Reuel Tolkien was an English author and philologist, best known as the author of The Hobbit and The Lord of the Rings. He is considered the father of high fantasy.",
    topBooks: ["The Fellowship of the Ring", "The Two Towers", "The Return of the King"],
  },
  3: {
    id: 3,
    name: "George Orwell",
    photo: "https://upload.wikimedia.org/wikipedia/en/thumb/8/8e/Dune_Cover_ISBN_0441172717.jpg/220px-Dune_Cover_ISBN_0441172717.jpg",
    bio: "Eric Arthur Blair, known by his pen name George Orwell, was an English novelist and essayist. His work is characterised by lucid prose, social criticism, and opposition to totalitarianism.",
    topBooks: ["1984", "Animal Farm", "Homage to Catalonia"],
  },
  4: {
    id: 4,
    name: "Isaac Asimov",
    photo: "https://upload.wikimedia.org/wikipedia/en/thumb/8/8e/Dune_Cover_ISBN_0441172717.jpg/220px-Dune_Cover_ISBN_0441172717.jpg",
    bio: "Isaac Asimov was an American writer and professor of biochemistry at Boston University. He was one of the most prolific writers of all time, having written or edited more than 500 books.",
    topBooks: ["Foundation", "I, Robot", "The Caves of Steel"],
  },
};

const BOOKS = [
  { id: 1, title: "Dune", authorId: 1, genre: "Sci-Fi", rating: 4.8, year: 1965, cover: "🏜️", description: "A desert planet hides the universe's most precious resource." },
  { id: 2, title: "The Fellowship of the Ring", authorId: 2, genre: "Fantasy", rating: 4.9, year: 1954, cover: "💍", description: "A young hobbit inherits a ring of immense and terrible power." },
  { id: 3, title: "1984", authorId: 3, genre: "Dystopia", rating: 4.7, year: 1949, cover: "👁️", description: "Big Brother is always watching in a chilling totalitarian world." },
  { id: 4, title: "Foundation", authorId: 4, genre: "Sci-Fi", rating: 4.6, year: 1951, cover: "🔭", description: "A mathematician predicts the fall of a galactic empire." },
  { id: 5, title: "Dune Messiah", authorId: 1, genre: "Sci-Fi", rating: 4.5, year: 1969, cover: "🌌", description: "The messiah grapples with the consequences of his holy war." },
  { id: 6, title: "Animal Farm", authorId: 3, genre: "Satire", rating: 4.5, year: 1945, cover: "🐷", description: "All animals are equal, but some are more equal than others." },
];

// ─── PROPTYPE SHAPES ─────────────────────────────────────────────────────────

const bookShape = PropTypes.shape({
  id: PropTypes.number.isRequired,
  title: PropTypes.string.isRequired,
  authorId: PropTypes.number.isRequired,
  genre: PropTypes.string.isRequired,
  rating: PropTypes.number.isRequired,
  year: PropTypes.number.isRequired,
  cover: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
});

// ─── STAR RATING (Functional) ─────────────────────────────────────────────────

function StarRating({ rating }) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  return (
    <span className="bv-stars" aria-label={`${rating} out of 5`}>
      {Array.from({ length: 5 }, (_, i) => (
        <span key={i} className={i < full ? "star full" : i === full && half ? "star half" : "star empty"}>
          {i < full ? "★" : i === full && half ? "⯨" : "☆"}
        </span>
      ))}
      <span className="bv-rating-num">{rating}</span>
    </span>
  );
}

StarRating.propTypes = {
  rating: PropTypes.number.isRequired,
};

// ─── AUTHOR INFO (Class Component with Lifecycle) ─────────────────────────────

class AuthorInfo extends Component {
  constructor(props) {
    super(props);
    this.state = { loaded: false, activeTab: "bio" };
  }

  componentDidMount() {
    console.log(`[AuthorInfo] componentDidMount — loading author data for: ${this.props.author.name}`);
    // Simulate async data loading
    setTimeout(() => {
      console.log(`[AuthorInfo] Author data fully loaded for: ${this.props.author.name}`);
      this.setState({ loaded: true });
    }, 300);
  }

  componentDidUpdate(prevProps) {
    if (prevProps.author.id !== this.props.author.id) {
      console.log(`[AuthorInfo] componentDidUpdate — author changed to: ${this.props.author.name}`);
      this.setState({ loaded: false, activeTab: "bio" });
      setTimeout(() => this.setState({ loaded: true }), 300);
    }
  }

  componentWillUnmount() {
    console.log(`[AuthorInfo] componentWillUnmount — cleaning up for: ${this.props.author.name}`);
  }

  render() {
    const { author, onClose } = this.props;
    const { loaded, activeTab } = this.state;

    return (
      <div className={`bv-author-panel ${loaded ? "bv-author-panel--loaded" : ""}`}>
        <button className="bv-author-close" onClick={onClose} aria-label="Close author panel">✕</button>

        <div className="bv-author-header">
          <div className="bv-author-avatar">{author.name.charAt(0)}</div>
          <div>
            <h2 className="bv-author-name">{author.name}</h2>
            <span className="bv-author-badge">Author</span>
          </div>
        </div>

        <div className="bv-author-tabs">
          {["bio", "books"].map((tab) => (
            <button
              key={tab}
              className={`bv-tab ${activeTab === tab ? "bv-tab--active" : ""}`}
              onClick={() => this.setState({ activeTab: tab })}
            >
              {tab === "bio" ? "📖 Biography" : "📚 Top Books"}
            </button>
          ))}
        </div>

        <div className="bv-author-content">
          {activeTab === "bio" ? (
            <p className="bv-author-bio">{author.bio}</p>
          ) : (
            <ol className="bv-author-books">
              {author.topBooks.map((book, i) => (
                <li key={i} className="bv-author-book-item">
                  <span className="bv-book-rank">#{i + 1}</span>
                  <span className="bv-book-name">{book}</span>
                </li>
              ))}
            </ol>
          )}
        </div>

        {!loaded && <div className="bv-author-loading">Loading author data…</div>}
      </div>
    );
  }
}

AuthorInfo.propTypes = {
  author: PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    bio: PropTypes.string.isRequired,
    topBooks: PropTypes.arrayOf(PropTypes.string).isRequired,
  }).isRequired,
  onClose: PropTypes.func.isRequired,
};

// ─── BOOK CARD (Class Component with PropTypes) ───────────────────────────────

class BookCard extends Component {
  constructor(props) {
    super(props);
    this.state = { hovered: false };
  }

  componentDidMount() {
    console.log(`[BookCard] componentDidMount — rendered: "${this.props.book.title}"`);
  }

  render() {
    const { book, onSelect, isSelected } = this.props;
    const { hovered } = this.state;

    return (
      <div
        className={`bv-book-card ${isSelected ? "bv-book-card--selected" : ""} ${hovered ? "bv-book-card--hovered" : ""}`}
        onClick={() => onSelect(book)}
        onMouseEnter={() => this.setState({ hovered: true })}
        onMouseLeave={() => this.setState({ hovered: false })}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && onSelect(book)}
        aria-pressed={isSelected}
      >
        <div className="bv-book-cover">{book.cover}</div>
        <div className="bv-book-body">
          <span className="bv-book-genre">{book.genre}</span>
          <h3 className="bv-book-title">{book.title}</h3>
          <p className="bv-book-desc">{book.description}</p>
          <div className="bv-book-footer">
            <StarRating rating={book.rating} />
            <span className="bv-book-year">{book.year}</span>
          </div>
          <button
            className="bv-book-author-btn"
            onClick={(e) => { e.stopPropagation(); onSelect(book); }}
          >
            View Author →
          </button>
        </div>
        {isSelected && <div className="bv-book-selected-badge">✓ Selected</div>}
      </div>
    );
  }
}

BookCard.propTypes = {
  book: bookShape.isRequired,
  onSelect: PropTypes.func.isRequired,
  isSelected: PropTypes.bool,
};

BookCard.defaultProps = {
  isSelected: false,
};

// ─── BOOK LIST (Class Component) ──────────────────────────────────────────────

class BookList extends Component {
  componentDidMount() {
    console.log(`[BookList] componentDidMount — rendering ${this.props.books.length} books`);
  }

  componentDidUpdate(prevProps) {
    if (prevProps.books.length !== this.props.books.length) {
      console.log(`[BookList] componentDidUpdate — book count changed: ${this.props.books.length}`);
    }
  }

  render() {
    const { books, onSelectBook, selectedBookId } = this.props;

    if (books.length === 0) {
      return (
        <div className="bv-empty">
          <span className="bv-empty-icon">🔍</span>
          <p>No books match your search.</p>
        </div>
      );
    }

    return (
      <div className="row g-4">
        {books.map((book) => (
          <div key={book.id} className="col-12 col-sm-6 col-lg-4">
            <BookCard
              book={book}
              onSelect={onSelectBook}
              isSelected={selectedBookId === book.id}
            />
          </div>
        ))}
      </div>
    );
  }
}

BookList.propTypes = {
  books: PropTypes.arrayOf(bookShape).isRequired,
  onSelectBook: PropTypes.func.isRequired,
  selectedBookId: PropTypes.number,
};

BookList.defaultProps = {
  selectedBookId: null,
};

// ─── SEARCH BAR (Uncontrolled Component with Ref) ────────────────────────────

class SearchBar extends Component {
  constructor(props) {
    super(props);
    // Ref for uncontrolled component focus
    this.searchInputRef = createRef();
  }

  componentDidMount() {
    console.log("[SearchBar] componentDidMount — search input ref attached");
    // Auto-focus on mount
    this.searchInputRef.current?.focus();
  }

  handleFocusClick = () => {
    this.searchInputRef.current?.focus();
    console.log("[SearchBar] Focus button clicked — focusing input via ref");
  };

  render() {
    const { onSearch, query } = this.props;

    return (
      <div className="bv-search-bar">
        <div className="bv-search-inner">
          <span className="bv-search-icon">🔍</span>
          <input
            ref={this.searchInputRef}           // ← Uncontrolled ref
            type="text"
            className="bv-search-input"
            placeholder="Search books, authors, genres…"
            defaultValue={query}
            onChange={(e) => onSearch(e.target.value)}
            aria-label="Search books"
          />
          {query && (
            <button
              className="bv-search-clear"
              onClick={() => { onSearch(""); this.searchInputRef.current.value = ""; }}
              aria-label="Clear search"
            >✕</button>
          )}
        </div>
        <button
          className="bv-focus-btn"
          onClick={this.handleFocusClick}
          title="Click to focus search (demonstrates Ref usage)"
        >
          🎯 Focus
        </button>
      </div>
    );
  }
}

SearchBar.propTypes = {
  onSearch: PropTypes.func.isRequired,
  query: PropTypes.string.isRequired,
};

// ─── ROOT APP (Class Component — Composition Root) ───────────────────────────

class BookVerse extends Component {
  constructor(props) {
    super(props);
    this.state = {
      query: "",
      selectedBook: null,
      selectedAuthor: null,
    };
  }

  componentDidMount() {
    console.log("[BookVerse] componentDidMount — App ready. Books loaded:", BOOKS.length);
  }

  handleSearch = (query) => {
    this.setState({ query });
    console.log(`[BookVerse] Search query: "${query}"`);
  };

  handleSelectBook = (book) => {
    const author = AUTHORS[book.authorId];
    console.log(`[BookVerse] Book selected: "${book.title}" by ${author.name}`);
    this.setState({ selectedBook: book, selectedAuthor: author });
  };

  handleCloseAuthor = () => {
    console.log("[BookVerse] Author panel closed");
    this.setState({ selectedAuthor: null, selectedBook: null });
  };

  get filteredBooks() {
    const { query } = this.state;
    if (!query.trim()) return BOOKS;
    const q = query.toLowerCase();
    return BOOKS.filter(
      (b) =>
        b.title.toLowerCase().includes(q) ||
        b.genre.toLowerCase().includes(q) ||
        AUTHORS[b.authorId].name.toLowerCase().includes(q)
    );
  }

  render() {
    const { query, selectedBook, selectedAuthor } = this.state;
    const filtered = this.filteredBooks;

    return (
      <>
        <style>{CSS}</style>
        <div className="bv-root">
          {/* Header */}
          <header className="bv-header">
            <div className="bv-header-inner container-fluid">
              <div className="bv-logo">
                <span className="bv-logo-icon">📚</span>
                <span className="bv-logo-text">BookVerse</span>
              </div>
              <p className="bv-tagline">Discover worlds between pages</p>
            </div>
          </header>

          {/* Main */}
          <main className="container-fluid bv-main">
            <div className="bv-layout">
              {/* Left: Book List + Search */}
              <section className="bv-section-books">
                <div className="bv-section-top">
                  <h2 className="bv-section-title">
                    Library <span className="bv-count">{filtered.length}</span>
                  </h2>
                  {/* SearchBar uses Ref (Uncontrolled Component) */}
                  <SearchBar onSearch={this.handleSearch} query={query} />
                </div>

                {/* BookList composes BookCard components */}
                <BookList
                  books={filtered}
                  onSelectBook={this.handleSelectBook}
                  selectedBookId={selectedBook?.id ?? null}
                />
              </section>

              {/* Right: Author Panel */}
              <aside className={`bv-section-author ${selectedAuthor ? "bv-section-author--visible" : ""}`}>
                {selectedAuthor ? (
                  /* AuthorInfo is a Class Component with lifecycle methods */
                  <AuthorInfo
                    key={selectedAuthor.id}
                    author={selectedAuthor}
                    onClose={this.handleCloseAuthor}
                  />
                ) : (
                  <div className="bv-author-placeholder">
                    <span className="bv-placeholder-icon">👤</span>
                    <p>Select a book to view its author details</p>
                  </div>
                )}
              </aside>
            </div>
          </main>

          {/* Footer */}
          <footer className="bv-footer">
            <p>BookVerse · Day 11 · Class Components · PropTypes · Refs · Lifecycle · Composition</p>
          </footer>
        </div>
      </>
    );
  }
}

// ─── CSS ──────────────────────────────────────────────────────────────────────

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:wght@300;400;500&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --ink:       #1a1208;
  --parchment: #faf6ef;
  --cream:     #f3ece0;
  --amber:     #c8813a;
  --amber-dk:  #9e5e20;
  --amber-lt:  #f5d9b0;
  --teal:      #2a6b6e;
  --teal-lt:   #d4ecec;
  --red:       #b84040;
  --shadow:    0 4px 24px rgba(26,18,8,.10);
  --shadow-lg: 0 12px 48px rgba(26,18,8,.18);
  --radius:    14px;
  --transition: .22s cubic-bezier(.4,0,.2,1);
}

body { background: var(--parchment); font-family: 'DM Sans', sans-serif; color: var(--ink); }

/* ── Header ── */
.bv-root { min-height: 100vh; display: flex; flex-direction: column; }
.bv-header {
  background: var(--ink);
  padding: 1.5rem 2rem;
  position: sticky; top: 0; z-index: 100;
  border-bottom: 3px solid var(--amber);
}
.bv-header-inner { display: flex; align-items: center; gap: 2rem; flex-wrap: wrap; }
.bv-logo { display: flex; align-items: center; gap: .6rem; }
.bv-logo-icon { font-size: 1.8rem; }
.bv-logo-text {
  font-family: 'Playfair Display', serif;
  font-size: 1.9rem; font-weight: 700;
  color: var(--amber-lt);
  letter-spacing: -.5px;
}
.bv-tagline { color: #9e8e78; font-size: .85rem; font-style: italic; }

/* ── Main layout ── */
.bv-main { padding: 2rem; flex: 1; }
.bv-layout {
  display: grid;
  grid-template-columns: 1fr;
  gap: 2rem;
}
@media (min-width: 992px) {
  .bv-layout { grid-template-columns: 1fr 360px; }
}

/* ── Section header ── */
.bv-section-top { margin-bottom: 1.5rem; display: flex; flex-direction: column; gap: 1rem; }
@media(min-width:576px){ .bv-section-top{ flex-direction:row; align-items:center; justify-content:space-between; } }
.bv-section-title {
  font-family: 'Playfair Display', serif;
  font-size: 1.6rem; font-weight: 700; color: var(--ink);
}
.bv-count {
  display: inline-flex; align-items: center; justify-content: center;
  background: var(--amber); color: white;
  font-family: 'DM Sans', sans-serif; font-size: .8rem; font-weight: 500;
  width: 28px; height: 28px; border-radius: 50%;
  vertical-align: middle; margin-left: .4rem;
}

/* ── Search Bar (Ref demo) ── */
.bv-search-bar { display: flex; gap: .5rem; align-items: center; }
.bv-search-inner {
  display: flex; align-items: center; gap: .5rem;
  background: white; border: 2px solid var(--cream);
  border-radius: 50px; padding: .5rem 1rem;
  transition: border-color var(--transition), box-shadow var(--transition);
  flex: 1;
}
.bv-search-inner:focus-within { border-color: var(--amber); box-shadow: 0 0 0 3px var(--amber-lt); }
.bv-search-icon { font-size: 1rem; opacity: .5; }
.bv-search-input {
  border: none; outline: none; background: transparent;
  font-family: 'DM Sans', sans-serif; font-size: .95rem; color: var(--ink);
  width: 100%;
}
.bv-search-clear {
  background: none; border: none; cursor: pointer; color: #aaa; font-size: 1rem;
  padding: 0; line-height: 1; transition: color var(--transition);
}
.bv-search-clear:hover { color: var(--red); }
.bv-focus-btn {
  background: var(--teal); color: white;
  border: none; border-radius: 50px; padding: .5rem 1rem;
  font-family: 'DM Sans', sans-serif; font-size: .82rem; font-weight: 500;
  cursor: pointer; white-space: nowrap;
  transition: background var(--transition), transform var(--transition);
}
.bv-focus-btn:hover { background: var(--ink); transform: scale(1.04); }

/* ── Book Card ── */
.bv-book-card {
  background: white; border-radius: var(--radius);
  border: 2px solid var(--cream);
  overflow: hidden; cursor: pointer; height: 100%;
  display: flex; flex-direction: column;
  transition: transform var(--transition), box-shadow var(--transition), border-color var(--transition);
  position: relative;
}
.bv-book-card--hovered, .bv-book-card:focus-visible {
  transform: translateY(-5px);
  box-shadow: var(--shadow-lg);
  border-color: var(--amber-lt);
  outline: none;
}
.bv-book-card--selected {
  border-color: var(--amber);
  box-shadow: 0 0 0 3px var(--amber-lt), var(--shadow);
}
.bv-book-cover {
  background: linear-gradient(135deg, var(--ink) 0%, #3d2b10 100%);
  display: flex; align-items: center; justify-content: center;
  font-size: 3.5rem; padding: 1.8rem;
  min-height: 130px;
}
.bv-book-body { padding: 1.2rem; display: flex; flex-direction: column; gap: .5rem; flex: 1; }
.bv-book-genre {
  font-size: .72rem; font-weight: 500; text-transform: uppercase; letter-spacing: 1px;
  color: var(--teal); background: var(--teal-lt); border-radius: 4px;
  padding: 2px 8px; width: fit-content;
}
.bv-book-title {
  font-family: 'Playfair Display', serif;
  font-size: 1.1rem; font-weight: 700; color: var(--ink); line-height: 1.3;
}
.bv-book-desc { font-size: .83rem; color: #7a6a55; line-height: 1.5; flex: 1; }
.bv-book-footer { display: flex; align-items: center; justify-content: space-between; margin-top: .3rem; }
.bv-book-year { font-size: .78rem; color: #aaa; }
.bv-book-author-btn {
  margin-top: .6rem; width: 100%;
  background: var(--ink); color: var(--amber-lt);
  border: none; border-radius: 8px; padding: .5rem;
  font-family: 'DM Sans', sans-serif; font-size: .85rem; font-weight: 500;
  cursor: pointer; transition: background var(--transition);
}
.bv-book-author-btn:hover { background: var(--amber); color: white; }
.bv-book-selected-badge {
  position: absolute; top: 10px; right: 10px;
  background: var(--amber); color: white;
  border-radius: 50%; width: 26px; height: 26px;
  display: flex; align-items: center; justify-content: center;
  font-size: .75rem; font-weight: 700;
}

/* ── Stars ── */
.bv-stars { display: inline-flex; align-items: center; gap: 1px; }
.star { font-size: .9rem; }
.star.full { color: #f5a623; }
.star.half { color: #f5a623; }
.star.empty { color: #ddd; }
.bv-rating-num { font-size: .78rem; color: #999; margin-left: 4px; }

/* ── Empty state ── */
.bv-empty {
  text-align: center; padding: 4rem 2rem; color: #aaa;
  display: flex; flex-direction: column; align-items: center; gap: 1rem;
}
.bv-empty-icon { font-size: 3rem; }

/* ── Author panel ── */
.bv-section-author {
  transition: opacity var(--transition);
}
.bv-author-placeholder {
  background: white; border-radius: var(--radius);
  border: 2px dashed var(--cream); padding: 3rem 2rem;
  text-align: center; color: #bbb;
  display: flex; flex-direction: column; align-items: center; gap: 1rem;
  height: 100%; justify-content: center;
}
.bv-placeholder-icon { font-size: 3rem; opacity: .4; }
.bv-author-panel {
  background: white; border-radius: var(--radius);
  border: 2px solid var(--cream);
  padding: 1.8rem; position: relative;
  opacity: 0; transform: translateY(12px);
  transition: opacity .35s ease, transform .35s ease;
  box-shadow: var(--shadow);
}
.bv-author-panel--loaded { opacity: 1; transform: translateY(0); }
.bv-author-close {
  position: absolute; top: 1rem; right: 1rem;
  background: var(--cream); border: none; border-radius: 50%;
  width: 30px; height: 30px; cursor: pointer; font-size: .9rem;
  display: flex; align-items: center; justify-content: center;
  transition: background var(--transition);
}
.bv-author-close:hover { background: #f0d0c0; }
.bv-author-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.2rem; }
.bv-author-avatar {
  width: 56px; height: 56px; border-radius: 50%;
  background: linear-gradient(135deg, var(--amber), var(--ink));
  display: flex; align-items: center; justify-content: center;
  font-family: 'Playfair Display', serif;
  font-size: 1.5rem; font-weight: 700; color: white;
  flex-shrink: 0;
}
.bv-author-name {
  font-family: 'Playfair Display', serif;
  font-size: 1.25rem; font-weight: 700; color: var(--ink);
}
.bv-author-badge {
  font-size: .72rem; font-weight: 500; text-transform: uppercase;
  letter-spacing: 1px; color: var(--amber);
  border: 1px solid var(--amber-lt); border-radius: 4px; padding: 1px 7px;
}
.bv-author-tabs { display: flex; gap: .4rem; margin-bottom: 1rem; border-bottom: 2px solid var(--cream); padding-bottom: .6rem; }
.bv-tab {
  background: none; border: none; cursor: pointer;
  font-family: 'DM Sans', sans-serif; font-size: .85rem; color: #999;
  padding: .3rem .7rem; border-radius: 6px;
  transition: background var(--transition), color var(--transition);
}
.bv-tab:hover { background: var(--cream); color: var(--ink); }
.bv-tab--active { background: var(--amber-lt); color: var(--amber-dk); font-weight: 500; }
.bv-author-bio {
  font-size: .9rem; color: #5a4a35; line-height: 1.7;
}
.bv-author-books { list-style: none; display: flex; flex-direction: column; gap: .6rem; padding: 0; }
.bv-author-book-item {
  display: flex; align-items: center; gap: .8rem;
  padding: .6rem; background: var(--parchment); border-radius: 8px;
}
.bv-book-rank {
  font-size: .75rem; font-weight: 700; color: var(--amber);
  background: var(--amber-lt); padding: 2px 7px; border-radius: 4px;
  flex-shrink: 0;
}
.bv-book-name { font-size: .88rem; font-weight: 500; }
.bv-author-loading {
  text-align: center; font-size: .8rem; color: #bbb;
  font-style: italic; margin-top: 1rem;
}

/* ── Footer ── */
.bv-footer {
  background: var(--ink); color: #6a5a45;
  text-align: center; padding: 1rem; font-size: .78rem;
  border-top: 2px solid #2a2010;
}
`;

export default BookVerse;
