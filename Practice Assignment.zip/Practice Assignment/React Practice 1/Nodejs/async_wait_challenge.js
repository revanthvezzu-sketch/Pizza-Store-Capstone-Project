const fs = require("fs").promises;

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function copyFile() {
    try {
        console.log("Reading file...");

        const data = await fs.readFile("input.txt", "utf8");

        await delay(1000);

        console.log("Writing file...");

        await fs.writeFile("output.txt", data);

        console.log("File copied successfully!");
    } catch (err) {
        console.error("Error:", err.message);
    }
}

copyFile();