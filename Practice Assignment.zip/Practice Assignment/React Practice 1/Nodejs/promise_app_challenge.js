const fs = require("fs").promises;

fs.readFile("input.txt", "utf8")
    .then((data) => {
        return fs.writeFile("output.txt", data);
    })
    .then(() => {
        console.log("I am Revanth.");
    })
    .catch((err) => {
        console.error("Error:", err);
    });