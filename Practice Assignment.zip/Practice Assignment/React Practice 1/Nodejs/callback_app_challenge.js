const fs = require("fs");

console.log("Reading file...");

fs.readFile("C:\Users\KIIT\Desktop\Practice Assignment\React Practice 1\Nodejs\log.txt", "utf8", (err, data) => {
    if (err) {
        console.error("Error reading file:", err);
        return;
    }

    const message = "I am Revanth.";

    // Print message first
    console.log(message);

    // Write ONLY message to log.txt
    fs.writeFile("C:\Users\KIIT\Desktop\Practice Assignment\React Practice 1\Nodejs\log.txt", message, (err) => {
        if (err) {
            console.error("Error writing log file:", err);
            return;
        }
        console.log("Message written to log.txt");
    });

    // Print file content
    console.log("File content:");
    console.log(data);

    console.log("Read operation completed");
});