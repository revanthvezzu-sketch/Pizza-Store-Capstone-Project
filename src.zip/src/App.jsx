import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import LoginPage     from "./pages/Login";
import Menu          from "./pages/Menu";
import OrderPage     from "./pages/Order";
import AdminDashboard from "./pages/AdminDashboard";
import AdminMenu     from "./pages/AdminMenu";
import BillsPage     from "./pages/Bills";
import AdminBillsPage from "./pages/AdminBills";
import RevenuePage   from "./pages/RevenuePage";
import Toast         from "./components/Toast";

function GlobalStyles() {
  useEffect(() => { 
    const style = document.createElement("style");
    style.id = "pizza-global";
    style.innerHTML = `
      *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
      html { scroll-behavior:smooth; }
body { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif; background:#faf9f7; color:#1f1b17; min-height:100vh; overflow-x:hidden; }
      ::-webkit-scrollbar { width:5px; }
      ::-webkit-scrollbar-track { background:#f0efec; }
      ::-webkit-scrollbar-thumb { background:#f5a623; border-radius:99px; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(22px)} to{opacity:1;transform:translateY(0)} }
      @keyframes fadeIn { from{opacity:0} to{opacity:1} }
      @keyframes spin { to{transform:rotate(360deg)} }
      @keyframes slideIn { from{transform:translateX(100%)} to{transform:translateX(0)} }
      .fade-up { animation: fadeUp 0.45s ease both; }
    `;
    if (!document.getElementById("pizza-global")) document.head.appendChild(style);
    return () => { const el = document.getElementById("pizza-global"); if (el) el.remove(); };
  }, []);
  return null;
}

const isAuthenticated = () => !!localStorage.getItem("token");
const isAdmin = () => localStorage.getItem("role") === "Admin";
const isUser  = () => localStorage.getItem("role") === "User";

function PrivateRoute({ children }) {
  return isAuthenticated() ? children : <Navigate to="/login" />;
}
function AdminRoute({ children }) {
  return isAuthenticated() && isAdmin() ? children : <Navigate to="/login" />;
}
function UserRoute({ children }) {
  // Admins cannot access user pages
  if (!isAuthenticated()) return <Navigate to="/login" />;
  if (isAdmin()) return <Navigate to="/admin" />;
  return children;
}

function App() {
  return (
    <Router>
      <GlobalStyles />
      <Toast />
      <Routes>
        <Route path="/login"       element={<LoginPage />} />
        <Route path="/register"    element={<LoginPage />} />
        {/* User routes */}
        <Route path="/menu"        element={<UserRoute><Menu /></UserRoute>} />
        <Route path="/orders"      element={<UserRoute><OrderPage /></UserRoute>} />
        <Route path="/bills"       element={<UserRoute><BillsPage /></UserRoute>} />
        {/* Admin routes */}
        <Route path="/admin"         element={<AdminRoute><AdminDashboard /></AdminRoute>} />
        <Route path="/admin/menu"    element={<AdminRoute><AdminMenu /></AdminRoute>} />
        <Route path="/admin/bills"   element={<AdminRoute><AdminBillsPage /></AdminRoute>} />
        <Route path="/admin/revenue" element={<AdminRoute><RevenuePage /></AdminRoute>} />
        <Route path="*"            element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;
