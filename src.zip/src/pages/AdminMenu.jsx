import { useEffect, useState } from "react";
import { getAllMenu, addMenuItem, deleteMenuItem, updateMenuItem, getAllCategories, addCategory, deleteCategory, updateCategory } from "../service/menu";
import { useNavigate } from "react-router-dom";
import AdminNavbar from "../components/AdminNavbar";

const EMOJIS = ["🍕","🧀","🌶️","🍖"];
const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";

const getCatName = (item) => {
  if (!item.category) return "";
  return typeof item.category === "string" ? item.category.trim() : (item.category.name || "").trim();
};
const getCatColor = (item) => {
  if (!item.category || typeof item.category === "string") return null;
  return item.category.color || null;
};
const getCatColorByName = (name, cats) => {
  if (!name || name === "All") return "#f5a623";
  const m = cats.find(c => c.name.toLowerCase() === name.toLowerCase());
  return m?.color || "#f5a623";
};
const getEmoji = (id) => EMOJIS[Math.abs(Number(id) % EMOJIS.length)];

function AdminMenu() {
  const [menu,          setMenu]         = useState([]);
  const [categories,    setCategories]   = useState([]);
  const [loading,       setLoading]      = useState(true);
  const [selectedCat,   setSelectedCat]  = useState("All");
  const [search,        setSearch]       = useState("");
  const [showAddForm,   setShowAddForm]  = useState(false);
  const [newItem,       setNewItem]      = useState({ name:"", price:"", categoryName:"", description:"", stockLimit:-1 });
  const [editItem,      setEditItem]     = useState(null);
  const [newCat,        setNewCat]       = useState({ name:"", color:"#f5a623" });
  const [editCat,       setEditCat]      = useState(null);
  const [showCatForm,   setShowCatForm]  = useState(false);
  const [focusedInput,  setFocusedInput] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!localStorage.getItem("token") || localStorage.getItem("role") !== "Admin") { navigate("/login"); return; }
    fetchAll();
  }, []);

  const fetchAll = () => {
    setLoading(true);
    Promise.all([
      getAllMenu().then(r => setMenu(r.data)),
      getAllCategories().then(r => setCategories(r.data)).catch(() => {}),
    ]).finally(() => setLoading(false));
  };

  const catNames = ["All", ...Array.from(new Set([...categories.map(c=>c.name).filter(Boolean), ...menu.map(getCatName).filter(Boolean)]))];

  const filtered = menu
    .filter(i => selectedCat === "All" || getCatName(i).toLowerCase() === selectedCat.toLowerCase())
    .filter(i => i.name?.toLowerCase().includes(search.toLowerCase()));

  // ── Item handlers ──
  const handleAddItem = async (e) => {
    e.preventDefault();
    try {
      await addMenuItem({ ...newItem, price: parseFloat(newItem.price), stockLimit: parseInt(newItem.stockLimit ?? -1) });
      setNewItem({ name:"", price:"", categoryName:"", description:"", stockLimit:-1 }); setShowAddForm(false);
      const [rm, rc] = await Promise.all([getAllMenu(), getAllCategories()]);
      setMenu(rm.data); setCategories(rc.data);
    } catch(e) { console.error(e); }
  };
  const handleDelete = async (id) => {
    if (!window.confirm("Delete this item?")) return;
    try { await deleteMenuItem(id); const r = await getAllMenu(); setMenu(r.data); }
    catch(e) { console.error(e); }
  };
  const openEdit = (item) => {
    let catName = "";
    if (item.category) {
      if (typeof item.category === "string") catName = item.category;
      else { const m = categories.find(c => c.id === item.category.id); catName = m ? m.name : (item.category.name || ""); }
    }
    setEditItem({ id:item.id, name:item.name, price:item.price, description:item.description||"", categoryName:catName, stockLimit: item.stockLimit ?? -1 });
  };
  const handleEditSave = async (e) => {
    e.preventDefault();
    try {
      await updateMenuItem(editItem.id, { name:editItem.name, price:parseFloat(editItem.price), description:editItem.description, categoryName:editItem.categoryName, stockLimit: parseInt(editItem.stockLimit ?? -1) });
      setEditItem(null);
      const [rm, rc] = await Promise.all([getAllMenu(), getAllCategories()]);
      setMenu(rm.data); setCategories(rc.data);
    } catch(e) { console.error(e); }
  };

  // ── Category handlers ──
  const handleAddCat = async (e) => {
    e.preventDefault(); if (!newCat.name.trim()) return;
    try { await addCategory({ name:newCat.name.trim(), color:newCat.color }); setNewCat({ name:"", color:"#f5a623" }); setShowCatForm(false); const r = await getAllCategories(); setCategories(r.data); }
    catch(e) { console.error(e); }
  };
  const handleEditCat = async (e) => {
    e.preventDefault();
    try { await updateCategory(editCat.id, { name:editCat.name.trim(), color:editCat.color }); setEditCat(null); const [rc,rm] = await Promise.all([getAllCategories(),getAllMenu()]); setCategories(rc.data); setMenu(rm.data); }
    catch(e) { console.error(e); }
  };
  const handleDeleteCat = async (id) => {
    if (!window.confirm("Delete category?")) return;
    try { await deleteCategory(id); const [rc,rm] = await Promise.all([getAllCategories(),getAllMenu()]); setCategories(rc.data); setMenu(rm.data); }
    catch(e) { console.error(e); }
  };

  const inp = (name) => ({
    background:"#1e1a16", border:focusedInput===name?"1.5px solid #f5a623":"1.5px solid rgba(255,220,120,0.12)",
    boxShadow:focusedInput===name?"0 0 0 3px rgba(245,166,35,0.1)":"none",
    color:"#f5efe6", borderRadius:"9px", padding:"10px 14px", fontSize:"14px", fontFamily:FONT, outline:"none", width:"100%", boxSizing:"border-box",
  });

  return (
    <div style={{ minHeight:"100vh", background:"#0e0c0a", fontFamily:FONT }}>
      <AdminNavbar />

      {/* ── Header ── */}
      <div style={{ padding:"36px 40px 20px", display:"flex", justifyContent:"space-between", alignItems:"flex-end", flexWrap:"wrap", gap:"16px", borderBottom:"1px solid rgba(245,166,35,0.06)" }}>
        <div>
          <h1 style={{ fontFamily:FONT_H, fontSize:"34px", fontWeight:"900", color:"#f5efe6", margin:0 }}>🍕 Menu Management</h1>
          <p style={{ color:"#6b5e50", fontSize:"14px", marginTop:"5px" }}>{menu.length} items · {categories.length} categories</p>
        </div>
        <div style={{ display:"flex", gap:"10px", flexWrap:"wrap" }}>
          <input placeholder="🔍 Search items…" value={search} onChange={e=>setSearch(e.target.value)}
            onFocus={()=>setFocusedInput("s")} onBlur={()=>setFocusedInput(null)}
            style={{ ...inp("s"), width:"200px" }} />
          <button onClick={()=>{ setShowCatForm(!showCatForm); setShowAddForm(false); }}
            style={{ background:"rgba(100,149,237,0.1)", border:"1.5px solid rgba(100,149,237,0.3)", color:"#6495ed", padding:"10px 18px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
            {showCatForm ? "Cancel" : "🏷 Add Category"}
          </button>
          <button onClick={()=>{ setShowAddForm(!showAddForm); setShowCatForm(false); }}
            style={{ background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"10px 18px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
            {showAddForm ? "Cancel" : "+ Add Item"}
          </button>
        </div>
      </div>

      {/* ── Category filter bar ── */}
      <div style={{ padding:"16px 40px", display:"flex", gap:"10px", flexWrap:"wrap", alignItems:"center", borderBottom:"1px solid rgba(245,166,35,0.06)", marginBottom:"4px" }}>
        <span style={{ color:"#6b5e50", fontSize:"12px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px" }}>Filter:</span>
        {catNames.map(cat => {
          const cc = getCatColorByName(cat, categories);
          const isActive = selectedCat === cat;
          return (
            <button key={cat} onClick={()=>setSelectedCat(cat)} style={{
              background: isActive ? cc : "#1e1a16",
              border: isActive ? "none" : `1.5px solid ${cc}33`,
              color: isActive ? "#fff" : cc,
              padding:"7px 16px", borderRadius:"99px", fontSize:"13px", fontWeight:"600",
              cursor:"pointer", fontFamily:FONT,
              boxShadow: isActive ? `0 2px 12px ${cc}55` : "none",
            }}>
              {cat === "All" ? "🍽️ All" : cat}
            </button>
          );
        })}
      </div>

      {/* ── Add Category Form ── */}
      {showCatForm && (
        <div style={{ margin:"16px 40px 0", background:"#161410", border:"1px solid rgba(100,149,237,0.12)", borderRadius:"14px", padding:"20px" }}>
          <h3 style={{ fontFamily:FONT_H, fontSize:"16px", color:"#f5efe6", marginBottom:"14px" }}>Add New Category</h3>
          <form onSubmit={handleAddCat} style={{ display:"flex", gap:"12px", alignItems:"flex-end", flexWrap:"wrap" }}>
            <div style={{ flex:1, minWidth:"160px" }}>
              <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"5px" }}>Name *</label>
              <input placeholder="e.g. Desserts" value={newCat.name} required onChange={e=>setNewCat({...newCat,name:e.target.value})} onFocus={()=>setFocusedInput("cn")} onBlur={()=>setFocusedInput(null)} style={inp("cn")} />
            </div>
            <div>
              <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"5px" }}>Color</label>
              <input type="color" value={newCat.color} onChange={e=>setNewCat({...newCat,color:e.target.value})} style={{ width:"48px", height:"40px", borderRadius:"8px", border:"1.5px solid rgba(255,220,120,0.12)", background:"#1e1a16", cursor:"pointer", padding:"2px" }} />
            </div>
            <button type="submit" style={{ background:"linear-gradient(135deg,#6495ed,#4169e1)", border:"none", color:"#fff", padding:"10px 22px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Add Category</button>
          </form>
        </div>
      )}

      {/* ── Add Item Form ── */}
      {showAddForm && (
        <div style={{ margin:"16px 40px 0", background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"14px", padding:"20px" }}>
          <h3 style={{ fontFamily:FONT_H, fontSize:"16px", color:"#f5efe6", marginBottom:"14px" }}>Add New Item</h3>
          <form onSubmit={handleAddItem}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1fr 1fr", gap:"12px", marginBottom:"12px" }}>
              <input placeholder="Item name *" value={newItem.name} required onChange={e=>setNewItem({...newItem,name:e.target.value})} onFocus={()=>setFocusedInput("an")} onBlur={()=>setFocusedInput(null)} style={inp("an")} />
              <input placeholder="Price *" type="number" step="0.01" min="0" value={newItem.price} required onChange={e=>setNewItem({...newItem,price:e.target.value})} onFocus={()=>setFocusedInput("ap")} onBlur={()=>setFocusedInput(null)} style={inp("ap")} />
              <select value={newItem.categoryName} onChange={e=>setNewItem({...newItem,categoryName:e.target.value})} style={{ ...inp("ac"), cursor:"pointer" }}>
                <option value="">-- Category --</option>
                {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
              </select>
              <input placeholder="Description" value={newItem.description} onChange={e=>setNewItem({...newItem,description:e.target.value})} onFocus={()=>setFocusedInput("ad")} onBlur={()=>setFocusedInput(null)} style={inp("ad")} />
              <div style={{ display:"flex", flexDirection:"column", gap:"4px" }}>
                <label style={{ fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px" }}>Cart Limit</label>
                <select value={newItem.stockLimit} onChange={e=>setNewItem({...newItem,stockLimit:parseInt(e.target.value)})} style={{ ...inp("al"), cursor:"pointer" }}>
                  <option value={-1}>♾️ Unlimited</option>
                  <option value={0}>🚫 Not Available</option>
                  {[1,2,3,4,5,6,7,8,9,10].map(n=><option key={n} value={n}>Max {n}</option>)}
                </select>
              </div>
            </div>
            <div style={{ display:"flex", justifyContent:"flex-end" }}>
              <button type="submit" style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"10px 26px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>+ Add Item</button>
            </div>
          </form>
        </div>
      )}

      {/* ── Categories management strip ── */}
      {categories.length > 0 && (
        <div style={{ margin:"20px 40px 0", background:"#161410", border:"1px solid rgba(255,220,120,0.06)", borderRadius:"12px", padding:"16px 20px" }}>
          <p style={{ color:"#6b5e50", fontSize:"12px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"12px" }}>Categories</p>
          <div style={{ display:"flex", flexWrap:"wrap", gap:"8px" }}>
            {categories.map(cat => (
              <div key={cat.id} style={{ display:"flex", alignItems:"center", gap:"6px", background:`${cat.color||"#f5a623"}18`, border:`1px solid ${cat.color||"#f5a623"}44`, borderRadius:"99px", padding:"5px 12px 5px 8px" }}>
                <span style={{ width:"10px", height:"10px", borderRadius:"50%", background:cat.color||"#f5a623", flexShrink:0 }} />
                <span style={{ color:"#f5efe6", fontSize:"13px", fontWeight:"600" }}>{cat.name}</span>
                <button onClick={()=>setEditCat({...cat})} style={{ background:"none", border:"none", color:"#a89880", cursor:"pointer", fontSize:"12px", padding:"0 2px" }}>✏️</button>
                <button onClick={()=>handleDeleteCat(cat.id)} style={{ background:"none", border:"none", color:"#e85454", cursor:"pointer", fontSize:"12px", padding:"0 2px" }}>✕</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {loading && <div style={{ width:"36px", height:"36px", border:"3px solid rgba(255,220,120,0.1)", borderTopColor:"#f5a623", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"60px auto" }} />}

      {/* ── Menu Items Grid ── */}
      {!loading && (
        <div style={{ padding:"24px 40px 60px" }}>
          <p style={{ color:"#6b5e50", fontSize:"13px", marginBottom:"16px" }}>{filtered.length} item{filtered.length!==1?"s":""}{selectedCat!=="All"?` in ${selectedCat}`:""}</p>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))", gap:"18px" }}>
            {filtered.map((item, i) => {
              const catColor = getCatColor(item) || "#f5a623";
              return (
                <div key={item.id} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"16px", overflow:"hidden", animation:`fadeUp 0.4s ease ${i*0.04}s both`, display:"flex", flexDirection:"column" }}>
                  <div style={{ height:"100px", background:`linear-gradient(135deg,#1e1a16,#252018)`, borderBottom:`2px solid ${catColor}22`, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
                    <span style={{ fontSize:"46px" }}>{getEmoji(item.id)}</span>
                    {getCatName(item) && (
                      <span style={{ position:"absolute", top:"8px", right:"8px", background:`${catColor}30`, border:`1px solid ${catColor}80`, color:catColor, fontSize:"10px", fontWeight:"700", padding:"3px 9px", borderRadius:"99px", textTransform:"uppercase", letterSpacing:"0.4px" }}>
                        {getCatName(item)}
                      </span>
                    )}
                  </div>
                  <div style={{ padding:"14px 16px", display:"flex", flexDirection:"column", flex:1 }}>
                    <h3 style={{ fontFamily:FONT_H, fontSize:"16px", fontWeight:"700", color:"#f5efe6", marginBottom:"4px" }}>{item.name}</h3>
                    {item.description && <p style={{ color:"#a89880", fontSize:"12px", lineHeight:"1.5", marginBottom:"10px", flex:1 }}>{item.description}</p>}
                    {!item.description && <div style={{ flex:1 }} />}
                    <p style={{ color:"#f5a623", fontSize:"19px", fontWeight:"700", marginBottom:"8px", fontFamily:FONT_H }}>₹{parseFloat(item.price).toFixed(2)}</p>
                    <div style={{ marginBottom:"10px" }}>
                      {item.stockLimit === 0 ? (
                        <span style={{ background:"rgba(232,84,84,0.12)", border:"1px solid rgba(232,84,84,0.3)", color:"#e85454", fontSize:"11px", fontWeight:"700", padding:"3px 10px", borderRadius:"6px" }}>🚫 Not Available</span>
                      ) : item.stockLimit === -1 ? (
                        <span style={{ background:"rgba(76,175,125,0.1)", border:"1px solid rgba(76,175,125,0.25)", color:"#4caf7d", fontSize:"11px", fontWeight:"600", padding:"3px 10px", borderRadius:"6px" }}>♾️ Unlimited</span>
                      ) : (
                        <span style={{ background:"rgba(245,166,35,0.1)", border:"1px solid rgba(245,166,35,0.3)", color:"#f5a623", fontSize:"11px", fontWeight:"700", padding:"3px 10px", borderRadius:"6px" }}>⚠️ Limit: {item.stockLimit}</span>
                      )}
                    </div>
                    <div style={{ display:"flex", gap:"8px" }}>
                      <button onClick={()=>openEdit(item)} style={{ flex:1, background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"9px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>✏️ Edit</button>
                      <button onClick={()=>handleDelete(item.id)} style={{ flex:1, background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.3)", color:"#e85454", padding:"9px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>🗑 Delete</button>
                    </div>
                  </div>
                </div>
              );
            })}
            {filtered.length === 0 && (
              <div style={{ gridColumn:"1/-1", textAlign:"center", color:"#6b5e50", padding:"60px 20px" }}>
                <div style={{ fontSize:"48px", marginBottom:"12px" }}>🍽️</div>
                <p style={{ fontSize:"15px" }}>No items{selectedCat !== "All" ? ` in ${selectedCat}` : ""}</p>
                {selectedCat !== "All" && <button onClick={()=>setSelectedCat("All")} style={{ marginTop:"12px", background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"8px 20px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Show all</button>}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Edit Item Modal ── */}
      {editItem && (
        <div onClick={()=>setEditItem(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(4px)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.12)", borderRadius:"18px", padding:"32px", width:"100%", maxWidth:"480px", boxShadow:"0 24px 64px rgba(0,0,0,0.6)" }}>
            <h2 style={{ fontFamily:FONT_H, fontSize:"22px", color:"#f5efe6", marginBottom:"22px" }}>Edit Item</h2>
            <form onSubmit={handleEditSave} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
              {[{n:"en",label:"Item Name",key:"name",type:"text"},{n:"ep",label:"Price",key:"price",type:"number"},{n:"ed",label:"Description",key:"description",type:"text"}].map(f=>(
                <div key={f.n}>
                  <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>{f.label}</label>
                  <input type={f.type} value={editItem[f.key]||""} required={["en","ep"].includes(f.n)} onChange={e=>setEditItem({...editItem,[f.key]:e.target.value})} onFocus={()=>setFocusedInput(f.n)} onBlur={()=>setFocusedInput(null)} style={inp(f.n)} />
                </div>
              ))}
              <div>
                <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Category</label>
                <select value={editItem.categoryName} onChange={e=>setEditItem({...editItem,categoryName:e.target.value})} style={{ ...inp("ec"), cursor:"pointer" }}>
                  <option value="">-- Category --</option>
                  {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Cart Limit</label>
                <select value={editItem.stockLimit ?? -1} onChange={e=>setEditItem({...editItem,stockLimit:parseInt(e.target.value)})} style={{ ...inp("el"), cursor:"pointer" }}>
                  <option value={-1}>♾️ Unlimited</option>
                  <option value={0}>🚫 Not Available (hidden from users)</option>
                  {[1,2,3,4,5,6,7,8,9,10].map(n=><option key={n} value={n}>Max {n} per order</option>)}
                </select>
                <p style={{ color:"#6b5e50", fontSize:"11px", marginTop:"4px" }}>Set 0 to mark item as unavailable. Set max qty users can add to cart.</p>
              </div>
              <div style={{ display:"flex", gap:"10px", marginTop:"6px" }}>
                <button type="button" onClick={()=>setEditItem(null)} style={{ flex:1, background:"transparent", border:"1.5px solid rgba(255,220,120,0.15)", color:"#a89880", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Cancel</button>
                <button type="submit" style={{ flex:2, background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Edit Category Modal ── */}
      {editCat && (
        <div onClick={()=>setEditCat(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(4px)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#161410", border:"1px solid rgba(100,149,237,0.2)", borderRadius:"18px", padding:"32px", width:"100%", maxWidth:"400px", boxShadow:"0 24px 64px rgba(0,0,0,0.6)" }}>
            <h2 style={{ fontFamily:FONT_H, fontSize:"20px", color:"#f5efe6", marginBottom:"20px" }}>Edit Category</h2>
            <form onSubmit={handleEditCat} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
              <div>
                <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Name</label>
                <input value={editCat.name} required onChange={e=>setEditCat({...editCat,name:e.target.value})} onFocus={()=>setFocusedInput("ecn")} onBlur={()=>setFocusedInput(null)} style={inp("ecn")} />
              </div>
              <div>
                <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Color</label>
                <input type="color" value={editCat.color||"#f5a623"} onChange={e=>setEditCat({...editCat,color:e.target.value})} style={{ width:"60px", height:"40px", borderRadius:"8px", border:"1.5px solid rgba(255,220,120,0.12)", background:"#1e1a16", cursor:"pointer", padding:"2px" }} />
              </div>
              <div style={{ display:"flex", gap:"10px", marginTop:"4px" }}>
                <button type="button" onClick={()=>setEditCat(null)} style={{ flex:1, background:"transparent", border:"1.5px solid rgba(255,220,120,0.15)", color:"#a89880", padding:"11px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Cancel</button>
                <button type="submit" style={{ flex:2, background:"linear-gradient(135deg,#6495ed,#4169e1)", border:"none", color:"#fff", padding:"11px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminMenu;



// import { useEffect, useState } from "react";
// import { getAllMenu, addMenuItem, deleteMenuItem, updateMenuItem, getAllCategories, addCategory, deleteCategory, updateCategory } from "../service/menu";
// import { useNavigate } from "react-router-dom";
// import AdminNavbar from "../components/AdminNavbar";

// const EMOJIS = ["🍕","🧀","🌶️","🍖","🥓","🫑","🧅","🍗","🥩","🌮"];
// const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
// const FONT_H = "Georgia,'Times New Roman',serif";

// const getCatName = (item) => {
//   if (!item.category) return "";
//   return typeof item.category === "string" ? item.category.trim() : (item.category.name || "").trim();
// };
// const getCatColor = (item) => {
//   if (!item.category || typeof item.category === "string") return null;
//   return item.category.color || null;
// };
// const getCatColorByName = (name, cats) => {
//   if (!name || name === "All") return "#f5a623";
//   const m = cats.find(c => c.name.toLowerCase() === name.toLowerCase());
//   return m?.color || "#f5a623";
// };
// const getEmoji = (id) => EMOJIS[Math.abs(Number(id) % EMOJIS.length)];

// function AdminMenu() {
//   const [menu,          setMenu]         = useState([]);
//   const [categories,    setCategories]   = useState([]);
//   const [loading,       setLoading]      = useState(true);
//   const [selectedCat,   setSelectedCat]  = useState("All");
//   const [search,        setSearch]       = useState("");
//   const [showAddForm,   setShowAddForm]  = useState(false);
//   const [newItem,       setNewItem]      = useState({ name:"", price:"", categoryName:"", description:"" });
//   const [editItem,      setEditItem]     = useState(null);
//   const [newCat,        setNewCat]       = useState({ name:"", color:"#f5a623" });
//   const [editCat,       setEditCat]      = useState(null);
//   const [showCatForm,   setShowCatForm]  = useState(false);
//   const [focusedInput,  setFocusedInput] = useState(null);
//   const navigate = useNavigate();

//   useEffect(() => {
//     if (!localStorage.getItem("token") || localStorage.getItem("role") !== "Admin") { navigate("/login"); return; }
//     fetchAll();
//   }, []);

//   const fetchAll = () => {
//     setLoading(true);
//     Promise.all([
//       getAllMenu().then(r => setMenu(r.data)),
//       getAllCategories().then(r => setCategories(r.data)).catch(() => {}),
//     ]).finally(() => setLoading(false));
//   };

//   const catNames = ["All", ...Array.from(new Set([...categories.map(c=>c.name).filter(Boolean), ...menu.map(getCatName).filter(Boolean)]))];

//   const filtered = menu
//     .filter(i => selectedCat === "All" || getCatName(i).toLowerCase() === selectedCat.toLowerCase())
//     .filter(i => i.name?.toLowerCase().includes(search.toLowerCase()));

//   // ── Item handlers ──
//   const handleAddItem = async (e) => {
//     e.preventDefault();
//     try {
//       await addMenuItem({ ...newItem, price: parseFloat(newItem.price) });
//       setNewItem({ name:"", price:"", categoryName:"", description:"" }); setShowAddForm(false);
//       const [rm, rc] = await Promise.all([getAllMenu(), getAllCategories()]);
//       setMenu(rm.data); setCategories(rc.data);
//     } catch(e) { console.error(e); }
//   };
//   const handleDelete = async (id) => {
//     if (!window.confirm("Delete this item?")) return;
//     try { await deleteMenuItem(id); const r = await getAllMenu(); setMenu(r.data); }
//     catch(e) { console.error(e); }
//   };
//   const openEdit = (item) => {
//     let catName = "";
//     if (item.category) {
//       if (typeof item.category === "string") catName = item.category;
//       else { const m = categories.find(c => c.id === item.category.id); catName = m ? m.name : (item.category.name || ""); }
//     }
//     setEditItem({ id:item.id, name:item.name, price:item.price, description:item.description||"", categoryName:catName });
//   };
//   const handleEditSave = async (e) => {
//     e.preventDefault();
//     try {
//       await updateMenuItem(editItem.id, { name:editItem.name, price:parseFloat(editItem.price), description:editItem.description, categoryName:editItem.categoryName });
//       setEditItem(null);
//       const [rm, rc] = await Promise.all([getAllMenu(), getAllCategories()]);
//       setMenu(rm.data); setCategories(rc.data);
//     } catch(e) { console.error(e); }
//   };

//   // ── Category handlers ──
//   const handleAddCat = async (e) => {
//     e.preventDefault(); if (!newCat.name.trim()) return;
//     try { await addCategory({ name:newCat.name.trim(), color:newCat.color }); setNewCat({ name:"", color:"#f5a623" }); setShowCatForm(false); const r = await getAllCategories(); setCategories(r.data); }
//     catch(e) { console.error(e); }
//   };
//   const handleEditCat = async (e) => {
//     e.preventDefault();
//     try { await updateCategory(editCat.id, { name:editCat.name.trim(), color:editCat.color }); setEditCat(null); const [rc,rm] = await Promise.all([getAllCategories(),getAllMenu()]); setCategories(rc.data); setMenu(rm.data); }
//     catch(e) { console.error(e); }
//   };
//   const handleDeleteCat = async (id) => {
//     if (!window.confirm("Delete category?")) return;
//     try { await deleteCategory(id); const [rc,rm] = await Promise.all([getAllCategories(),getAllMenu()]); setCategories(rc.data); setMenu(rm.data); }
//     catch(e) { console.error(e); }
//   };

//   const inp = (name) => ({
//     background:"#1e1a16", border:focusedInput===name?"1.5px solid #f5a623":"1.5px solid rgba(255,220,120,0.12)",
//     boxShadow:focusedInput===name?"0 0 0 3px rgba(245,166,35,0.1)":"none",
//     color:"#f5efe6", borderRadius:"9px", padding:"10px 14px", fontSize:"14px", fontFamily:FONT, outline:"none", width:"100%", boxSizing:"border-box",
//   });

//   return (
//     <div style={{ minHeight:"100vh", background:"#0e0c0a", fontFamily:FONT }}>
//       <AdminNavbar />

//       {/* ── Header ── */}
//       <div style={{ padding:"36px 40px 20px", display:"flex", justifyContent:"space-between", alignItems:"flex-end", flexWrap:"wrap", gap:"16px", borderBottom:"1px solid rgba(245,166,35,0.06)" }}>
//         <div>
//           <h1 style={{ fontFamily:FONT_H, fontSize:"34px", fontWeight:"900", color:"#f5efe6", margin:0 }}>🍕 Menu Management</h1>
//           <p style={{ color:"#6b5e50", fontSize:"14px", marginTop:"5px" }}>{menu.length} items · {categories.length} categories</p>
//         </div>
//         <div style={{ display:"flex", gap:"10px", flexWrap:"wrap" }}>
//           <input placeholder="🔍 Search items…" value={search} onChange={e=>setSearch(e.target.value)}
//             onFocus={()=>setFocusedInput("s")} onBlur={()=>setFocusedInput(null)}
//             style={{ ...inp("s"), width:"200px" }} />
//           <button onClick={()=>{ setShowCatForm(!showCatForm); setShowAddForm(false); }}
//             style={{ background:"rgba(100,149,237,0.1)", border:"1.5px solid rgba(100,149,237,0.3)", color:"#6495ed", padding:"10px 18px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
//             {showCatForm ? "Cancel" : "🏷 Add Category"}
//           </button>
//           <button onClick={()=>{ setShowAddForm(!showAddForm); setShowCatForm(false); }}
//             style={{ background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"10px 18px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
//             {showAddForm ? "Cancel" : "+ Add Item"}
//           </button>
//         </div>
//       </div>

//       {/* ── Category filter bar ── */}
//       <div style={{ padding:"16px 40px", display:"flex", gap:"10px", flexWrap:"wrap", alignItems:"center", borderBottom:"1px solid rgba(245,166,35,0.06)", marginBottom:"4px" }}>
//         <span style={{ color:"#6b5e50", fontSize:"12px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px" }}>Filter:</span>
//         {catNames.map(cat => {
//           const cc = getCatColorByName(cat, categories);
//           const isActive = selectedCat === cat;
//           return (
//             <button key={cat} onClick={()=>setSelectedCat(cat)} style={{
//               background: isActive ? cc : "#1e1a16",
//               border: isActive ? "none" : `1.5px solid ${cc}33`,
//               color: isActive ? "#fff" : cc,
//               padding:"7px 16px", borderRadius:"99px", fontSize:"13px", fontWeight:"600",
//               cursor:"pointer", fontFamily:FONT,
//               boxShadow: isActive ? `0 2px 12px ${cc}55` : "none",
//             }}>
//               {cat === "All" ? "🍽️ All" : cat}
//             </button>
//           );
//         })}
//       </div>

//       {/* ── Add Category Form ── */}
//       {showCatForm && (
//         <div style={{ margin:"16px 40px 0", background:"#161410", border:"1px solid rgba(100,149,237,0.12)", borderRadius:"14px", padding:"20px" }}>
//           <h3 style={{ fontFamily:FONT_H, fontSize:"16px", color:"#f5efe6", marginBottom:"14px" }}>Add New Category</h3>
//           <form onSubmit={handleAddCat} style={{ display:"flex", gap:"12px", alignItems:"flex-end", flexWrap:"wrap" }}>
//             <div style={{ flex:1, minWidth:"160px" }}>
//               <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"5px" }}>Name *</label>
//               <input placeholder="e.g. Desserts" value={newCat.name} required onChange={e=>setNewCat({...newCat,name:e.target.value})} onFocus={()=>setFocusedInput("cn")} onBlur={()=>setFocusedInput(null)} style={inp("cn")} />
//             </div>
//             <div>
//               <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"5px" }}>Color</label>
//               <input type="color" value={newCat.color} onChange={e=>setNewCat({...newCat,color:e.target.value})} style={{ width:"48px", height:"40px", borderRadius:"8px", border:"1.5px solid rgba(255,220,120,0.12)", background:"#1e1a16", cursor:"pointer", padding:"2px" }} />
//             </div>
//             <button type="submit" style={{ background:"linear-gradient(135deg,#6495ed,#4169e1)", border:"none", color:"#fff", padding:"10px 22px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Add Category</button>
//           </form>
//         </div>
//       )}

//       {/* ── Add Item Form ── */}
//       {showAddForm && (
//         <div style={{ margin:"16px 40px 0", background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"14px", padding:"20px" }}>
//           <h3 style={{ fontFamily:FONT_H, fontSize:"16px", color:"#f5efe6", marginBottom:"14px" }}>Add New Item</h3>
//           <form onSubmit={handleAddItem}>
//             <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1fr", gap:"12px", marginBottom:"12px" }}>
//               <input placeholder="Item name *" value={newItem.name} required onChange={e=>setNewItem({...newItem,name:e.target.value})} onFocus={()=>setFocusedInput("an")} onBlur={()=>setFocusedInput(null)} style={inp("an")} />
//               <input placeholder="Price *" type="number" step="0.01" min="0" value={newItem.price} required onChange={e=>setNewItem({...newItem,price:e.target.value})} onFocus={()=>setFocusedInput("ap")} onBlur={()=>setFocusedInput(null)} style={inp("ap")} />
//               <select value={newItem.categoryName} onChange={e=>setNewItem({...newItem,categoryName:e.target.value})} style={{ ...inp("ac"), cursor:"pointer" }}>
//                 <option value="">-- Category --</option>
//                 {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
//               </select>
//               <input placeholder="Description" value={newItem.description} onChange={e=>setNewItem({...newItem,description:e.target.value})} onFocus={()=>setFocusedInput("ad")} onBlur={()=>setFocusedInput(null)} style={inp("ad")} />
//             </div>
//             <div style={{ display:"flex", justifyContent:"flex-end" }}>
//               <button type="submit" style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"10px 26px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>+ Add Item</button>
//             </div>
//           </form>
//         </div>
//       )}

//       {/* ── Categories management strip ── */}
//       {categories.length > 0 && (
//         <div style={{ margin:"20px 40px 0", background:"#161410", border:"1px solid rgba(255,220,120,0.06)", borderRadius:"12px", padding:"16px 20px" }}>
//           <p style={{ color:"#6b5e50", fontSize:"12px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"12px" }}>Categories</p>
//           <div style={{ display:"flex", flexWrap:"wrap", gap:"8px" }}>
//             {categories.map(cat => (
//               <div key={cat.id} style={{ display:"flex", alignItems:"center", gap:"6px", background:`${cat.color||"#f5a623"}18`, border:`1px solid ${cat.color||"#f5a623"}44`, borderRadius:"99px", padding:"5px 12px 5px 8px" }}>
//                 <span style={{ width:"10px", height:"10px", borderRadius:"50%", background:cat.color||"#f5a623", flexShrink:0 }} />
//                 <span style={{ color:"#f5efe6", fontSize:"13px", fontWeight:"600" }}>{cat.name}</span>
//                 <button onClick={()=>setEditCat({...cat})} style={{ background:"none", border:"none", color:"#a89880", cursor:"pointer", fontSize:"12px", padding:"0 2px" }}>✏️</button>
//                 <button onClick={()=>handleDeleteCat(cat.id)} style={{ background:"none", border:"none", color:"#e85454", cursor:"pointer", fontSize:"12px", padding:"0 2px" }}>✕</button>
//               </div>
//             ))}
//           </div>
//         </div>
//       )}

//       {loading && <div style={{ width:"36px", height:"36px", border:"3px solid rgba(255,220,120,0.1)", borderTopColor:"#f5a623", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"60px auto" }} />}

//       {/* ── Menu Items Grid ── */}
//       {!loading && (
//         <div style={{ padding:"24px 40px 60px" }}>
//           <p style={{ color:"#6b5e50", fontSize:"13px", marginBottom:"16px" }}>{filtered.length} item{filtered.length!==1?"s":""}{selectedCat!=="All"?` in ${selectedCat}`:""}</p>
//           <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))", gap:"18px" }}>
//             {filtered.map((item, i) => {
//               const catColor = getCatColor(item) || "#f5a623";
//               return (
//                 <div key={item.id} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"16px", overflow:"hidden", animation:`fadeUp 0.4s ease ${i*0.04}s both`, display:"flex", flexDirection:"column" }}>
//                   <div style={{ height:"100px", background:`linear-gradient(135deg,#1e1a16,#252018)`, borderBottom:`2px solid ${catColor}22`, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
//                     <span style={{ fontSize:"46px" }}>{getEmoji(item.id)}</span>
//                     {getCatName(item) && (
//                       <span style={{ position:"absolute", top:"8px", right:"8px", background:`${catColor}30`, border:`1px solid ${catColor}80`, color:catColor, fontSize:"10px", fontWeight:"700", padding:"3px 9px", borderRadius:"99px", textTransform:"uppercase", letterSpacing:"0.4px" }}>
//                         {getCatName(item)}
//                       </span>
//                     )}
//                   </div>
//                   <div style={{ padding:"14px 16px", display:"flex", flexDirection:"column", flex:1 }}>
//                     <h3 style={{ fontFamily:FONT_H, fontSize:"16px", fontWeight:"700", color:"#f5efe6", marginBottom:"4px" }}>{item.name}</h3>
//                     {item.description && <p style={{ color:"#a89880", fontSize:"12px", lineHeight:"1.5", marginBottom:"10px", flex:1 }}>{item.description}</p>}
//                     {!item.description && <div style={{ flex:1 }} />}
//                     <p style={{ color:"#f5a623", fontSize:"19px", fontWeight:"700", marginBottom:"12px", fontFamily:FONT_H }}>₹{parseFloat(item.price).toFixed(2)}</p>
//                     <div style={{ display:"flex", gap:"8px" }}>
//                       <button onClick={()=>openEdit(item)} style={{ flex:1, background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"9px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>✏️ Edit</button>
//                       <button onClick={()=>handleDelete(item.id)} style={{ flex:1, background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.3)", color:"#e85454", padding:"9px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>🗑 Delete</button>
//                     </div>
//                   </div>
//                 </div>
//               );
//             })}
//             {filtered.length === 0 && (
//               <div style={{ gridColumn:"1/-1", textAlign:"center", color:"#6b5e50", padding:"60px 20px" }}>
//                 <div style={{ fontSize:"48px", marginBottom:"12px" }}>🍽️</div>
//                 <p style={{ fontSize:"15px" }}>No items{selectedCat !== "All" ? ` in ${selectedCat}` : ""}</p>
//                 {selectedCat !== "All" && <button onClick={()=>setSelectedCat("All")} style={{ marginTop:"12px", background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"8px 20px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Show all</button>}
//               </div>
//             )}
//           </div>
//         </div>
//       )}

//       {/* ── Edit Item Modal ── */}
//       {editItem && (
//         <div onClick={()=>setEditItem(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(4px)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
//           <div onClick={e=>e.stopPropagation()} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.12)", borderRadius:"18px", padding:"32px", width:"100%", maxWidth:"480px", boxShadow:"0 24px 64px rgba(0,0,0,0.6)" }}>
//             <h2 style={{ fontFamily:FONT_H, fontSize:"22px", color:"#f5efe6", marginBottom:"22px" }}>Edit Item</h2>
//             <form onSubmit={handleEditSave} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
//               {[{n:"en",label:"Item Name",key:"name",type:"text"},{n:"ep",label:"Price",key:"price",type:"number"},{n:"ed",label:"Description",key:"description",type:"text"}].map(f=>(
//                 <div key={f.n}>
//                   <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>{f.label}</label>
//                   <input type={f.type} value={editItem[f.key]||""} required={["en","ep"].includes(f.n)} onChange={e=>setEditItem({...editItem,[f.key]:e.target.value})} onFocus={()=>setFocusedInput(f.n)} onBlur={()=>setFocusedInput(null)} style={inp(f.n)} />
//                 </div>
//               ))}
//               <div>
//                 <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Category</label>
//                 <select value={editItem.categoryName} onChange={e=>setEditItem({...editItem,categoryName:e.target.value})} style={{ ...inp("ec"), cursor:"pointer" }}>
//                   <option value="">-- Category --</option>
//                   {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
//                 </select>
//               </div>
//               <div style={{ display:"flex", gap:"10px", marginTop:"6px" }}>
//                 <button type="button" onClick={()=>setEditItem(null)} style={{ flex:1, background:"transparent", border:"1.5px solid rgba(255,220,120,0.15)", color:"#a89880", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Cancel</button>
//                 <button type="submit" style={{ flex:2, background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Save Changes</button>
//               </div>
//             </form>
//           </div>
//         </div>
//       )}

//       {/* ── Edit Category Modal ── */}
//       {editCat && (
//         <div onClick={()=>setEditCat(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(4px)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
//           <div onClick={e=>e.stopPropagation()} style={{ background:"#161410", border:"1px solid rgba(100,149,237,0.2)", borderRadius:"18px", padding:"32px", width:"100%", maxWidth:"400px", boxShadow:"0 24px 64px rgba(0,0,0,0.6)" }}>
//             <h2 style={{ fontFamily:FONT_H, fontSize:"20px", color:"#f5efe6", marginBottom:"20px" }}>Edit Category</h2>
//             <form onSubmit={handleEditCat} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
//               <div>
//                 <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Name</label>
//                 <input value={editCat.name} required onChange={e=>setEditCat({...editCat,name:e.target.value})} onFocus={()=>setFocusedInput("ecn")} onBlur={()=>setFocusedInput(null)} style={inp("ecn")} />
//               </div>
//               <div>
//                 <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Color</label>
//                 <input type="color" value={editCat.color||"#f5a623"} onChange={e=>setEditCat({...editCat,color:e.target.value})} style={{ width:"60px", height:"40px", borderRadius:"8px", border:"1.5px solid rgba(255,220,120,0.12)", background:"#1e1a16", cursor:"pointer", padding:"2px" }} />
//               </div>
//               <div style={{ display:"flex", gap:"10px", marginTop:"4px" }}>
//                 <button type="button" onClick={()=>setEditCat(null)} style={{ flex:1, background:"transparent", border:"1.5px solid rgba(255,220,120,0.15)", color:"#a89880", padding:"11px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Cancel</button>
//                 <button type="submit" style={{ flex:2, background:"linear-gradient(135deg,#6495ed,#4169e1)", border:"none", color:"#fff", padding:"11px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Save</button>
//               </div>
//             </form>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// export default AdminMenu;
