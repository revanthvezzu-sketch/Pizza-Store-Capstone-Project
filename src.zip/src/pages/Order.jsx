import { useEffect, useState, useRef } from "react";
import { getMyOrders, getAllOrders, deleteOrder, getBillByOrder } from "../service/order";
import { useNavigate } from "react-router-dom";
import UserNavbar from "../components/UserNavbar";
import AdminNavbar from "../components/AdminNavbar";
import BillPopup from "../components/BillPopup";

const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";
const CANCEL_WINDOW = 60;

const STATUS_COLORS = {
  PLACED:    { bg:"rgba(245,166,35,0.12)",  color:"#f5a623",  border:"rgba(245,166,35,0.3)"  },
  PREPARING: { bg:"rgba(100,149,237,0.12)", color:"#6495ed",  border:"rgba(100,149,237,0.3)" },
  READY:     { bg:"rgba(76,175,125,0.12)",  color:"#4caf7d",  border:"rgba(76,175,125,0.3)"  },
  DELIVERED: { bg:"rgba(76,175,125,0.08)",  color:"#4caf7d",  border:"rgba(76,175,125,0.2)"  },
  APPROVED:  { bg:"rgba(76,175,125,0.15)",  color:"#4caf7d",  border:"rgba(76,175,125,0.4)"  },
  CANCELLED: { bg:"rgba(232,84,84,0.1)",    color:"#e85454",  border:"rgba(232,84,84,0.3)"   },
};
const BILL_STATUS_STYLE = {
  APPROVED: { bg:"rgba(76,175,125,0.12)",  color:"#4caf7d", border:"rgba(76,175,125,0.3)",  label:"Bill ✅ Approved" },
  DENIED:   { bg:"rgba(232,84,84,0.1)",    color:"#e85454", border:"rgba(232,84,84,0.3)",   label:"Bill ❌ Denied"   },
};

const getTotal  = (o) => parseFloat(o.totalAmount ?? o.total ?? 0);
const getStatus = (s) => STATUS_COLORS[(s||"PLACED").toUpperCase()] || STATUS_COLORS.PLACED;
const STATUS_LABEL = {
  PLACED:"🕐 Placed", PREPARING:"👨‍🍳 Preparing", READY:"✅ Ready",
  DELIVERED:"📦 Delivered", CANCELLED:"❌ Cancelled", APPROVED:"✅ Approved"
};

function OrderPage() {
  const [orders,    setOrders]    = useState([]);
  const [bills,     setBills]     = useState({}); // orderId → bill
  const [loading,   setLoading]   = useState(true);
  const [filter,    setFilter]    = useState("all");
  const [billPopup, setBillPopup] = useState(null);
  const [timers,    setTimers]    = useState({});

  // sessionStorage key: bill_{orderId}_{APPROVED|DENIED} — popup shows once per decision
  const countdowns = useRef({});
  const navigate   = useNavigate();
  const role       = localStorage.getItem("role");
  
  //Timer
  const startCountdown = (orderId, secondsLeft) => {
    if (countdowns.current[orderId]) return;
    if (secondsLeft <= 0) return;
    setTimers(prev => ({ ...prev, [orderId]: secondsLeft }));
    countdowns.current[orderId] = setInterval(() => {
      setTimers(prev => {
        const next = (prev[orderId] ?? 1) - 1;
        if (next <= 0) {
          clearInterval(countdowns.current[orderId]);
          delete countdowns.current[orderId];
          const { [orderId]: _, ...rest } = prev;
          return rest;
        }
        return { ...prev, [orderId]: next };
      });
    }, 100);
  };

  const fetchOrders = async () => {
    try {
      const fn = role === "Admin" ? getAllOrders : getMyOrders;
      const r  = await fn();
      const fetched = r.data;
      setOrders(fetched);

      if (role !== "Admin") {
        for (const order of fetched) {
          const st = (order.status || "").toUpperCase();

          // Fetch bill for any non-PLACED order — always re-fetch to get latest status
          const billableStatus = ["PREPARING","CANCELLED","READY","DELIVERED"].includes(st);
          if (billableStatus) {
            try {
              const br = await getBillByOrder(order.id);
              if (br.data) {
                // Always derive status from order context — never trust null billStatus
                const rawStatus = (br.data.billStatus || "").toUpperCase();
                const orderSt   = (order.status || "").toUpperCase();
                const derived   = rawStatus === "DENIED"   ? "DENIED"
                                : rawStatus === "APPROVED" ? "APPROVED"
                                : orderSt  === "CANCELLED" ? "DENIED"
                                : "APPROVED";
                const enriched = { ...br.data, billStatus: derived };

                // Always update bills state with latest derived status
                setBills(prev => ({ ...prev, [order.id]: enriched }));

                // Show popup once per DECISION (approve or deny) per session
                // Key = orderId + derived status so deny after approve shows new popup
                const popupKey = `bill_${order.id}_${derived}`;
                const shown = sessionStorage.getItem(popupKey);
                if (!shown) {
                  sessionStorage.setItem(popupKey, "1");
                  setBillPopup({ bill: enriched, order });
                }
              }
            } catch {}
          }
           
          //Timer 
          // Start countdown only for PLACED
          if (st === "PLACED" && !countdowns.current[order.id]) {
            let elapsed = 0;
            if (order.createdAt) {
              elapsed = Math.floor((Date.now() - new Date(order.createdAt).getTime()) / 100);
            }
            const remaining = CANCEL_WINDOW - elapsed;
            if (remaining > 0) startCountdown(order.id, remaining);
            else {
              // Timer already done — just remove from timers (DO NOT auto-change status)
              setTimers(prev => { const { [order.id]: _, ...rest } = prev; return rest; });
            }
          }
        }
      }
    } catch(e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    if (!localStorage.getItem("token")) { navigate("/login"); return; }
    fetchOrders();
    const interval = setInterval(fetchOrders, 6000);
    return () => {
      clearInterval(interval);
      Object.values(countdowns.current).forEach(clearInterval);
      countdowns.current = {};
    };
  }, []);

  const handleCancel = async (id) => {
    if (!window.confirm("Cancel this order?")) return;
    try {
      await deleteOrder(id);
      if (countdowns.current[id]) { clearInterval(countdowns.current[id]); delete countdowns.current[id]; }
      setOrders(prev => prev.filter(o => o.id !== id));
      setTimers(prev => { const { [id]: _, ...rest } = prev; return rest; });
    } catch(e) { console.error(e); }
  };

  const FILTERS  = ["all","PLACED","PREPARING","READY","DELIVERED","CANCELLED"];
  const filtered = filter === "all" ? orders : orders.filter(o => (o.status||"PLACED").toUpperCase() === filter);

  return (
    <div style={{ minHeight:"100vh", background:"#0e0c0a", fontFamily:FONT }}>
      {role === "Admin" ? <AdminNavbar /> : <UserNavbar />}
      {billPopup && <BillPopup bill={billPopup.bill} order={billPopup.order} onClose={() => setBillPopup(null)} />}

      <div style={{ padding:"36px 40px 24px", display:"flex", justifyContent:"space-between", alignItems:"flex-end", flexWrap:"wrap", gap:"20px", borderBottom:"1px solid rgba(245,166,35,0.06)", marginBottom:"28px" }}>
        <div>
          <h1 style={{ fontFamily:FONT_H, fontSize:"36px", fontWeight:"900", color:"#f5efe6" }}>My Orders</h1>
          <p style={{ color:"#6b5e50", fontSize:"14px", marginTop:"4px" }}>{orders.length} total orders</p>
        </div>
      </div>

      <div style={{ padding:"0 40px", display:"flex", gap:"8px", marginBottom:"28px", flexWrap:"wrap" }}>
        {FILTERS.map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{ background:filter===f?"rgba(245,166,35,0.12)":"transparent", border:filter===f?"1.5px solid rgba(245,166,35,0.3)":"1.5px solid rgba(255,220,120,0.1)", color:filter===f?"#f5a623":"#6b5e50", padding:"7px 16px", borderRadius:"99px", fontSize:"13px", fontWeight:"500", cursor:"pointer", fontFamily:FONT }}>
            {f === "all" ? "All" : f.charAt(0)+f.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      {loading && <div style={{ width:"36px", height:"36px", border:"3px solid rgba(255,220,120,0.1)", borderTopColor:"#f5a623", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"60px auto" }} />}

      {!loading && (
        <div style={{ padding:"0 40px 60px", display:"flex", flexDirection:"column", gap:"14px" }}>
          {filtered.length === 0 ? (
            <div style={{ textAlign:"center", color:"#6b5e50", padding:"80px" }}>
              <div style={{ fontSize:"52px", marginBottom:"16px" }}>📋</div>No orders found
            </div>
          ) : filtered.map((order, i) => {
            const st        = getStatus(order.status);
            const tot       = getTotal(order);
            const statusKey = (order.status||"PLACED").toUpperCase();
            const countdown = timers[order.id];
            const timerActive = statusKey === "PLACED" && countdown !== undefined && countdown > 0;
            const canCancel   = timerActive;
            const bill        = bills[order.id];
            // bill already has enriched billStatus from fetchOrders (derived from order context)
            const derivedBillStatus = bill ? (bill.billStatus || "APPROVED").toUpperCase() : null;
            const bs = derivedBillStatus ? (BILL_STATUS_STYLE[derivedBillStatus] || BILL_STATUS_STYLE.APPROVED) : null;

            return (
              <div key={order.id} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"16px", padding:"22px 26px", animation:`fadeUp 0.4s ease ${i*0.04}s both` }}>
                {/* Header row */}
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"14px", flexWrap:"wrap", gap:"12px" }}>
                  <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:"12px", flexWrap:"wrap" }}>
                      <span style={{ fontFamily:FONT_H, fontSize:"18px", fontWeight:"700", color:"#f5efe6" }}>Order #{order.id}</span>
                      {/* ORDER STATUS */}
                      <span style={{ background:st.bg, color:st.color, border:`1px solid ${st.border}`, fontSize:"12px", fontWeight:"700", padding:"4px 12px", borderRadius:"99px" }}>
                        {STATUS_LABEL[statusKey] || statusKey}
                      </span>
                      {/* BILL STATUS — shown separately once bill exists */}
                      {bs && (
                        <span style={{ background:bs.bg, color:bs.color, border:`1px solid ${bs.border}`, fontSize:"12px", fontWeight:"700", padding:"4px 12px", borderRadius:"99px" }}>
                          {bs.label}
                        </span>
                      )}
                    </div>
                    {/* Email + delivery */}
                    <div style={{ display:"flex", gap:"10px", flexWrap:"wrap", alignItems:"center" }}>
                      {order.userEmail && (
                        <span style={{ color:"#6b5e50", fontSize:"12px" }}>📧 {order.userEmail}</span>
                      )}
                      {order.deliveryMode && (
                        <span style={{ background:"rgba(100,149,237,0.1)", border:"1px solid rgba(100,149,237,0.25)", color:"#6495ed", fontSize:"12px", fontWeight:"600", padding:"3px 10px", borderRadius:"99px" }}>
                          🚚 {order.deliveryMode}
                        </span>
                      )}
                    </div>
                  </div>

                  <div style={{ display:"flex", alignItems:"center", gap:"12px", flexWrap:"wrap" }}>
                    <span style={{ color:"#f5a623", fontSize:"22px", fontWeight:"700", fontFamily:FONT_H }}>₹{tot.toFixed(2)}</span>

                    {/* Timer + cancel during 1-min window */}
                    {statusKey === "PLACED" && (
                      timerActive ? (
                        <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:"6px" }}>
                          <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                            {/* Countdown ring */}
                            <div style={{ position:"relative", width:"38px", height:"38px", flexShrink:0 }}>
                              <svg width="38" height="38" style={{ transform:"rotate(-90deg)" }}>
                                <circle cx="19" cy="19" r="15" fill="none" stroke="rgba(232,84,84,0.15)" strokeWidth="3"/>
                                <circle cx="19" cy="19" r="15" fill="none" stroke="#e85454" strokeWidth="3"
                                  strokeDasharray={`${2 * Math.PI * 15}`}
                                  strokeDashoffset={`${2 * Math.PI * 15 * (1 - countdown / CANCEL_WINDOW)}`}
                                  strokeLinecap="round" style={{ transition:"stroke-dashoffset 1s linear" }}
                                />
                              </svg>
                              <span style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", color:"#e85454", fontSize:"11px", fontWeight:"700" }}>{countdown}</span>
                            </div>
                            {canCancel && (
                              <button onClick={() => handleCancel(order.id)} style={{ background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.3)", color:"#e85454", padding:"7px 14px", borderRadius:"8px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
                                Cancel
                              </button>
                            )}
                          </div>
                          <span style={{ color:"#6b5e50", fontSize:"11px", fontStyle:"italic" }}>
                            Order will be confirmed when timer ends
                          </span>
                        </div>
                      ) : null // timer ended → both timer and text disappear, no cancel
                    )}

                    {/* View Bill button — red if denied, green if approved */}
                    {bill && (() => {
                      const isDenied = derivedBillStatus === "DENIED";
                      return (
                        <button onClick={() => setBillPopup({ bill, order })}
                          style={{ background:isDenied?"rgba(232,84,84,0.12)":"rgba(76,175,125,0.1)", border:isDenied?"1.5px solid rgba(232,84,84,0.4)":"1px solid rgba(76,175,125,0.3)", color:isDenied?"#e85454":"#4caf7d", padding:"7px 14px", borderRadius:"8px", fontSize:"13px", fontWeight:"700", cursor:"pointer", fontFamily:FONT }}>
                          {isDenied ? "❌ View Bill" : "🧾 View Bill"}
                        </button>
                      );
                    })()}
                  </div>
                </div>

                {/* Items */}
                {Array.isArray(order.items) && order.items.length > 0 && (
                  <div style={{ background:"#1e1a16", borderRadius:"10px", padding:"14px 16px", border:"1px solid rgba(255,220,120,0.06)" }}>
                    <div style={{ color:"#6b5e50", fontSize:"11px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"10px" }}>Items</div>
                    {order.items.map((it, idx) => (
                      <div key={idx} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"7px 0", borderBottom:idx<order.items.length-1?"1px solid rgba(255,220,120,0.05)":"none" }}>
                        <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
                          <span style={{ background:"rgba(245,166,35,0.1)", color:"#f5a623", width:"24px", height:"24px", borderRadius:"6px", display:"inline-flex", alignItems:"center", justifyContent:"center", fontSize:"12px", fontWeight:"700" }}>×{it.quantity||1}</span>
                          <div>
                            <div style={{ color:"#f5efe6", fontSize:"14px", fontWeight:"500" }}>{it.name||`Item #${it.menuItemId}`}</div>
                            {it.category && <div style={{ color:"#6b5e50", fontSize:"11px" }}>📂 {it.category}</div>}
                          </div>
                        </div>
                        <span style={{ color:"#f5a623", fontSize:"14px", fontWeight:"600" }}>₹{(parseFloat(it.price||0)*(it.quantity||1)).toFixed(2)}</span>
                      </div>
                    ))}
                    <div style={{ display:"flex", justifyContent:"flex-end", paddingTop:"10px", borderTop:"1px solid rgba(255,220,120,0.08)", marginTop:"6px" }}>
                      <span style={{ color:"#a89880", fontSize:"13px", fontWeight:"600", marginRight:"12px" }}>Total:</span>
                      <span style={{ color:"#f5a623", fontSize:"16px", fontWeight:"700", fontFamily:FONT_H }}>₹{tot.toFixed(2)}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default OrderPage;
