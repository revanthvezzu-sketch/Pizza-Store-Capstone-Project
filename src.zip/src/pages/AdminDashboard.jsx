import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllMenu, addMenuItem, deleteMenuItem, updateMenuItem, getAllCategories, addCategory, updateCategory, deleteCategory } from "../service/menu";
import { getAllOrders, updateOrderStatus, approveOrder, denyOrder, getAllBills, getAllDeliveryModes, addDeliveryMode, updateDeliveryMode, deleteDeliveryMode } from "../service/order";
import AdminNavbar from "../components/AdminNavbar";
import BillPopup from "../components/BillPopup";

const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";
const STATUS_OPTIONS = ["PREPARING","READY","DELIVERED","CANCELLED"];
const STATUS_COLORS  = {
  PLACED:    { bg:"rgba(245,166,35,0.12)",  color:"#f5a623",  border:"rgba(245,166,35,0.3)"  },
  PREPARING: { bg:"rgba(100,149,237,0.12)", color:"#6495ed",  border:"rgba(100,149,237,0.3)" },
  READY:     { bg:"rgba(76,175,125,0.12)",  color:"#4caf7d",  border:"rgba(76,175,125,0.3)"  },
  DELIVERED: { bg:"rgba(76,175,125,0.08)",  color:"#4caf7d",  border:"rgba(76,175,125,0.2)"  },
  APPROVED:  { bg:"rgba(76,175,125,0.15)",  color:"#4caf7d",  border:"rgba(76,175,125,0.4)"  },
  CANCELLED: { bg:"rgba(232,84,84,0.1)",    color:"#e85454",  border:"rgba(232,84,84,0.3)"   },
};
const BILL_STATUS_STYLE = {
  APPROVED: { bg:"rgba(76,175,125,0.12)", color:"#4caf7d", border:"rgba(76,175,125,0.3)", label:"Bill ✅ Approved" },
  DENIED:   { bg:"rgba(232,84,84,0.1)",   color:"#e85454", border:"rgba(232,84,84,0.3)",  label:"Bill ❌ Denied"  },
};

const getCatName = (item) => { if (!item.category) return "—"; if (typeof item.category==="string") return item.category; return item.category.name||"—"; };
const getTotal   = (o)    => parseFloat(o.totalAmount??o.total??0);

function AdminDashboard() {
  const [menu,           setMenu]          = useState([]);
  const [orders,         setOrders]        = useState([]);
  const [bills,          setBills]         = useState({}); // orderId → bill
  const [categories,     setCategories]    = useState([]);
  const [deliveryModes,  setDeliveryModes] = useState([]);
  const [loading,        setLoading]       = useState(true);
  const [activeTab,      setActiveTab]     = useState("overview");
  const [newItem,        setNewItem]       = useState({ name:"", price:"", categoryName:"", description:"" });
  const [newCat,         setNewCat]        = useState({ name:"", color:"#f5a623" });
  const [newMode,        setNewMode]       = useState({ name:"", description:"", active:true });
  const [editItem,       setEditItem]      = useState(null);
  const [editCat,        setEditCat]       = useState(null);
  const [editMode,       setEditMode]      = useState(null);
  const [focusedInput,   setFocusedInput]  = useState(null);
  const [statusUpdating, setStatusUpdating]= useState({});
  const [actionLoading,  setActionLoading] = useState({});
  const [billPopup,      setBillPopup]     = useState(null);
  const [orderSearch,    setOrderSearch]   = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    if (!localStorage.getItem("token") || localStorage.getItem("role") !== "Admin") { navigate("/login"); return; }
    fetchAll();
    // Poll orders + bills every 5s so new user orders appear immediately
    const pollInterval = setInterval(fetchOrdersAndBills, 5000);
    return () => clearInterval(pollInterval);
  }, []);

  // Full load (menu, categories, delivery modes too) — runs once on mount
  const fetchAll = async () => {
    setLoading(true);
    try {
      const [menuR, ordersR, catsR, modesR, billsR] = await Promise.allSettled([
        getAllMenu(), getAllOrders(), getAllCategories(), getAllDeliveryModes(), getAllBills()
      ]);
      if (menuR.status === "fulfilled")   setMenu(menuR.value.data);
      if (ordersR.status === "fulfilled") setOrders(ordersR.value.data);
      if (catsR.status === "fulfilled")   setCategories(catsR.value.data);
      if (modesR.status === "fulfilled")  setDeliveryModes(modesR.value.data);
      if (billsR.status === "fulfilled") {
        const billMap = {};
        billsR.value.data.forEach(b => { billMap[b.orderId] = b; });
        setBills(billMap);
      }
    } finally { setLoading(false); }
  };

  // Lightweight poll — only orders + bills, no loading spinner
  const fetchOrdersAndBills = async () => {
    try {
      const [ordersR, billsR] = await Promise.allSettled([getAllOrders(), getAllBills()]);
      if (ordersR.status === "fulfilled") setOrders(ordersR.value.data);
      if (billsR.status === "fulfilled") {
        const billMap = {};
        billsR.value.data.forEach(b => { billMap[b.orderId] = b; });
        setBills(billMap);
      }
    } catch {}
  };

  // Approve → order becomes PREPARING, bill APPROVED
  const handleApprove = async (order) => {
    setActionLoading(p => ({ ...p, [order.id]: "approving" }));
    try {
      const r = await approveOrder(order.id);
      setOrders(prev => prev.map(o => o.id === order.id ? { ...o, status:"PREPARING" } : o));
      if (r.data.bill) setBills(prev => ({ ...prev, [order.id]: r.data.bill }));
      if (r.data.bill) setBillPopup({ bill: r.data.bill, order: { ...order, status:"PREPARING" } });
    } catch(e) { console.error(e); }
    finally { setActionLoading(p => ({ ...p, [order.id]: null })); }
  };

  // Deny → order becomes CANCELLED, bill DENIED
  const handleDeny = async (order) => {
    if (!window.confirm("Deny this order? The order will be cancelled.")) return;
    setActionLoading(p => ({ ...p, [order.id]: "denying" }));
    try {
      const r = await denyOrder(order.id);
      setOrders(prev => prev.map(o => o.id === order.id ? { ...o, status:"CANCELLED" } : o));
      if (r.data.bill) setBills(prev => ({ ...prev, [order.id]: r.data.bill }));
    } catch(e) { console.error(e); }
    finally { setActionLoading(p => ({ ...p, [order.id]: null })); }
  };

  const handleStatusChange = async (orderId, newStatus) => {
    setStatusUpdating(p => ({ ...p, [orderId]: true }));
    try { await updateOrderStatus(orderId, newStatus); setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status:newStatus } : o)); }
    catch(e) { console.error(e); }
    finally { setStatusUpdating(p => ({ ...p, [orderId]: false })); }
  };

  // Category handlers
  const handleAddCategory    = async (e) => { e.preventDefault(); if (!newCat.name.trim()) return; try { await addCategory({name:newCat.name.trim(),color:newCat.color}); setNewCat({name:"",color:"#f5a623"}); const r=await getAllCategories(); setCategories(r.data); } catch(e){console.error(e);} };
  const handleEditCategory   = async (e) => { e.preventDefault(); try { await updateCategory(editCat.id,{name:editCat.name.trim(),color:editCat.color}); setEditCat(null); const r=await getAllCategories(); setCategories(r.data); const rm=await getAllMenu(); setMenu(rm.data); } catch(e){console.error(e);} };
  const handleDeleteCategory = async (id) => { if (!window.confirm("Delete category?")) return; try { await deleteCategory(id); const [rc,rm]=await Promise.all([getAllCategories(),getAllMenu()]); setCategories(rc.data); setMenu(rm.data); } catch(e){console.error(e);} };

  // Menu handlers
  const handleAddItem  = async (e) => { e.preventDefault(); try { await addMenuItem({...newItem,price:parseFloat(newItem.price)}); setNewItem({name:"",price:"",categoryName:"",description:""}); const [rm,rc]=await Promise.all([getAllMenu(),getAllCategories()]); setMenu(rm.data); setCategories(rc.data); } catch(e){console.error(e);} };
  const handleDelete   = async (id) => { if (!window.confirm("Delete this item?")) return; try { await deleteMenuItem(id); const r=await getAllMenu(); setMenu(r.data); } catch(e){console.error(e);} };
  const openEdit       = (item) => setEditItem({id:item.id,name:item.name,price:item.price,description:item.description||"",categoryName:getCatName(item)==="—"?"":getCatName(item)});
  const handleEditSave = async (e) => { e.preventDefault(); try { await updateMenuItem(editItem.id,{name:editItem.name,price:parseFloat(editItem.price),description:editItem.description,categoryName:editItem.categoryName}); setEditItem(null); const [rm,rc]=await Promise.all([getAllMenu(),getAllCategories()]); setMenu(rm.data); setCategories(rc.data); } catch(e){console.error(e);} };

  // Delivery mode handlers
  const handleAddMode    = async (e) => { e.preventDefault(); if (!newMode.name.trim()) return; try { await addDeliveryMode({...newMode}); setNewMode({name:"",description:"",active:true}); const r=await getAllDeliveryModes(); setDeliveryModes(r.data); } catch(e){console.error(e);} };
  const handleEditMode   = async (e) => { e.preventDefault(); try { await updateDeliveryMode(editMode.id,{name:editMode.name,description:editMode.description,active:editMode.active}); setEditMode(null); const r=await getAllDeliveryModes(); setDeliveryModes(r.data); } catch(e){console.error(e);} };
  const handleDeleteMode = async (id) => { if (!window.confirm("Delete this delivery mode?")) return; try { await deleteDeliveryMode(id); const r=await getAllDeliveryModes(); setDeliveryModes(r.data); } catch(e){console.error(e);} };

  // Grouping
  const groupedOrders = orders.reduce((acc, o) => {
    const key = o.username||"Unknown";
    if (!acc[key]) acc[key] = { username:key, email:o.userEmail||"", orders:[] };
    acc[key].orders.push(o);
    return acc;
  }, {});
  const filteredGroups = Object.values(groupedOrders).filter(g =>
    !orderSearch.trim() || g.username.toLowerCase().includes(orderSearch.toLowerCase())
  );

  // Stats
  // Count all bills EXCEPT explicitly denied (null/empty billStatus = old data = approved)
  const totalRevenue  = Object.values(bills).filter(b=>(b.billStatus||"").toUpperCase()!=="DENIED").reduce((s,b)=>s+parseFloat(b.grandTotal||0),0);
  const pendingOrders = orders.filter(o=>(o.status||"").toUpperCase()==="PLACED").length;
  const totalOrders   = orders.length;

  const stats = [
    { label:"Total Revenue", value:`₹${totalRevenue.toFixed(2)}`, icon:"💰", color:"#f5a623", clickable:true, onClick:()=>navigate("/admin/revenue") },
    { label:"Menu Items",    value:menu.length,                    icon:"🍕", color:"#6495ed" },
    { label:"Total Orders",  value:totalOrders,                    icon:"📋", color:"#4caf7d" },
    { label:"Pending",       value:pendingOrders,                  icon:"⏳", color:"#e8420a" },
  ];

  const inp = (name) => ({
    background:"#1e1a16", border:focusedInput===name?"1.5px solid #f5a623":"1.5px solid rgba(255,220,120,0.1)",
    boxShadow:focusedInput===name?"0 0 0 3px rgba(245,166,35,0.1)":"none",
    color:"#f5efe6", borderRadius:"9px", padding:"10px 14px", fontSize:"14px", fontFamily:FONT, outline:"none", flex:1, minWidth:"120px",
  });
  const thS = { color:"#6b5e50", fontSize:"12px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px" };
  const selStyle = (id) => ({ background:"#1e1a16", border:"1.5px solid rgba(245,166,35,0.25)", color:"#f5a623", borderRadius:"8px", padding:"6px 10px", fontSize:"13px", fontFamily:FONT, cursor:statusUpdating[id]?"wait":"pointer", outline:"none", opacity:statusUpdating[id]?0.6:1 });

  const renderOrderRow = (o, compact = false) => {
    const sc      = STATUS_COLORS[(o.status||"PLACED").toUpperCase()]||STATUS_COLORS.PLACED;
    const bill    = bills[o.id];
    const bs      = bill ? (BILL_STATUS_STYLE[(bill.billStatus||"").toUpperCase()] || null) : null;
    const loading = actionLoading[o.id];
    const st      = (o.status||"PLACED").toUpperCase();
    const billSt  = (bill?.billStatus||"").toUpperCase();
    // Bill APPROVED → show dropdown: READY, DELIVERED, CANCELLED
    const showDropdown  = billSt === "APPROVED";
    // Bill DENIED → locked CANCELLED, no dropdown
    const isDenied      = billSt === "DENIED";
    // No bill yet (PLACED) → show Approve/Deny buttons
    const showActions   = !bill && st === "PLACED";
    const dropdownOptions = ["READY","DELIVERED","CANCELLED"];

    return (
      <div key={o.id} style={{ background:"#252018", border:"1px solid rgba(255,220,120,0.05)", borderRadius:"12px", padding:"14px 16px", marginBottom: compact ? 0 : undefined }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:"10px", marginBottom:"10px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:"10px", flexWrap:"wrap" }}>
            <span style={{ fontFamily:FONT_H, fontSize:"15px", fontWeight:"700", color:"#f5efe6" }}>Order #{o.id}</span>
            {/* Order status */}
            <span style={{ background:sc.bg, color:sc.color, border:`1px solid ${sc.border}`, fontSize:"11px", fontWeight:"700", padding:"3px 10px", borderRadius:"99px" }}>
              {o.status||"PLACED"}
            </span>
            {/* Bill status */}
            {bs && (
              <span style={{ background:bs.bg, color:bs.color, border:`1px solid ${bs.border}`, fontSize:"11px", fontWeight:"700", padding:"3px 10px", borderRadius:"99px" }}>
                {bs.label}
              </span>
            )}
            {o.deliveryMode && (
              <span style={{ background:"rgba(100,149,237,0.1)", border:"1px solid rgba(100,149,237,0.25)", color:"#6495ed", fontSize:"11px", fontWeight:"600", padding:"3px 10px", borderRadius:"99px" }}>
                🚚 {o.deliveryMode}
              </span>
            )}
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:"10px", flexWrap:"wrap" }}>
            <span style={{ color:"#f5a623", fontSize:"18px", fontWeight:"700", fontFamily:FONT_H }}>₹{getTotal(o).toFixed(2)}</span>

            {/* Email */}
            {o.userEmail && <span style={{ color:"#6b5e50", fontSize:"11px" }}>📧 {o.userEmail}</span>}

            {/* Bill APPROVED → status dropdown: READY, DELIVERED, CANCELLED */}
            {showDropdown && (
              <select
                value=""
                onChange={e => { if (e.target.value) handleStatusChange(o.id, e.target.value); }}
                style={selStyle(o.id)}
                disabled={!!statusUpdating[o.id]}
              >
                <option value="" disabled>Select status</option>
                {dropdownOptions.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            )}

            {/* Bill DENIED → red locked badge */}
            {isDenied && (
              <span style={{ background:"rgba(232,84,84,0.12)", border:"1.5px solid rgba(232,84,84,0.4)", color:"#e85454", fontSize:"13px", fontWeight:"700", padding:"6px 14px", borderRadius:"8px", display:"flex", alignItems:"center", gap:"6px" }}>
                ❌ Order Denied
              </span>
            )}

            {/* No bill yet (PLACED) → Approve / Deny */}
            {showActions && (
              <>
                <button onClick={()=>handleApprove(o)} disabled={!!loading}
                  style={{ background:"rgba(76,175,125,0.15)", border:"1.5px solid rgba(76,175,125,0.4)", color:"#4caf7d", padding:"7px 14px", borderRadius:"8px", fontSize:"13px", fontWeight:"700", cursor:"pointer", fontFamily:FONT, opacity:loading?0.5:1 }}>
                  {loading==="approving" ? "…" : "✅ Approve"}
                </button>
                <button onClick={()=>handleDeny(o)} disabled={!!loading}
                  style={{ background:"rgba(232,84,84,0.1)", border:"1.5px solid rgba(232,84,84,0.4)", color:"#e85454", padding:"7px 14px", borderRadius:"8px", fontSize:"13px", fontWeight:"700", cursor:"pointer", fontFamily:FONT, opacity:loading?0.5:1 }}>
                  {loading==="denying" ? "…" : "❌ Deny"}
                </button>
              </>
            )}

            {/* View bill */}
            {bill && (
              <button onClick={()=>setBillPopup({ bill, order: o })}
                style={{ background:"rgba(100,149,237,0.1)", border:"1px solid rgba(100,149,237,0.3)", color:"#6495ed", padding:"7px 14px", borderRadius:"8px", fontSize:"12px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
                🧾 Bill
              </button>
            )}
          </div>
        </div>

        {/* Items */}
        {Array.isArray(o.items) && o.items.length > 0 && (
          <div style={{ background:"#1e1a16", borderRadius:"8px", padding:"10px 12px" }}>
            {o.items.map((it,idx)=>(
              <div key={idx} style={{ display:"flex", justifyContent:"space-between", padding:"5px 0", borderBottom:idx<o.items.length-1?"1px solid rgba(255,220,120,0.04)":"none" }}>
                <div>
                  <span style={{ color:"#a89880", fontSize:"12px" }}>×{it.quantity||1} {it.name}</span>
                  {it.category && <span style={{ color:"#6b5e50", fontSize:"11px", marginLeft:"8px" }}>📂{it.category}</span>}
                </div>
                <span style={{ color:"#f5a623", fontSize:"12px" }}>₹{(parseFloat(it.price||0)*(it.quantity||1)).toFixed(2)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div style={{ minHeight:"100vh", background:"#0e0c0a", fontFamily:FONT }}>
      <AdminNavbar />
      {billPopup && <BillPopup bill={billPopup.bill} order={billPopup.order} onClose={()=>setBillPopup(null)} />}

      <div style={{ padding:"36px 40px 24px", borderBottom:"1px solid rgba(245,166,35,0.06)", marginBottom:"28px" }}>
        <h1 style={{ fontFamily:FONT_H, fontSize:"36px", fontWeight:"900", color:"#f5efe6" }}>Admin Dashboard</h1>
        <p style={{ color:"#6b5e50", fontSize:"14px", marginTop:"4px" }}>Manage your pizzeria</p>
      </div>

      <div style={{ padding:"0 40px", display:"flex", gap:"4px", marginBottom:"28px", flexWrap:"wrap" }}>
        {["overview","menu","orders","delivery"].map(t => (
          <button key={t} onClick={()=>setActiveTab(t)} style={{ background:activeTab===t?"rgba(245,166,35,0.1)":"transparent", border:"none", color:activeTab===t?"#f5a623":"#6b5e50", padding:"10px 22px", borderRadius:"9px", fontSize:"14px", fontWeight:"500", cursor:"pointer", fontFamily:FONT }}>
            {t === "delivery" ? "🚚 Delivery" : t.charAt(0).toUpperCase()+t.slice(1)}
          </button>
        ))}
      </div>

      {loading && <div style={{ width:"36px", height:"36px", border:"3px solid rgba(255,220,120,0.1)", borderTopColor:"#f5a623", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"60px auto" }} />}

      {/* ── OVERVIEW ── */}
      {!loading && activeTab==="overview" && (
        <div style={{ padding:"0 40px 60px" }}>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))", gap:"16px", marginBottom:"36px" }}>
            {stats.map((s,i) => (
              <div key={s.label} onClick={s.onClick} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"14px", padding:"24px", textAlign:"center", animation:`fadeUp 0.4s ease ${i*0.07}s both`, cursor:s.clickable?"pointer":"default", transition:"border-color 0.2s, transform 0.2s" }}
                onMouseEnter={e=>{ if(s.clickable){ e.currentTarget.style.borderColor="rgba(245,166,35,0.4)"; e.currentTarget.style.transform="translateY(-3px)"; } }}
                onMouseLeave={e=>{ e.currentTarget.style.borderColor="rgba(255,220,120,0.08)"; e.currentTarget.style.transform="none"; }}>
                <div style={{ fontSize:"32px", marginBottom:"12px" }}>{s.icon}</div>
                <div style={{ fontSize:"28px", fontWeight:"700", fontFamily:FONT_H, color:s.color, marginBottom:"6px" }}>{s.value}</div>
                <div style={{ color:"#6b5e50", fontSize:"12px", textTransform:"uppercase", letterSpacing:"0.5px", fontWeight:"500" }}>{s.label}</div>
                {s.clickable && <div style={{ color:"#f5a623", fontSize:"11px", marginTop:"6px", opacity:0.7 }}>Click to view →</div>}
              </div>
            ))}
          </div>

          <h2 style={{ fontFamily:FONT_H, fontSize:"22px", fontWeight:"700", color:"#f5efe6", marginBottom:"16px" }}>Recent Orders</h2>
          <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
            {orders.slice(0,8).map(o => renderOrderRow(o, true))}
          </div>
        </div>
      )}

      {/* ── MENU ── */}
      {!loading && activeTab==="menu" && (
        <div style={{ padding:"0 40px 60px" }}>
          {/* Categories */}
          <div style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"14px", padding:"20px 24px", marginBottom:"16px" }}>
            <h3 style={{ fontFamily:FONT_H, fontSize:"16px", color:"#f5efe6", marginBottom:"14px" }}>Categories</h3>
            <form onSubmit={handleAddCategory} style={{ display:"flex", gap:"12px", alignItems:"center", flexWrap:"wrap" }}>
              <input placeholder="Category name" value={newCat.name} required onChange={e=>setNewCat({...newCat,name:e.target.value})} onFocus={()=>setFocusedInput("cn")} onBlur={()=>setFocusedInput(null)} style={{ ...inp("cn"), maxWidth:"240px" }} />
              <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                <label style={{ color:"#a89880", fontSize:"12px", fontWeight:"600" }}>Color:</label>
                <input type="color" value={newCat.color} onChange={e=>setNewCat({...newCat,color:e.target.value})} style={{ width:"40px", height:"36px", border:"1.5px solid rgba(255,220,120,0.2)", borderRadius:"8px", background:"#1e1a16", cursor:"pointer", padding:"2px" }} />
                <span style={{ color:newCat.color, fontSize:"13px", fontWeight:"600" }}>{newCat.color}</span>
              </div>
              <button type="submit" style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"11px 22px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT, flexShrink:0 }}>+ Add</button>
            </form>
            {categories.length > 0 && (
              <div style={{ display:"flex", flexWrap:"wrap", gap:"8px", marginTop:"14px" }}>
                {categories.map(c => { const cc=c.color||"#f5a623"; return (
                  <div key={c.id} style={{ background:cc+"18", border:`1.5px solid ${cc}55`, borderRadius:"99px", padding:"5px 6px 5px 14px", display:"inline-flex", alignItems:"center", gap:"6px" }}>
                    <span style={{ width:"8px", height:"8px", borderRadius:"50%", background:cc, flexShrink:0 }}/>
                    <span style={{ color:cc, fontSize:"13px", fontWeight:"600" }}>{c.name}</span>
                    <button onClick={()=>setEditCat({id:c.id,name:c.name,color:c.color||"#f5a623"})} style={{ background:cc+"33", border:"none", color:cc, borderRadius:"99px", padding:"2px 9px", fontSize:"11px", fontWeight:"700", cursor:"pointer", fontFamily:FONT, marginLeft:"2px" }}>Edit</button>
                    <button onClick={()=>handleDeleteCategory(c.id)} style={{ background:"rgba(232,84,84,0.15)", border:"none", color:"#e85454", borderRadius:"99px", padding:"2px 9px", fontSize:"11px", fontWeight:"700", cursor:"pointer", fontFamily:FONT }}>✕</button>
                  </div>
                ); })}
              </div>
            )}
          </div>

          {/* Add Item */}
          <div style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"14px", padding:"20px 24px", marginBottom:"28px" }}>
            <h3 style={{ fontFamily:FONT_H, fontSize:"16px", color:"#f5efe6", marginBottom:"14px" }}>Add Menu Item</h3>
            <form onSubmit={handleAddItem} style={{ display:"flex", gap:"12px", flexWrap:"wrap", alignItems:"flex-end" }}>
              <input placeholder="Item name *" value={newItem.name} required onChange={e=>setNewItem({...newItem,name:e.target.value})} onFocus={()=>setFocusedInput("in")} onBlur={()=>setFocusedInput(null)} style={inp("in")} />
              <input placeholder="Price *" type="number" step="0.01" min="0" value={newItem.price} required onChange={e=>setNewItem({...newItem,price:e.target.value})} onFocus={()=>setFocusedInput("ip")} onBlur={()=>setFocusedInput(null)} style={inp("ip")} />
              <select value={newItem.categoryName} onChange={e=>setNewItem({...newItem,categoryName:e.target.value})} style={{ ...inp("ic"), cursor:"pointer" }}>
                <option value="">-- Category --</option>
                {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
              </select>
              <input placeholder="Description" value={newItem.description} onChange={e=>setNewItem({...newItem,description:e.target.value})} onFocus={()=>setFocusedInput("id")} onBlur={()=>setFocusedInput(null)} style={inp("id")} />
              <button type="submit" style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"11px 24px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT, flexShrink:0 }}>+ Add</button>
            </form>
          </div>

          <h2 style={{ fontFamily:FONT_H, fontSize:"22px", fontWeight:"700", color:"#f5efe6", marginBottom:"16px" }}>All Items ({menu.length})</h2>
          <div style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"14px", overflow:"hidden" }}>
            <div style={{ display:"grid", gridTemplateColumns:"1.5fr 1fr 0.8fr 1.5fr auto", padding:"14px 20px", background:"#1e1a16", borderBottom:"1px solid rgba(255,220,120,0.08)", gap:"16px" }}>
              {["Name","Category","Price","Description","Actions"].map(h=><span key={h} style={thS}>{h}</span>)}
            </div>
            {menu.map(item => (
              <div key={item.id} style={{ display:"grid", gridTemplateColumns:"1.5fr 1fr 0.8fr 1.5fr auto", padding:"14px 20px", borderBottom:"1px solid rgba(255,220,120,0.04)", gap:"16px", alignItems:"center" }}>
                <span style={{ color:"#f5efe6", fontWeight:"600" }}>{item.name}</span>
                <span style={{ color:"#a89880", fontSize:"13px" }}>{getCatName(item)}</span>
                <span style={{ color:"#f5a623", fontWeight:"700" }}>₹{parseFloat(item.price).toFixed(2)}</span>
                <span style={{ color:"#6b5e50", fontSize:"12px" }}>{item.description||"—"}</span>
                <div style={{ display:"flex", gap:"8px" }}>
                  <button onClick={()=>openEdit(item)} style={{ background:"rgba(245,166,35,0.1)", border:"1px solid rgba(245,166,35,0.25)", color:"#f5a623", padding:"6px 12px", borderRadius:"7px", fontSize:"12px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>✏️</button>
                  <button onClick={()=>handleDelete(item.id)} style={{ background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.25)", color:"#e85454", padding:"6px 12px", borderRadius:"7px", fontSize:"12px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>🗑</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── ORDERS ── */}
      {!loading && activeTab==="orders" && (
        <div style={{ padding:"0 40px 60px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"24px", flexWrap:"wrap", gap:"16px" }}>
            <div style={{ background:"linear-gradient(135deg,rgba(245,166,35,0.15),rgba(232,66,10,0.1))", border:"1px solid rgba(245,166,35,0.2)", borderRadius:"14px", padding:"16px 24px", display:"flex", alignItems:"center", gap:"16px", cursor:"pointer" }} onClick={()=>navigate("/admin/revenue")}>
              <span style={{ fontSize:"36px" }}>💰</span>
              <div>
                <div style={{ color:"#a89880", fontSize:"11px", textTransform:"uppercase", letterSpacing:"1px" }}>Total Revenue</div>
                <div style={{ color:"#f5a623", fontSize:"28px", fontWeight:"700", fontFamily:FONT_H }}>₹{totalRevenue.toFixed(2)}</div>
                <div style={{ color:"#f5a623", fontSize:"11px", opacity:0.7, marginTop:"2px" }}>Click for analytics →</div>
              </div>
            </div>
            <div style={{ display:"flex", gap:"12px", alignItems:"center" }}>
              <div style={{ background:"rgba(100,149,237,0.1)", border:"1px solid rgba(100,149,237,0.2)", borderRadius:"10px", padding:"10px 18px", textAlign:"center" }}>
                <div style={{ color:"#6b5e50", fontSize:"11px" }}>TOTAL ORDERS</div>
                <div style={{ color:"#6495ed", fontSize:"20px", fontWeight:"700" }}>{totalOrders}</div>
              </div>
              <input placeholder="🔍 Search by username..." value={orderSearch} onChange={e=>setOrderSearch(e.target.value)}
                onFocus={()=>setFocusedInput("os")} onBlur={()=>setFocusedInput(null)}
                style={{ ...inp("os"), maxWidth:"280px", flex:"unset", minWidth:"unset" }} />
            </div>
          </div>

          {filteredGroups.length === 0 && (
            <div style={{ textAlign:"center", color:"#6b5e50", padding:"60px" }}>
              <div style={{ fontSize:"48px", marginBottom:"12px" }}>📋</div>
              <p>{orderSearch ? `No customer found matching "${orderSearch}"` : "No orders yet"}</p>
            </div>
          )}
           
          <div style={{ display:"flex", flexDirection:"column", gap:"20px" }}>
            {filteredGroups.map((group, gi) => {
              const groupTotal = group.orders.reduce((s,o)=>s+getTotal(o),0);
              return (
                <div key={group.username} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"16px", overflow:"hidden", animation:`fadeUp 0.4s ease ${gi*0.05}s both` }}>
                  <div style={{ background:"#1e1a16", borderBottom:"1px solid rgba(255,220,120,0.06)", padding:"16px 22px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:"12px" }}>
                      <div style={{ width:"40px", height:"40px", background:"rgba(245,166,35,0.12)", border:"1px solid rgba(245,166,35,0.25)", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"18px" }}>👤</div>
                      <div>
                        <div style={{ color:"#f5efe6", fontWeight:"700", fontSize:"16px" }}>Customer: {group.username}</div>
                        <div style={{ color:"#6b5e50", fontSize:"12px", marginTop:"2px" }}>
                          {group.email && <span>📧 {group.email} • </span>}
                          {group.orders.length} order{group.orders.length!==1?"s":""}
                        </div>
                      </div>
                    </div>
                    <div style={{ textAlign:"right" }}>
                      <div style={{ color:"#6b5e50", fontSize:"11px", textTransform:"uppercase", letterSpacing:"0.5px" }}>Total Spent</div>
                      <div style={{ color:"#f5a623", fontSize:"18px", fontWeight:"700", fontFamily:FONT_H }}>₹{groupTotal.toFixed(2)}</div>
                    </div>
                  </div>
                  <div style={{ padding:"14px 22px", display:"flex", flexDirection:"column", gap:"10px" }}>
                    {group.orders.map(o => renderOrderRow(o))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── DELIVERY ── */}
      {!loading && activeTab==="delivery" && (
        <div style={{ padding:"0 40px 60px" }}>
          <div style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"14px", padding:"24px", marginBottom:"24px" }}>
            <h3 style={{ fontFamily:FONT_H, fontSize:"18px", color:"#f5efe6", marginBottom:"16px" }}>Add Delivery Mode</h3>
            <form onSubmit={handleAddMode} style={{ display:"flex", gap:"12px", flexWrap:"wrap", alignItems:"flex-end" }}>
              <input placeholder="Mode name *" value={newMode.name} required onChange={e=>setNewMode({...newMode,name:e.target.value})} onFocus={()=>setFocusedInput("mn")} onBlur={()=>setFocusedInput(null)} style={inp("mn")} />
              <input placeholder="Description" value={newMode.description} onChange={e=>setNewMode({...newMode,description:e.target.value})} onFocus={()=>setFocusedInput("md")} onBlur={()=>setFocusedInput(null)} style={inp("md")} />
              <label style={{ display:"flex", alignItems:"center", gap:"8px", color:"#a89880", fontSize:"14px", cursor:"pointer" }}>
                <input type="checkbox" checked={newMode.active} onChange={e=>setNewMode({...newMode,active:e.target.checked})} /> Active
              </label>
              <button type="submit" style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"11px 24px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT, flexShrink:0 }}>+ Add Mode</button>
            </form>
          </div>
          <h2 style={{ fontFamily:FONT_H, fontSize:"22px", fontWeight:"700", color:"#f5efe6", marginBottom:"16px" }}>Delivery Modes ({deliveryModes.length})</h2>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))", gap:"14px" }}>
            {deliveryModes.map((dm,i) => (
              <div key={dm.id} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.08)", borderRadius:"14px", padding:"18px 20px", display:"flex", flexDirection:"column", gap:"10px", animation:`fadeUp 0.4s ease ${i*0.06}s both` }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                  <div>
                    <div style={{ color:"#f5efe6", fontWeight:"700", fontSize:"15px" }}>🚚 {dm.name}</div>
                    {dm.description && <div style={{ color:"#6b5e50", fontSize:"12px", marginTop:"3px" }}>{dm.description}</div>}
                  </div>
                  <span style={{ background:dm.active?"rgba(76,175,125,0.12)":"rgba(232,84,84,0.1)", border:dm.active?"1px solid rgba(76,175,125,0.3)":"1px solid rgba(232,84,84,0.3)", color:dm.active?"#4caf7d":"#e85454", fontSize:"11px", fontWeight:"700", padding:"3px 10px", borderRadius:"99px" }}>
                    {dm.active?"Active":"Inactive"}
                  </span>
                </div>
                <div style={{ display:"flex", gap:"8px" }}>
                  <button onClick={()=>setEditMode({id:dm.id,name:dm.name,description:dm.description||"",active:dm.active})} style={{ flex:1, background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"9px", borderRadius:"8px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>✏️ Edit</button>
                  <button onClick={()=>handleDeleteMode(dm.id)} style={{ flex:1, background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.3)", color:"#e85454", padding:"9px", borderRadius:"8px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>🗑 Delete</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modals */}
      {editCat && (
        <div onClick={()=>setEditCat(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(4px)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.12)", borderRadius:"18px", padding:"32px", width:"100%", maxWidth:"400px" }}>
            <h2 style={{ fontFamily:FONT_H, fontSize:"22px", color:"#f5efe6", marginBottom:"22px" }}>Edit Category</h2>
            <form onSubmit={handleEditCategory} style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
              <input value={editCat.name} required onChange={e=>setEditCat({...editCat,name:e.target.value})} onFocus={()=>setFocusedInput("ecn")} onBlur={()=>setFocusedInput(null)} style={{ ...inp("ecn"), minWidth:"unset", flex:"unset", width:"100%", boxSizing:"border-box" }} />
              <div style={{ display:"flex", alignItems:"center", gap:"12px" }}>
                <input type="color" value={editCat.color} onChange={e=>setEditCat({...editCat,color:e.target.value})} style={{ width:"52px", height:"44px", border:"1.5px solid rgba(255,220,120,0.2)", borderRadius:"10px", background:"#1e1a16", cursor:"pointer", padding:"3px" }} />
                <span style={{ color:editCat.color, fontWeight:"600" }}>{editCat.color}</span>
              </div>
              <div style={{ display:"flex", gap:"10px" }}>
                <button type="button" onClick={()=>setEditCat(null)} style={{ flex:1, background:"transparent", border:"1.5px solid rgba(255,220,120,0.15)", color:"#a89880", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Cancel</button>
                <button type="submit" style={{ flex:2, background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {editItem && (
        <div onClick={()=>setEditItem(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(4px)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.12)", borderRadius:"18px", padding:"32px", width:"100%", maxWidth:"460px" }}>
            <h2 style={{ fontFamily:FONT_H, fontSize:"22px", color:"#f5efe6", marginBottom:"22px" }}>Edit Item</h2>
            <form onSubmit={handleEditSave} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
              {[{n:"en",label:"Item Name",key:"name",type:"text"},{n:"ep",label:"Price",key:"price",type:"number"},{n:"ed",label:"Description",key:"description",type:"text"}].map(f=>(
                <div key={f.n}>
                  <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>{f.label}</label>
                  <input type={f.type} value={editItem[f.key]||""} required={["en","ep"].includes(f.n)} onChange={e=>setEditItem({...editItem,[f.key]:e.target.value})} onFocus={()=>setFocusedInput(f.n)} onBlur={()=>setFocusedInput(null)} style={{ ...inp(f.n), minWidth:"unset", flex:"unset", width:"100%", boxSizing:"border-box" }} />
                </div>
              ))}
              <div>
                <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Category</label>
                <select value={editItem.categoryName} onChange={e=>setEditItem({...editItem,categoryName:e.target.value})} style={{ ...inp("ec"), minWidth:"unset", flex:"unset", width:"100%", boxSizing:"border-box", cursor:"pointer" }}>
                  <option value="">-- Category --</option>
                  {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
              </div>
              <div style={{ display:"flex", gap:"10px", marginTop:"6px" }}>
                <button type="button" onClick={()=>setEditItem(null)} style={{ flex:1, background:"transparent", border:"1.5px solid rgba(255,220,120,0.15)", color:"#a89880", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Cancel</button>
                <button type="submit" style={{ flex:2, background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {editMode && (
        <div onClick={()=>setEditMode(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(4px)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#161410", border:"1px solid rgba(255,220,120,0.12)", borderRadius:"18px", padding:"32px", width:"100%", maxWidth:"420px" }}>
            <h2 style={{ fontFamily:FONT_H, fontSize:"22px", color:"#f5efe6", marginBottom:"22px" }}>Edit Delivery Mode</h2>
            <form onSubmit={handleEditMode} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
              <div>
                <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Mode Name</label>
                <input value={editMode.name} required onChange={e=>setEditMode({...editMode,name:e.target.value})} onFocus={()=>setFocusedInput("emn")} onBlur={()=>setFocusedInput(null)} style={{ ...inp("emn"), minWidth:"unset", flex:"unset", width:"100%", boxSizing:"border-box" }} />
              </div>
              <div>
                <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"#a89880", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Description</label>
                <input value={editMode.description} onChange={e=>setEditMode({...editMode,description:e.target.value})} onFocus={()=>setFocusedInput("emd")} onBlur={()=>setFocusedInput(null)} style={{ ...inp("emd"), minWidth:"unset", flex:"unset", width:"100%", boxSizing:"border-box" }} />
              </div>
              <label style={{ display:"flex", alignItems:"center", gap:"10px", color:"#a89880", fontSize:"14px", cursor:"pointer" }}>
                <input type="checkbox" checked={editMode.active} onChange={e=>setEditMode({...editMode,active:e.target.checked})} />
                Active (shown to users)
              </label>
              <div style={{ display:"flex", gap:"10px", marginTop:"4px" }}>
                <button type="button" onClick={()=>setEditMode(null)} style={{ flex:1, background:"transparent", border:"1.5px solid rgba(255,220,120,0.15)", color:"#a89880", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Cancel</button>
                <button type="submit" style={{ flex:2, background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
export default AdminDashboard;
