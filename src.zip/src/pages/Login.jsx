import { useState } from "react";
import { loginUser, registerUser } from "../service/auth";
import { useNavigate } from "react-router-dom";

const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";

function Login() {
  const navigate = useNavigate();
  const [page,         setPage]         = useState("select");
  const [role,         setRole]         = useState("");
  const [username,     setUsername]     = useState("");
  const [password,     setPassword]     = useState("");
  const [email,        setEmail]        = useState("");
  const [lastName,     setLastName]     = useState("");   
  const [loading,      setLoading]      = useState(false);
  const [error,        setError]        = useState("");
  const [focusedInput, setFocusedInput] = useState(null);
  const [hoveredRole,  setHoveredRole]  = useState(null);

  const resetFields = () => {
    setUsername(""); setPassword(""); setEmail("");
    setLastName("");                                      
    setError("");
  };

  // ── LOGIN ──────────────────────────────────────────────────────────────────
  const handleLogin = async (e) => {
    e.preventDefault(); setError(""); setLoading(true);
    try {
      const res = await loginUser({ username, password });

      //  Backend now returns an object { token, userId, username, email, role }
      const { token, userId, username: uname, email: uEmail, role: uRole } = res.data;

      const tokenRole = (uRole || "").toLowerCase();

      if (tokenRole) {
        if (role === "Admin" && tokenRole !== "admin") {
          setError("This account is not an admin account."); setLoading(false); return;
        }
        if (role === "User" && tokenRole === "admin") {
          setError("Admin accounts must use the Admin login."); setLoading(false); return;
        }
      }

      const resolvedRole = tokenRole === "admin" ? "Admin" : "User";

      //  Store all useful fields from response — no lastName (hidden by backend)
      localStorage.setItem("token",     token);
      localStorage.setItem("role",      resolvedRole);
      localStorage.setItem("username",  uname || username);
      localStorage.setItem("userId",    userId);
      if (uEmail) localStorage.setItem("userEmail", uEmail);

      navigate(resolvedRole === "Admin" ? "/admin" : "/menu");
    } catch (err) {
      const msg = err?.response?.data?.message;
      setError(msg || "Login failed. Check your credentials.");
    } finally {
      setLoading(false);
    }
  };

  // ── REGISTER ───────────────────────────────────────────────────────────────
  const handleRegister = async (e) => {
    e.preventDefault(); setError(""); setLoading(true);
    try {
      // ✅ lastName sent to backend — stored in DB, never comes back in response
      await registerUser({
        username,
        password,
        email,
        lastName,                                         // ✅ included
        role: role.toLowerCase(),
      });
      setPage("login"); resetFields();
    } catch (err) {
      const msg = err?.response?.data?.message;
      setError(msg || "Registration failed. Username may already exist.");
    } finally {
      setLoading(false);
    }
  };

  // ── STYLES ─────────────────────────────────────────────────────────────────
  const inp = (name) => ({
background: "#f8f5f2"
    border: focusedInput === name
      ? "1.5px solid #f5a623"
      : "1.5px solid rgba(255,220,120,0.12)",
    boxShadow: focusedInput === name
      ? "0 0 0 3px rgba(245,166,35,0.12)"
      : "none",
color: "#1f1b17", borderRadius: "9px", padding: "12px 16px",\n    fontSize: "14px", fontFamily: FONT, outline: "none", width: "100%",\n    transition: "border-color 0.2s, box-shadow 0.2s", boxSizing: "border-box",\n  });

  // ── RENDER ─────────────────────────────────────────────────────────────────
  return (
background: "#faf9f7"
      <div style={{inset: 0, background: "radial-gradient(ellipse at 20% 50%, rgba(245,166,35,0.06) 0%,transparent 60%), radial-gradient(ellipse at 80% 20%, rgba(232,66,10,0.05) 0%,transparent 50%)", pointerEvents: "none" }} />

      {/* ── Left brand panel ── */}
      <div style={{ flex: 1, display: "flex", alignItems: "center", padding: "60px", borderRight: "1px solid rgba(245,166,35,0.08)" }}>
        <div style={{ maxWidth: "400px" }}>
          <span style={{ fontSize: "54px", marginBottom: "28px", display: "block" }}>🍕</span>
  <h1 style={{ fontFamily: FONT_H, fontSize: "46px", fontWeight: "900", lineHeight: "1.1", color: "#1f1b17", marginBottom: "16px" }}>\n            Craft Pizza,<br />Delivered Hot.\n          </h1>
          <p style={{ color: "#a89880", fontSize: "16px", lineHeight: "1.7", marginBottom: "36px" }}>
            Artisan ingredients. Bold flavors. Right to your door.
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            {["Fresh daily dough", "Premium toppings", "30-min delivery", "Real-time tracking"].map(f => (
              <div key={f} style={{ display: "flex", alignItems: "center", gap: "12px", color: "#a89880", fontSize: "14px" }}>
                <span style={{ width: "6px", height: "6px", background: "#f5a623", borderRadius: "50%", flexShrink: 0, display: "block" }} />
                {f}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Right form panel ── */}
      <div style={{ width: "1000px", display: "flex", alignItems: "center", justifyContent: "center", padding: "40px" }}>
background: "#ffffff"

          {/* ── Role selection ── */}
          {page === "select" && (
            <div>
<h2 style={{ fontFamily: FONT_H, fontSize: "28px", fontWeight: "700", color: "#1f1b17", marginBottom: "6px" }}>Welcome Back</h2>
              <p style={{ color: "#6b5e50", fontSize: "14px", marginBottom: "28px" }}>How would you like to continue?</p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                {[{ id: "User", icon: "👤", desc: "Browse menu & order" }, { id: "Admin", icon: "🛡️", desc: "Manage everything" }].map(r => (
                  <div key={r.id}
                    onMouseEnter={() => setHoveredRole(r.id)}
                    onMouseLeave={() => setHoveredRole(null)}
                    onClick={() => { setRole(r.id); setPage("login"); resetFields(); }}
                    style={{ background: hoveredRole === r.id ? "rgba(245,166,35,0.08)" : "#1e1a16", border: hoveredRole === r.id ? "1.5px solid rgba(245,166,35,0.4)" : "1.5px solid rgba(255,220,120,0.1)", borderRadius: "14px", padding: "22px 16px", cursor: "pointer", textAlign: "center", transition: "all 0.2s" }}>
                    <span style={{ fontSize: "32px", display: "block", marginBottom: "10px" }}>{r.icon}</span>
                    <span style={{ color: "#f5efe6", fontWeight: "600", fontSize: "15px", display: "block", marginBottom: "5px" }}>{r.id}</span>
                    <span style={{ color: "#6b5e50", fontSize: "12px" }}>{r.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── Login form ── */}
          {page === "login" && (
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "24px" }}>
                <button onClick={() => { setPage("select"); resetFields(); }} style={{ background: "none", border: "none", color: "#6b5e50", cursor: "pointer", fontSize: "18px", padding: "0" }}>←</button>
                <div>
  <h2 style={{ fontFamily: FONT_H, fontSize: "24px", fontWeight: "700", color: "#1f1b17", margin: 0 }}>\n                    {role === "Admin" ? "🛡️" : "👤"} Sign in as {role}\n                  </h2>
                  <p style={{ color: "#6b5e50", fontSize: "13px", margin: 0, marginTop: "2px" }}>Enter your credentials</p>
                </div>
              </div>

              {error && (
                <div style={{ background: "rgba(232,84,84,0.1)", border: "1px solid rgba(232,84,84,0.3)", color: "#e85454", padding: "10px 14px", borderRadius: "8px", fontSize: "13px", marginBottom: "16px" }}>
                  {error}
                </div>
              )}

              <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                <input
                  placeholder="Username" value={username} required
                  onChange={e => setUsername(e.target.value)}
                  onFocus={() => setFocusedInput("lu")} onBlur={() => setFocusedInput(null)}
                  style={inp("lu")} />
                <input
                  placeholder="Password" type="password" value={password} required
                  onChange={e => setPassword(e.target.value)}
                  onFocus={() => setFocusedInput("lp")} onBlur={() => setFocusedInput(null)}
                  style={inp("lp")} />
                <button type="submit" disabled={loading}
                  style={{ background: "linear-gradient(135deg,#f5a623,#e8420a)", border: "none", color: "#fff", padding: "13px", borderRadius: "10px", fontSize: "15px", fontWeight: "700", cursor: "pointer", fontFamily: FONT, opacity: loading ? 0.7 : 1 }}>
                  {loading ? "Signing in…" : "Sign In"}
                </button>
              </form>

              <p style={{ color: "#6b5e50", fontSize: "13px", textAlign: "center", marginTop: "16px" }}>
                No account?{" "}
                <span onClick={() => { setPage("register"); resetFields(); }} style={{ color: "#f5a623", cursor: "pointer", fontWeight: "600" }}>Register</span>
              </p>
            </div>
          )}

          {/* ── Register form ── */}
          {page === "register" && (
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "24px" }}>
                <button onClick={() => { setPage("login"); resetFields(); }} style={{ background: "none", border: "none", color: "#6b5e50", cursor: "pointer", fontSize: "18px", padding: "0" }}>←</button>
                <div>
  <h2 style={{ fontFamily: FONT_H, fontSize: "24px", fontWeight: "700", color: "#1f1b17", margin: 0 }}>\n                    {role === "Admin" ? "🛡️" : "👤"} Register as {role}\n                  </h2>
                  <p style={{ color: "#6b5e50", fontSize: "13px", margin: 0, marginTop: "2px" }}>Create a new {role.toLowerCase()} account</p>
                </div>
              </div>

              {error && (
                <div style={{ background: "rgba(232,84,84,0.1)", border: "1px solid rgba(232,84,84,0.3)", color: "#e85454", padding: "10px 14px", borderRadius: "8px", fontSize: "13px", marginBottom: "16px" }}>
                  {error}
                </div>
              )}

              <form onSubmit={handleRegister} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                <input
                  placeholder="Username" value={username} required
                  onChange={e => setUsername(e.target.value)}
                  onFocus={() => setFocusedInput("ru")} onBlur={() => setFocusedInput(null)}
                  style={inp("ru")} />

                {/* ✅ Last Name field — sent to backend, stored in DB, never returned */}
                <input
                  placeholder="Last Name" value={lastName}
                  onChange={e => setLastName(e.target.value)}
                  onFocus={() => setFocusedInput("rl")} onBlur={() => setFocusedInput(null)}
                  style={inp("rl")} />

                <input
                  placeholder="Email" type="email" value={email} required
                  onChange={e => setEmail(e.target.value)}
                  onFocus={() => setFocusedInput("re")} onBlur={() => setFocusedInput(null)}
                  style={inp("re")} />
                <input
                  placeholder="Password" type="password" value={password} required
                  onChange={e => setPassword(e.target.value)}
                  onFocus={() => setFocusedInput("rp")} onBlur={() => setFocusedInput(null)}
                  style={inp("rp")} />

                <button type="submit" disabled={loading}
                  style={{ background: "linear-gradient(135deg,#f5a623,#e8420a)", border: "none", color: "#fff", padding: "13px", borderRadius: "10px", fontSize: "15px", fontWeight: "700", cursor: "pointer", fontFamily: FONT, opacity: loading ? 0.7 : 1 }}>
                  {loading ? "Creating…" : `Create ${role} Account`}
                </button>
              </form>

              <p style={{ color: "#6b5e50", fontSize: "13px", textAlign: "center", marginTop: "16px" }}>
                Already have an account?{" "}
                <span onClick={() => { setPage("login"); resetFields(); }} style={{ color: "#f5a623", cursor: "pointer", fontWeight: "600" }}>Sign in</span>
              </p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

export default Login;




// import { useState } from "react";
// import { loginUser, registerUser } from "../service/auth";
// import { useNavigate } from "react-router-dom";

// const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
// const FONT_H = "Georgia,'Times New Roman',serif";

// function decodeJwt(token) {
//   try {
//     const base64 = token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
//     return JSON.parse(atob(base64));
//   } catch { return {}; }
// }

// function Login() {
//   const navigate = useNavigate();
//   const [page,         setPage]         = useState("select");
//   const [role,         setRole]         = useState("");
//   const [username,     setUsername]     = useState("");
//   const [password,     setPassword]     = useState("");
//   const [email,        setEmail]        = useState("");
//   const [loading,      setLoading]      = useState(false);
//   const [error,        setError]        = useState("");
//   const [focusedInput, setFocusedInput] = useState(null);
//   const [hoveredRole,  setHoveredRole]  = useState(null);

//   const resetFields = () => { setUsername(""); setPassword(""); setEmail(""); setError(""); };

//   const handleLogin = async (e) => {
//     e.preventDefault(); setError(""); setLoading(true);
//     try {
//       const res = await loginUser({ username, password });
//       const token = res.data;
//       const payload = decodeJwt(token);
//       const tokenRole = (payload.role || "").toLowerCase();

//       // If token has a role claim, enforce it matches what was selected
//       if (tokenRole) {
//         if (role === "Admin" && tokenRole !== "admin") {
//           setError("This account is not an admin account."); setLoading(false); return;
//         }
//         if (role === "User" && tokenRole === "admin") {
//           setError("Admin accounts must use the Admin login."); setLoading(false); return;
//         }
//       }

//       const resolvedRole = tokenRole === "admin" ? "Admin" : "User";
//       localStorage.setItem("token", token);
//       localStorage.setItem("role", resolvedRole);
//       localStorage.setItem("username", payload.sub || username);
//       // email not in JWT, but user typed it on login form — store it
//       if (email) localStorage.setItem("userEmail", email);
//       navigate(resolvedRole === "Admin" ? "/admin" : "/menu");
//     } catch { setError("Login failed. Check your credentials."); }
//     finally { setLoading(false); }
//   };

//   const handleRegister = async (e) => {
//     e.preventDefault(); setError(""); setLoading(true);
//     try {
//       await registerUser({ username, password, email, role: role.toLowerCase() });
//       setPage("login"); resetFields();
//     } catch { setError("Registration failed. Username may already exist."); }
//     finally { setLoading(false); }
//   };

//   const inp = (name) => ({
//     background:"#1e1a16",
//     border: focusedInput===name ? "1.5px solid #f5a623" : "1.5px solid rgba(255,220,120,0.12)",
//     boxShadow: focusedInput===name ? "0 0 0 3px rgba(245,166,35,0.12)" : "none",
//     color:"#f5efe6", borderRadius:"9px", padding:"12px 16px",
//     fontSize:"14px", fontFamily:FONT, outline:"none", width:"100%",
//     transition:"border-color 0.2s, box-shadow 0.2s", boxSizing:"border-box",
//   });

//   return (
//     <div style={{ minHeight:"100vh", display:"flex", background:"#0e0c0a", fontFamily:FONT, position:"relative", overflow:"hidden" }}>
//       <div style={{ position:"absolute", inset:0, background:"radial-gradient(ellipse at 20% 50%, rgba(245,166,35,0.06) 0%,transparent 60%), radial-gradient(ellipse at 80% 20%, rgba(232,66,10,0.05) 0%,transparent 50%)", pointerEvents:"none" }} />

//       {/* ── Left brand panel ── */}
//       <div style={{ flex:1, display:"flex", alignItems:"center", padding:"60px", borderRight:"1px solid rgba(245,166,35,0.08)" }}>
//         <div style={{ maxWidth:"400px" }}>
//           <span style={{ fontSize:"54px", marginBottom:"28px", display:"block" }}>🍕</span>
//           <h1 style={{ fontFamily:FONT_H, fontSize:"46px", fontWeight:"900", lineHeight:"1.1", color:"#f5efe6", marginBottom:"16px" }}>Craft Pizza,<br />Delivered Hot.</h1>
//           <p style={{ color:"#a89880", fontSize:"16px", lineHeight:"1.7", marginBottom:"36px" }}>Artisan ingredients. Bold flavors. Right to your door.</p>
//           <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
//             {["Fresh daily dough","Premium toppings","30-min delivery","Real-time tracking"].map(f => (
//               <div key={f} style={{ display:"flex", alignItems:"center", gap:"12px", color:"#a89880", fontSize:"14px" }}>
//                 <span style={{ width:"6px", height:"6px", background:"#f5a623", borderRadius:"50%", flexShrink:0, display:"block" }} />{f}
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {/* ── Right form panel ── */}
//       <div style={{ width:"1000px", display:"flex", alignItems:"center", justifyContent:"center", padding:"40px" }}>
//         <div style={{ width:"1000%", background:"#161410", border:"1px solid rgba(255,220,120,0.1)", borderRadius:"20px", padding:"40px", boxShadow:"0 24px 64px rgba(0,0,0,0.5)" }}>

//           {/* Role selection */}
//           {page === "select" && (
//             <div style={{ animation:"fadeUp 0.4s ease" }}>
//               <h2 style={{ fontFamily:FONT_H, fontSize:"28px", fontWeight:"700", color:"#f5efe6", marginBottom:"6px" }}>Welcome Back</h2>
//               <p style={{ color:"#6b5e50", fontSize:"14px", marginBottom:"28px" }}>How would you like to continue?</p>
//               <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"14px" }}>
//                 {[{id:"User",icon:"👤",desc:"Browse menu & order"},{id:"Admin",icon:"🛡️",desc:"Manage everything"}].map(r => (
//                   <div key={r.id}
//                     onMouseEnter={()=>setHoveredRole(r.id)} onMouseLeave={()=>setHoveredRole(null)}
//                     onClick={()=>{ setRole(r.id); setPage("login"); resetFields(); }}
//                     style={{ background:hoveredRole===r.id?"rgba(245,166,35,0.08)":"#1e1a16", border:hoveredRole===r.id?"1.5px solid rgba(245,166,35,0.4)":"1.5px solid rgba(255,220,120,0.1)", borderRadius:"14px", padding:"22px 16px", cursor:"pointer", textAlign:"center", transition:"all 0.2s" }}>
//                     <span style={{ fontSize:"32px", display:"block", marginBottom:"10px" }}>{r.icon}</span>
//                     <span style={{ color:"#f5efe6", fontWeight:"600", fontSize:"15px", display:"block", marginBottom:"5px" }}>{r.id}</span>
//                     <span style={{ color:"#6b5e50", fontSize:"12px" }}>{r.desc}</span>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           )}

//           {/* Login form */}
//           {page === "login" && (
//             <div style={{ animation:"fadeUp 0.35s ease" }}>
//               <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"24px" }}>
//                 <button onClick={()=>{ setPage("select"); resetFields(); }} style={{ background:"none", border:"none", color:"#6b5e50", cursor:"pointer", fontSize:"18px", padding:"0" }}>←</button>
//                 <div>
//                   <h2 style={{ fontFamily:FONT_H, fontSize:"24px", fontWeight:"700", color:"#f5efe6", margin:0 }}>
//                     {role === "Admin" ? "🛡️" : "👤"} Sign in as {role}
//                   </h2>
//                   <p style={{ color:"#6b5e50", fontSize:"13px", margin:0, marginTop:"2px" }}>Enter your credentials</p>
//                 </div>
//               </div>
//               {error && <div style={{ background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.3)", color:"#e85454", padding:"10px 14px", borderRadius:"8px", fontSize:"13px", marginBottom:"16px" }}>{error}</div>}
//               <form onSubmit={handleLogin} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
//                 <input placeholder="Username" value={username} required onChange={e=>setUsername(e.target.value)} onFocus={()=>setFocusedInput("lu")} onBlur={()=>setFocusedInput(null)} style={inp("lu")} />
//                 <input placeholder="Password" type="password" value={password} required onChange={e=>setPassword(e.target.value)} onFocus={()=>setFocusedInput("lp")} onBlur={()=>setFocusedInput(null)} style={inp("lp")} />
//                 <button type="submit" disabled={loading}
//                   style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"13px", borderRadius:"10px", fontSize:"15px", fontWeight:"700", cursor:"pointer", fontFamily:FONT, opacity:loading?0.7:1 }}>
//                   {loading ? "Signing in…" : "Sign In"}
//                 </button>
//               </form>
//               {/* Register link — available for both User and Admin */}
//               <p style={{ color:"#6b5e50", fontSize:"13px", textAlign:"center", marginTop:"16px" }}>
//                 No account?{" "}
//                 <span onClick={()=>{ setPage("register"); resetFields(); }} style={{ color:"#f5a623", cursor:"pointer", fontWeight:"600" }}>Register</span>
//               </p>
//             </div>
//           )}

//           {/* Register form */}
//           {page === "register" && (
//             <div style={{ animation:"fadeUp 0.35s ease" }}>
//               <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"24px" }}>
//                 <button onClick={()=>{ setPage("login"); resetFields(); }} style={{ background:"none", border:"none", color:"#6b5e50", cursor:"pointer", fontSize:"18px", padding:"0" }}>←</button>
//                 <div>
//                   <h2 style={{ fontFamily:FONT_H, fontSize:"24px", fontWeight:"700", color:"#f5efe6", margin:0 }}>
//                     {role === "Admin" ? "🛡️" : "👤"} Register as {role}
//                   </h2>
//                   <p style={{ color:"#6b5e50", fontSize:"13px", margin:0, marginTop:"2px" }}>Create a new {role.toLowerCase()} account</p>
//                 </div>
//               </div>
//               {error && <div style={{ background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.3)", color:"#e85454", padding:"10px 14px", borderRadius:"8px", fontSize:"13px", marginBottom:"16px" }}>{error}</div>}
//               <form onSubmit={handleRegister} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
//                 <input placeholder="Username" value={username} required onChange={e=>setUsername(e.target.value)} onFocus={()=>setFocusedInput("ru")} onBlur={()=>setFocusedInput(null)} style={inp("ru")} />
//                 <input placeholder="Email" type="email" value={email} required onChange={e=>setEmail(e.target.value)} onFocus={()=>setFocusedInput("re")} onBlur={()=>setFocusedInput(null)} style={inp("re")} />
//                 <input placeholder="Password" type="password" value={password} required onChange={e=>setPassword(e.target.value)} onFocus={()=>setFocusedInput("rp")} onBlur={()=>setFocusedInput(null)} style={inp("rp")} />
//                 <button type="submit" disabled={loading}
//                   style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"13px", borderRadius:"10px", fontSize:"15px", fontWeight:"700", cursor:"pointer", fontFamily:FONT, opacity:loading?0.7:1 }}>
//                   {loading ? "Creating…" : `Create ${role} Account`}
//                 </button>
//               </form>
//               <p style={{ color:"#6b5e50", fontSize:"13px", textAlign:"center", marginTop:"16px" }}>
//                 Already have an account?{" "}
//                 <span onClick={()=>{ setPage("login"); resetFields(); }} style={{ color:"#f5a623", cursor:"pointer", fontWeight:"600" }}>Sign in</span>
//               </p>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Login;
