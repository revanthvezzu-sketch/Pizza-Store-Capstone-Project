const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";

const BILL_STATUS_STYLE = {
  APPROVED: { bg:"rgba(76,175,125,0.15)",  color:"#4caf7d", border:"rgba(76,175,125,0.4)",  label:"✅ Approved" },
  DENIED:   { bg:"rgba(232,84,84,0.12)",   color:"#e85454", border:"rgba(232,84,84,0.35)",  label:"❌ Denied"   },
};

function BillPopup({ bill, order, onClose }) {
  if (!bill) return null;
  const fmt = (n) => "₹" + parseFloat(n || 0).toFixed(2);
  const bs   = BILL_STATUS_STYLE[(bill.billStatus || "APPROVED").toUpperCase()] || BILL_STATUS_STYLE.APPROVED;
  // Items: prefer from bill's order (passed as order prop), else from bill itself
  const items = (order && Array.isArray(order.items) && order.items.length > 0)
    ? order.items
    : (Array.isArray(bill.items) ? bill.items : []);

  return (
    <div onClick={onClose} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.82)", backdropFilter:"blur(6px)", zIndex:5000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px", animation:"fadeIn 0.2s ease" }}>
      <div onClick={e=>e.stopPropagation()} style={{ background:"#161410", border:"1px solid rgba(245,166,35,0.2)", borderRadius:"20px", width:"100%", maxWidth:"460px", boxShadow:"0 32px 80px rgba(0,0,0,0.7)", overflow:"hidden", animation:"fadeUp 0.3s ease", maxHeight:"90vh", overflowY:"auto" }}>

        {/* Header */}
        <div style={{ background:"linear-gradient(135deg,rgba(245,166,35,0.15),rgba(232,66,10,0.1))", borderBottom:"1px solid rgba(245,166,35,0.12)", padding:"20px 24px", display:"flex", justifyContent:"space-between", alignItems:"center", position:"sticky", top:0, zIndex:1 }}>
          <div>
            <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
              <span style={{ fontSize:"20px" }}>🧾</span>
              <span style={{ fontFamily:FONT_H, fontSize:"20px", fontWeight:"700", color:"#f5efe6" }}>Bill Receipt</span>
            </div>
            <div style={{ color:"#6b5e50", fontSize:"12px", marginTop:"2px" }}>Order #{bill.orderId}</div>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
            {/* Bill status badge */}
            <span style={{ background:bs.bg, color:bs.color, border:`1px solid ${bs.border}`, fontSize:"12px", fontWeight:"700", padding:"5px 12px", borderRadius:"99px" }}>
              {bs.label}
            </span>
            <button onClick={onClose} style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", color:"#a89880", width:"32px", height:"32px", borderRadius:"50%", cursor:"pointer", fontSize:"16px", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:FONT }}>✕</button>
          </div>
        </div>

        {/* Customer + delivery */}
        <div style={{ padding:"16px 24px 0", display:"flex", justifyContent:"space-between", flexWrap:"wrap", gap:"8px" }}>
          <div>
            <div style={{ color:"#6b5e50", fontSize:"11px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px" }}>Customer</div>
            <div style={{ color:"#f5efe6", fontSize:"14px", fontWeight:"600", marginTop:"3px" }}>{bill.username}</div>
            {bill.userEmail && <div style={{ color:"#a89880", fontSize:"12px" }}>📧 {bill.userEmail}</div>}
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ color:"#6b5e50", fontSize:"11px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px" }}>Delivery Mode</div>
            <div style={{ color:"#f5a623", fontSize:"14px", fontWeight:"600", marginTop:"3px" }}>🚚 {bill.deliveryMode || "—"}</div>
          </div>
        </div>

        {/* Items with category */}
        {items.length > 0 && (
          <div style={{ padding:"16px 24px 0" }}>
            <div style={{ color:"#6b5e50", fontSize:"11px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"10px" }}>Order Items</div>
            <div style={{ background:"#1e1a16", borderRadius:"10px", overflow:"hidden" }}>
              {items.map((it, idx) => (
                <div key={idx} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"10px 14px", borderBottom:idx<items.length-1?"1px solid rgba(255,220,120,0.06)":"none" }}>
                  <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                    <span style={{ background:"rgba(245,166,35,0.12)", color:"#f5a623", fontSize:"11px", fontWeight:"700", padding:"2px 7px", borderRadius:"5px" }}>×{it.quantity||it.qty||1}</span>
                    <div>
                      <div style={{ color:"#f5efe6", fontSize:"13px", fontWeight:"500" }}>{it.name}</div>
                      {it.category && (
                        <div style={{ color:"#6b5e50", fontSize:"11px", marginTop:"1px" }}>📂 {it.category}</div>
                      )}
                    </div>
                  </div>
                  <span style={{ color:"#a89880", fontSize:"13px" }}>₹{(parseFloat(it.price||0)*(it.quantity||it.qty||1)).toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bill breakdown */}
        <div style={{ padding:"16px 24px" }}>
          <div style={{ background:"#1e1a16", borderRadius:"12px", overflow:"hidden" }}>
            {[
              { label:"Items Total",    value: fmt(bill.itemsTotal),     muted:false },
              { label:"GST (5%)",       value: fmt(bill.gst),            muted:true  },
              { label:"Delivery Fee",   value: fmt(bill.deliveryFee),    muted:true  },
              { label:"Convenience Fee",value: fmt(bill.convenienceFee), muted:true  },
            ].map(({ label, value, muted }) => (
              <div key={label} style={{ display:"flex", justifyContent:"space-between", padding:"10px 16px", borderBottom:"1px solid rgba(255,220,120,0.05)" }}>
                <span style={{ color: muted ? "#6b5e50" : "#a89880", fontSize:"13px" }}>{label}</span>
                <span style={{ color: muted ? "#a89880" : "#f5efe6", fontSize:"13px", fontWeight:"500" }}>{value}</span>
              </div>
            ))}
            <div style={{ display:"flex", justifyContent:"space-between", padding:"14px 16px", background:"rgba(245,166,35,0.06)" }}>
              <span style={{ color:"#f5efe6", fontSize:"15px", fontWeight:"700" }}>Grand Total</span>
              <span style={{ color:"#f5a623", fontSize:"20px", fontWeight:"700", fontFamily:FONT_H }}>₹{parseFloat(bill.grandTotal||0).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{ padding:"0 24px 20px", textAlign:"center" }}>
          {(bill.billStatus||"").toUpperCase() === "DENIED" ? (
            <div style={{ background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.3)", borderRadius:"10px", padding:"12px 16px" }}>
              <div style={{ fontSize:"22px", marginBottom:"6px" }}>❌</div>
              <div style={{ color:"#e85454", fontSize:"14px", fontWeight:"700" }}>Order Denied — Order is Cancelled</div>
              <div style={{ color:"#a89880", fontSize:"12px", marginTop:"4px" }}>No charges have been applied to your account.</div>
            </div>
          ) : (
            <div style={{ background:"rgba(76,175,125,0.08)", border:"1px solid rgba(76,175,125,0.25)", borderRadius:"10px", padding:"12px 16px" }}>
              <div style={{ fontSize:"22px", marginBottom:"6px" }}>✅</div>
              <div style={{ color:"#4caf7d", fontSize:"14px", fontWeight:"700" }}>Order Approved — Thank you for your order!</div>
            </div>
          )}
          <button onClick={onClose} style={{ marginTop:"14px", background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"11px 36px", borderRadius:"10px", fontSize:"14px", fontWeight:"700", cursor:"pointer", fontFamily:FONT }}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export default BillPopup;


// const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
// const FONT_H = "Georgia,'Times New Roman',serif";

// function BillPopup({ bill, order, onClose }) {
//   if (!bill) return null;

//   const fmt = (n) => "₹" + parseFloat(n || 0).toFixed(2);

//   return (
//     <div
//       onClick={onClose}
//       style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.82)", backdropFilter:"blur(6px)", zIndex:5000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px", animation:"fadeIn 0.2s ease" }}>
//       <div
//         onClick={e=>e.stopPropagation()}
//         style={{ background:"#161410", border:"1px solid rgba(245,166,35,0.2)", borderRadius:"20px", width:"100%", maxWidth:"440px", boxShadow:"0 32px 80px rgba(0,0,0,0.7)", overflow:"hidden", animation:"fadeUp 0.3s ease" }}>

//         {/* Header */}
//         <div style={{ background:"linear-gradient(135deg,rgba(245,166,35,0.15),rgba(232,66,10,0.1))", borderBottom:"1px solid rgba(245,166,35,0.12)", padding:"20px 24px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
//           <div>
//             <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
//               <span style={{ fontSize:"20px" }}>🧾</span>
//               <span style={{ fontFamily:FONT_H, fontSize:"20px", fontWeight:"700", color:"#f5efe6" }}>Bill Receipt</span>
//             </div>
//             <div style={{ color:"#6b5e50", fontSize:"12px", marginTop:"2px" }}>Order #{bill.orderId}</div>
//           </div>
//           <button onClick={onClose} style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", color:"#a89880", width:"32px", height:"32px", borderRadius:"50%", cursor:"pointer", fontSize:"16px", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:FONT }}>✕</button>
//         </div>

//         {/* Customer + delivery info */}
//         <div style={{ padding:"16px 24px 0", display:"flex", justifyContent:"space-between", flexWrap:"wrap", gap:"8px" }}>
//           <div>
//             <div style={{ color:"#6b5e50", fontSize:"11px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px" }}>Customer</div>
//             <div style={{ color:"#f5efe6", fontSize:"14px", fontWeight:"600", marginTop:"3px" }}>{bill.username}</div>
//             {bill.userEmail && <div style={{ color:"#a89880", fontSize:"12px" }}>{bill.userEmail}</div>}
//           </div>
//           <div style={{ textAlign:"right" }}>
//             <div style={{ color:"#6b5e50", fontSize:"11px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px" }}>Delivery Mode</div>
//             <div style={{ color:"#f5a623", fontSize:"14px", fontWeight:"600", marginTop:"3px" }}>🚚 {bill.deliveryMode || "—"}</div>
//           </div>
//         </div>

//         {/* Items */}
//         {order && Array.isArray(order.items) && order.items.length > 0 && (
//           <div style={{ padding:"16px 24px 0" }}>
//             <div style={{ color:"#6b5e50", fontSize:"11px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"10px" }}>Items</div>
//             <div style={{ background:"#1e1a16", borderRadius:"10px", overflow:"hidden" }}>
//               {order.items.map((it, idx) => (
//                 <div key={idx} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"9px 14px", borderBottom:idx<order.items.length-1?"1px solid rgba(255,220,120,0.06)":"none" }}>
//                   <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
//                     <span style={{ background:"rgba(245,166,35,0.12)", color:"#f5a623", fontSize:"11px", fontWeight:"700", padding:"2px 7px", borderRadius:"5px" }}>×{it.quantity||1}</span>
//                     <span style={{ color:"#f5efe6", fontSize:"13px" }}>{it.name}</span>
//                   </div>
//                   <span style={{ color:"#a89880", fontSize:"13px" }}>₹{(parseFloat(it.price||0)*(it.quantity||1)).toFixed(2)}</span>
//                 </div>
//               ))}
//             </div>
//           </div>
//         )}

//         {/* Bill breakdown */}
//         <div style={{ padding:"16px 24px" }}>
//           <div style={{ background:"#1e1a16", borderRadius:"12px", overflow:"hidden" }}>
//             {[
//               { label:"Items Total", value: fmt(bill.itemsTotal), muted:false },
//               { label:"GST (5%)",    value: fmt(bill.gst),        muted:true  },
//               { label:"Delivery Fee",value: fmt(bill.deliveryFee),muted:true  },
//               { label:"Convenience Fee", value: fmt(bill.convenienceFee), muted:true },
//             ].map(({ label, value, muted }, i) => (
//               <div key={label} style={{ display:"flex", justifyContent:"space-between", padding:"10px 16px", borderBottom:"1px solid rgba(255,220,120,0.05)" }}>
//                 <span style={{ color: muted ? "#6b5e50" : "#a89880", fontSize:"13px" }}>{label}</span>
//                 <span style={{ color: muted ? "#a89880" : "#f5efe6", fontSize:"13px", fontWeight:"500" }}>{value}</span>
//               </div>
//             ))}
//             {/* Grand total */}
//             <div style={{ display:"flex", justifyContent:"space-between", padding:"14px 16px", background:"rgba(245,166,35,0.06)" }}>
//               <span style={{ color:"#f5efe6", fontSize:"15px", fontWeight:"700" }}>Grand Total</span>
//               <span style={{ color:"#f5a623", fontSize:"20px", fontWeight:"700", fontFamily:FONT_H }}>₹{parseFloat(bill.grandTotal||0).toFixed(2)}</span>
//             </div>
//           </div>
//         </div>

//         {/* Footer */}
//         <div style={{ padding:"0 24px 20px", textAlign:"center" }}>
//           <div style={{ color:"#6b5e50", fontSize:"12px" }}>✅ Order Approved • Thank you for your order!</div>
//           <button onClick={onClose} style={{ marginTop:"12px", background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"11px 36px", borderRadius:"10px", fontSize:"14px", fontWeight:"700", cursor:"pointer", fontFamily:FONT }}>
//             Close
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default BillPopup;
