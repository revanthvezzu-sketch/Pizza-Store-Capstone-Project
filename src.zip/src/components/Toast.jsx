import { useState, useEffect } from "react";

let _setToast = null;
export function showToast(message, type = "info") {
  if (_setToast) _setToast({ message, type });
}

const COLORS = { info:"#f5a623", success:"#4caf7d", error:"#e85454" };

function Toast() {
  const [toast, setToast] = useState(null);
  useEffect(() => { _setToast = setToast; return () => { _setToast = null; }; }, []);
  useEffect(() => {
    if (toast) { const t = setTimeout(() => setToast(null), 3500); return () => clearTimeout(t); }
  }, [toast]);

  if (!toast) return null;
  return (
    <div style={{
      position:"fixed", bottom:"24px", right:"24px",
background:"#f8f5f2", border:"1px solid rgba(90,78,64,0.1)",
      borderLeft:`4px solid ${COLORS[toast.type] || COLORS.info}`,
      padding:"14px 20px", borderRadius:"10px", fontSize:"14px",
color:"#1f1b17"
      animation:"fadeUp 0.3s ease", maxWidth:"320px",
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif",
    }}>
      {toast.message}
    </div>
  );
}

export default Toast;
