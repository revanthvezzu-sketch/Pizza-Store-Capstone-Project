import { Link, useNavigate, useLocation } from "react-router-dom";
import { logout } from "../service/auth";
import { useState } from "react";

const FONT = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";

function UserNavbar() {
  const navigate  = useNavigate();
  const location  = useLocation();
  const token     = localStorage.getItem("token");
  const username  = localStorage.getItem("username") || "User";
  const [hovered, setHovered] = useState(null);

  const handleLogout = () => {
    logout();
    localStorage.removeItem("role");
    localStorage.removeItem("username");
    navigate("/login");
  };

  const isActive = (path) => location.pathname === path;
  const links = [
    { path:"/menu",   label:"🍕 Menu"   },
    { path:"/orders", label:"📋 Orders" },
    { path:"/bills",  label:"🧾 Bills"  },
  ];

  if (!token) return null;

  return (
    <>
      <nav style={{
        position:"fixed", top:0, left:0, right:0, height:"64px",
        background:"rgba(14,12,10,0.94)", backdropFilter:"blur(18px)",
        borderBottom:"1px solid rgba(245,166,35,0.1)",
        display:"flex", alignItems:"center", justifyContent:"space-between",
        padding:"0 36px", zIndex:1000, fontFamily:FONT,
      }}>
        <Link to="/menu" style={{ display:"flex", alignItems:"center", gap:"10px", textDecoration:"none" }}>
          <span style={{ fontSize:"22px" }}>🍕</span>
          <span style={{ fontFamily:FONT_H, fontSize:"20px", fontWeight:"900", color:"#f5a623" }}>Pizzeria</span>
        </Link>

        <div style={{ display:"flex", gap:"4px" }}>
          {links.map(({ path, label }) => (
            <Link key={path} to={path} style={{
              color: isActive(path) ? "#f5efe6" : "#a89880",
              textDecoration:"none", padding:"6px 16px", borderRadius:"8px",
              fontSize:"14px", fontWeight:"500",
              background: isActive(path) ? "rgba(245,166,35,0.12)" : "transparent",
              transition:"background 0.2s",
            }}>{label}</Link>
          ))}
        </div>

        <div style={{ display:"flex", alignItems:"center", gap:"12px" }}>
          <span style={{ color:"#6b5e50", fontSize:"13px" }}>👤 {username}</span>
          <button onClick={handleLogout}
            onMouseEnter={()=>setHovered("out")} onMouseLeave={()=>setHovered(null)}
            style={{ background:hovered==="out"?"rgba(232,66,10,0.15)":"transparent", border:"1.5px solid rgba(232,66,10,0.4)", color:"#e8420a", padding:"7px 18px", borderRadius:"8px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT, transition:"background 0.2s" }}>
            Logout
          </button>
        </div>
      </nav>
      <div style={{ height:"64px" }} />
    </>
  );
}

export default UserNavbar;
