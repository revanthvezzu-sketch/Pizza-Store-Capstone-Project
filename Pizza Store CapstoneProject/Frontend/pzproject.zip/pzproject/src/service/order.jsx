import axios from "axios";

const API_BASE = "http://localhost:8083/orders";

const getConfig = () => ({
  headers: { Authorization: "Bearer " + localStorage.getItem("token") }
});

// Orders
export const getMyOrders   = ()      => axios.get(`${API_BASE}/my`, getConfig());
export const getAllOrders   = ()      => axios.get(`${API_BASE}/all`, getConfig());
export const addOrder      = (order) => axios.post(`${API_BASE}`, order, getConfig());
export const deleteOrder   = (id)    => axios.delete(`${API_BASE}/${id}`, getConfig());
export const updateOrderStatus = (id, status) =>
  axios.put(`${API_BASE}/${id}/status`, status, {
    ...getConfig(),
    headers: { ...getConfig().headers, "Content-Type": "text/plain" }
  });
export const approveOrder = (id) => axios.put(`${API_BASE}/${id}/approve`, {}, getConfig());
export const denyOrder    = (id) => axios.put(`${API_BASE}/${id}/deny`,    {}, getConfig());

// Bills
export const getMyBills     = ()        => axios.get(`${API_BASE}/bills/my`, getConfig());
export const getAllBills     = ()        => axios.get(`${API_BASE}/bills/all`, getConfig());
export const getBillByOrder = (orderId) => axios.get(`${API_BASE}/bills/order/${orderId}`, getConfig());

// Revenue
export const getRevenue = () => axios.get(`${API_BASE}/revenue`, getConfig());

// Delivery Modes
export const getDeliveryModes   = ()       => axios.get(`${API_BASE}/delivery-modes`, getConfig());
export const getAllDeliveryModes = ()       => axios.get(`${API_BASE}/delivery-modes/all`, getConfig());
export const addDeliveryMode    = (dm)     => axios.post(`${API_BASE}/delivery-modes`, dm, getConfig());
export const updateDeliveryMode = (id, dm) => axios.put(`${API_BASE}/delivery-modes/${id}`, dm, getConfig());
export const deleteDeliveryMode = (id)     => axios.delete(`${API_BASE}/delivery-modes/${id}`, getConfig());

export const getOrders = () => {
  const role = localStorage.getItem("role");
  return role === "Admin" ? getAllOrders() : getMyOrders();
};


// import axios from "axios";

// const API_BASE = "http://localhost:8083/orders";

// const getConfig = () => ({
//   headers: { Authorization: "Bearer " + localStorage.getItem("token") }
// });

// // ── Orders ──
// export const getMyOrders   = ()       => axios.get(`${API_BASE}/my`, getConfig());
// export const getAllOrders   = ()       => axios.get(`${API_BASE}/all`, getConfig());
// export const addOrder      = (order)  => axios.post(`${API_BASE}`, order, getConfig());
// export const deleteOrder   = (id)     => axios.delete(`${API_BASE}/${id}`, getConfig());
// export const updateOrderStatus = (id, status) =>
//   axios.put(`${API_BASE}/${id}/status`, status, {
//     ...getConfig(),
//     headers: { ...getConfig().headers, "Content-Type": "text/plain" }
//   });
// export const approveOrder  = (id)     => axios.put(`${API_BASE}/${id}/approve`, {}, getConfig());

// // ── Bills ──
// export const getMyBills      = ()       => axios.get(`${API_BASE}/bills/my`, getConfig());
// export const getAllBills      = ()       => axios.get(`${API_BASE}/bills/all`, getConfig());
// export const getBillByOrder  = (orderId)=> axios.get(`${API_BASE}/bills/order/${orderId}`, getConfig());

// // ── Revenue ──
// export const getRevenue = () => axios.get(`${API_BASE}/revenue`, getConfig());

// // ── Delivery Modes ──
// export const getDeliveryModes    = ()       => axios.get(`${API_BASE}/delivery-modes`, getConfig());
// export const getAllDeliveryModes  = ()       => axios.get(`${API_BASE}/delivery-modes/all`, getConfig());
// export const addDeliveryMode     = (dm)     => axios.post(`${API_BASE}/delivery-modes`, dm, getConfig());
// export const updateDeliveryMode  = (id, dm) => axios.put(`${API_BASE}/delivery-modes/${id}`, dm, getConfig());
// export const deleteDeliveryMode  = (id)     => axios.delete(`${API_BASE}/delivery-modes/${id}`, getConfig());

// // Legacy compat
// export const getOrders = () => {
//   const role = localStorage.getItem("role");
//   return role === "Admin" ? getAllOrders() : getMyOrders();
// };
