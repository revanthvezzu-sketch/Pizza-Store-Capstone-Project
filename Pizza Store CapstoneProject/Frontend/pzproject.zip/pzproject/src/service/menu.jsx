import axios from "axios";

const API_BASE = "http://localhost:8082/menu";

// Always read token fresh at call time — avoids stale token bug
const getConfig = () => ({
  headers: {
    Authorization: "Bearer " + localStorage.getItem("token")
  }
});

// GET /menu/items
export const getAllMenu = () => axios.get(`${API_BASE}/items`, getConfig());

// POST /menu/items
export const addMenuItem = (item) => axios.post(`${API_BASE}/items`, item, getConfig());

// PUT /menu/items/{id}
export const updateMenuItem = (id, item) => axios.put(`${API_BASE}/items/${id}`, item, getConfig());

// DELETE /menu/items/{id}
export const deleteMenuItem = (id) => axios.delete(`${API_BASE}/items/${id}`, getConfig());

// GET /menu/categories
export const getAllCategories = () => axios.get(`${API_BASE}/categories`, getConfig());

// GET /menu/categories/{id}
export const getCategoryById = (id) => axios.get(`${API_BASE}/categories/${id}`, getConfig());

// POST /menu/categories
export const addCategory = (category) => axios.post(`${API_BASE}/categories`, category, getConfig());

// PUT /menu/categories/{id}
export const updateCategory = (id, category) => axios.put(`${API_BASE}/categories/${id}`, category, getConfig());

// DELETE /menu/categories/{id}
export const deleteCategory = (id) => axios.delete(`${API_BASE}/categories/${id}`, getConfig());
