import axios from "axios";

const API_URL = "http://localhost:8081/auth";

export const loginUser = ({ username, password }) =>
  axios.post(`${API_URL}/login`, { username, password });

export const registerUser = ({ username, password, email, role }) =>
  axios.post(`${API_URL}/register`, { username, password, email, role });

export const getToken = () => localStorage.getItem("token");
export const setToken = (token) => localStorage.setItem("token", token);
export const logout = () => localStorage.removeItem("token");

