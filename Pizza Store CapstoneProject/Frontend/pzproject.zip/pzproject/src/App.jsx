import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import LoginPage      from "./pages/Login";
import Menu           from "./pages/Menu";
import OrderPage      from "./pages/Order";
import AdminDashboard from "./pages/AdminDashboard";
import AdminMenu      from "./pages/AdminMenu";
import BillsPage      from "./pages/Bills";
import AdminBillsPage from "./pages/AdminBills";
import RevenuePage    from "./pages/RevenuePage";
import Toast          from "./components/Toast";
import { ThemeProvider } from "./context/ThemeContext";

function GlobalStyles() {
  useEffect(() => {
    const style = document.createElement("style");
    style.id = "pizza-global";
    style.innerHTML = `
      *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
      html { scroll-behavior:smooth; }

      /* ── Dark theme (default) ── */
      :root, [data-theme="dark"] {
        --bg-base:        #0e0c0a;
        --bg-card:        #161410;
        --bg-card2:       #1e1a16;
        --bg-card3:       #252018;
        --border:         rgba(255,220,120,0.08);
        --border-hover:   rgba(245,166,35,0.35);
        --border-strong:  rgba(255,220,120,0.12);
        --text-primary:   #f5efe6;
        --text-secondary: #a89880;
        --text-muted:     #6b5e50;
        --accent:         #f5a623;
        --accent2:        #e8420a;
        --nav-bg:         rgba(14,12,10,0.94);
        --nav-border:     rgba(245,166,35,0.1);
        --nav-admin:      rgba(232,66,10,0.15);
        --input-bg:       #1e1a16;
        --input-border:   rgba(255,220,120,0.12);
        --input-color:    #f5efe6;
        --scrollbar-track:#1e1a16;
        --role-card-bg:   #1e1a16;
        --role-card-border: rgba(255,220,120,0.1);
        --form-card-bg:   #161410;
        --form-card-border: rgba(255,220,120,0.1);
        --toggle-bg:      rgba(255,220,120,0.08);
        --toggle-border:  rgba(255,220,120,0.2);
        --toggle-color:   #f5a623;
      }

      /* ── Light theme ── */
      [data-theme="light"] {
        --bg-base:        #faf9f7;
        --bg-card:        #ffffff;
        --bg-card2:       #f5f2ee;
        --bg-card3:       #ede9e3;
        --border:         rgba(90,78,64,0.1);
        --border-hover:   rgba(200,140,30,0.5);
        --border-strong:  rgba(90,78,64,0.15);
        --text-primary:   #1f1b17;
        --text-secondary: #5a4e40;
        --text-muted:     #9a8878;
        --accent:         #d4870a;
        --accent2:        #c03500;
        --nav-bg:         rgba(255,255,255,0.96);
        --nav-border:     rgba(200,140,30,0.15);
        --nav-admin:      rgba(192,53,0,0.08);
        --input-bg:       #f5f2ee;
        --input-border:   rgba(90,78,64,0.2);
        --input-color:    #1f1b17;
        --scrollbar-track:#ede9e3;
        --role-card-bg:   #f0ece6;
        --role-card-border: rgba(90,78,64,0.15);
        --form-card-bg:   #ffffff;
        --form-card-border: rgba(90,78,64,0.12);
        --toggle-bg:      rgba(200,140,30,0.08);
        --toggle-border:  rgba(200,140,30,0.3);
        --toggle-color:   #d4870a;
      }

      body {
        font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;
        background: var(--bg-base);
        color: var(--text-primary);
        min-height: 100vh;
        overflow-x: hidden;
        transition: background 0.25s ease, color 0.25s ease;
      }
      ::-webkit-scrollbar { width:5px; }
      ::-webkit-scrollbar-track { background: var(--scrollbar-track); }
      ::-webkit-scrollbar-thumb { background: var(--accent); border-radius:99px; }
      @keyframes fadeUp  { from{opacity:0;transform:translateY(22px)} to{opacity:1;transform:translateY(0)} }
      @keyframes fadeIn  { from{opacity:0} to{opacity:1} }
      @keyframes spin    { to{transform:rotate(360deg)} }
      @keyframes slideIn { from{transform:translateX(100%)} to{transform:translateX(0)} }
      .fade-up { animation: fadeUp 0.45s ease both; }
    `;
    if (!document.getElementById("pizza-global")) document.head.appendChild(style);
    return () => { const el = document.getElementById("pizza-global"); if (el) el.remove(); };
  }, []);
  return null;
}

const isAuthenticated = () => !!localStorage.getItem("token");
const isAdmin = () => localStorage.getItem("role") === "Admin";

function PrivateRoute({ children }) {
  return isAuthenticated() ? children : <Navigate to="/login" />;
}
function AdminRoute({ children }) {
  return isAuthenticated() && isAdmin() ? children : <Navigate to="/login" />;
}
function UserRoute({ children }) {
  if (!isAuthenticated()) return <Navigate to="/login" />;
  if (isAdmin()) return <Navigate to="/admin" />;
  return children;
}

function App() {
  return (
    <ThemeProvider>
      <Router>
        <GlobalStyles />
        <Toast />
        <Routes>
          <Route path="/login"        element={<LoginPage />} />
          <Route path="/register"     element={<LoginPage />} />
          <Route path="/menu"         element={<UserRoute><Menu /></UserRoute>} />
          <Route path="/orders"       element={<UserRoute><OrderPage /></UserRoute>} />
          <Route path="/bills"        element={<UserRoute><BillsPage /></UserRoute>} />
          <Route path="/admin"         element={<AdminRoute><AdminDashboard /></AdminRoute>} />
          <Route path="/admin/menu"    element={<AdminRoute><AdminMenu /></AdminRoute>} />
          <Route path="/admin/bills"   element={<AdminRoute><AdminBillsPage /></AdminRoute>} />
          <Route path="/admin/revenue" element={<AdminRoute><RevenuePage /></AdminRoute>} />
          <Route path="*"             element={<Navigate to="/login" />} />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;
