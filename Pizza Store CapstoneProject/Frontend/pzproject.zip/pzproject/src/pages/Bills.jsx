import { useEffect, useState } from "react";
import { getMyBills, getMyOrders } from "../service/order";
import { useNavigate } from "react-router-dom";
import UserNavbar from "../components/UserNavbar";
import BillPopup from "../components/BillPopup";

const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";

const BILL_STATUS_STYLE = {
  APPROVED: { bg:"rgba(76,175,125,0.12)", color:"#4caf7d", border:"rgba(76,175,125,0.3)", label:"✅ Approved" },
  DENIED:   { bg:"rgba(232,84,84,0.1)",   color:"#e85454", border:"rgba(232,84,84,0.3)",  label:"❌ Denied"  },
};

function BillsPage() {
  const [bills,    setBills]    = useState([]);
  const [orders,   setOrders]   = useState({});  // orderId → order
  const [loading,  setLoading]  = useState(true);
  const [selected, setSelected] = useState(null); // { bill, order }
  const navigate = useNavigate();

  useEffect(() => {
    if (!localStorage.getItem("token")) { navigate("/login"); return; }
    Promise.allSettled([getMyBills(), getMyOrders()]).then(([br, or]) => {
      if (br.status === "fulfilled") setBills(br.value.data);
      if (or.status === "fulfilled") {
        const map = {};
        or.value.data.forEach(o => { map[o.id] = o; });
        setOrders(map);
      }
      setLoading(false);
    });
  }, []);

  return (
    <div style={{ minHeight:"100vh", background:"var(--bg-base)", fontFamily:FONT }}>
      <UserNavbar />
      {selected && <BillPopup bill={selected.bill} order={selected.order} onClose={()=>setSelected(null)} />}

      <div style={{ padding:"36px 40px 24px", borderBottom:"1px solid rgba(245,166,35,0.06)", marginBottom:"28px" }}>
        <h1 style={{ fontFamily:FONT_H, fontSize:"36px", fontWeight:"900", color:"var(--text-primary)" }}>My Bills</h1>
        <p style={{ color:"var(--text-muted)", fontSize:"14px", marginTop:"4px" }}>{bills.length} bill{bills.length!==1?"s":""}</p>
      </div>

      {loading && <div style={{ width:"36px", height:"36px", border:"3px solid rgba(255,220,120,0.1)", borderTopColor:"#f5a623", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"60px auto" }} />}

      {!loading && bills.length === 0 && (
        <div style={{ textAlign:"center", color:"var(--text-muted)", padding:"80px" }}>
          <div style={{ fontSize:"52px", marginBottom:"16px" }}>🧾</div>
          <p style={{ fontSize:"16px" }}>No bills yet. Bills are generated when admin approves or denies your order.</p>
        </div>
      )}

      {!loading && bills.length > 0 && (
        <div style={{ padding:"0 40px 60px", display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(340px,1fr))", gap:"16px" }}>
          {bills.map((bill, i) => {
            const order = orders[bill.orderId];
            const bs    = BILL_STATUS_STYLE[(bill.billStatus||"APPROVED").toUpperCase()] || BILL_STATUS_STYLE.APPROVED;
            const items = order?.items || [];
            return (
              <div key={bill.id} onClick={()=>setSelected({ bill, order })}
                style={{ background:"var(--bg-card)", border:"1px solid rgba(245,166,35,0.1)", borderRadius:"16px", padding:"20px 22px", cursor:"pointer", animation:`fadeUp 0.4s ease ${i*0.05}s both`, transition:"border-color 0.2s, transform 0.2s" }}
                onMouseEnter={e=>{ e.currentTarget.style.borderColor="rgba(245,166,35,0.35)"; e.currentTarget.style.transform="translateY(-2px)"; }}
                onMouseLeave={e=>{ e.currentTarget.style.borderColor="rgba(245,166,35,0.1)"; e.currentTarget.style.transform="none"; }}>

                {/* Bill header */}
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"14px" }}>
                  <div>
                    <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                      <span style={{ fontSize:"18px" }}>🧾</span>
                      <span style={{ fontFamily:FONT_H, fontSize:"16px", fontWeight:"700", color:"var(--text-primary)" }}>Bill #{bill.id}</span>
                    </div>
                    <div style={{ color:"var(--text-muted)", fontSize:"12px", marginTop:"3px" }}>Order #{bill.orderId}</div>
                    {bill.userEmail && <div style={{ color:"var(--text-secondary)", fontSize:"11px", marginTop:"2px" }}>📧 {bill.userEmail}</div>}
                  </div>
                  <span style={{ background:bs.bg, border:`1px solid ${bs.border}`, color:bs.color, fontSize:"11px", fontWeight:"700", padding:"4px 10px", borderRadius:"99px", flexShrink:0 }}>{bs.label}</span>
                </div>

                {/* Delivery + date */}
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"12px" }}>
                  <span style={{ background:"rgba(100,149,237,0.1)", border:"1px solid rgba(100,149,237,0.25)", color:"#6495ed", fontSize:"12px", fontWeight:"600", padding:"4px 12px", borderRadius:"99px" }}>
                    🚚 {bill.deliveryMode||"—"}
                  </span>
                  {bill.createdAt && <span style={{ color:"var(--text-muted)", fontSize:"11px" }}>{new Date(bill.createdAt).toLocaleDateString()}</span>}
                </div>

                {/* Items preview */}
                {items.length > 0 && (
                  <div style={{ background:"var(--bg-card2)", borderRadius:"8px", padding:"10px 12px", marginBottom:"12px" }}>
                    <div style={{ color:"var(--text-muted)", fontSize:"10px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.4px", marginBottom:"8px" }}>Items</div>
                    {items.slice(0,3).map((it,idx) => (
                      <div key={idx} style={{ display:"flex", justifyContent:"space-between", padding:"4px 0", borderBottom:idx<Math.min(items.length,3)-1?"1px solid rgba(255,220,120,0.04)":"none" }}>
                        <div>
                          <span style={{ color:"var(--text-primary)", fontSize:"12px" }}>×{it.quantity||1} {it.name}</span>
                          {it.category && <span style={{ color:"var(--text-muted)", fontSize:"10px", marginLeft:"6px" }}>📂{it.category}</span>}
                        </div>
                        <span style={{ color:"var(--text-secondary)", fontSize:"11px" }}>₹{(parseFloat(it.price||0)*(it.quantity||1)).toFixed(2)}</span>
                      </div>
                    ))}
                    {items.length > 3 && <div style={{ color:"var(--text-muted)", fontSize:"10px", marginTop:"4px" }}>+{items.length-3} more items</div>}
                  </div>
                )}

                {/* Totals */}
                <div style={{ background:"var(--bg-card2)", borderRadius:"10px", padding:"12px 14px" }}>
                  {[
                    ["Items",       `₹${parseFloat(bill.itemsTotal||0).toFixed(2)}`],
                    ["GST (5%)",    `₹${parseFloat(bill.gst||0).toFixed(2)}`],
                    ["Delivery",    `₹${parseFloat(bill.deliveryFee||0).toFixed(2)}`],
                    ["Convenience", `₹${parseFloat(bill.convenienceFee||0).toFixed(2)}`],
                  ].map(([label, val]) => (
                    <div key={label} style={{ display:"flex", justifyContent:"space-between", padding:"4px 0", borderBottom:"1px solid rgba(255,220,120,0.04)" }}>
                      <span style={{ color:"var(--text-muted)", fontSize:"12px" }}>{label}</span>
                      <span style={{ color:"var(--text-secondary)", fontSize:"12px" }}>{val}</span>
                    </div>
                  ))}
                  <div style={{ display:"flex", justifyContent:"space-between", paddingTop:"8px", marginTop:"2px" }}>
                    <span style={{ color:"var(--text-primary)", fontSize:"14px", fontWeight:"700" }}>Grand Total</span>
                    <span style={{ color:"#f5a623", fontSize:"18px", fontWeight:"700", fontFamily:FONT_H }}>₹{parseFloat(bill.grandTotal||0).toFixed(2)}</span>
                  </div>
                </div>
                <div style={{ color:"var(--text-muted)", fontSize:"11px", textAlign:"center", marginTop:"10px" }}>Click to view full receipt</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default BillsPage;
