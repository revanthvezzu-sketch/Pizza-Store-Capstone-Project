import { useEffect, useState } from "react";
import { getAllMenu, addMenuItem, deleteMenuItem, updateMenuItem, getAllCategories, addCategory } from "../service/menu";
import { addOrder, getDeliveryModes } from "../service/order";
import { useNavigate } from "react-router-dom";
import UserNavbar from "../components/UserNavbar";

const EMOJIS = [" ","🍕","🧀","🌶️","🍖","🥓","🫑","🧅","🍗","🥩","🌮"];
const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";

const getCatName = (item) => {
  if (!item.category) return "";
  const raw = typeof item.category === "string" ? item.category : (item.category.name || "");
  return raw.trim();
};
const getCatColor = (item) => {
  if (!item.category || typeof item.category === "string") return null;
  return item.category.color || null;
};
const getCatColorByName = (catName, categoriesList) => {
  if (!catName || catName === "All") return "#f5a623";
  const match = categoriesList.find(c => c.name.toLowerCase() === catName.toLowerCase());
  return match?.color || "#f5a623";
};
const getEmoji = (itemId) => EMOJIS[Math.abs(Number(itemId) % EMOJIS.length)];

function Menu() {
  const [menu,              setMenu]             = useState([]);
  const [categories,        setCategories]       = useState([]);
  const [cart,              setCart]             = useState([]);
  const [loading,           setLoading]          = useState(true);
  const [search,            setSearch]           = useState("");
  const [selectedCat,       setSelectedCat]      = useState("All");
  const [showCart,          setShowCart]         = useState(false);
  const [showAddForm,       setShowAddForm]       = useState(false);
  const [newItem,           setNewItem]          = useState({ name:"", price:"", categoryName:"", description:"" });
  const [editItem,          setEditItem]         = useState(null);
  const [orderMsg,          setOrderMsg]         = useState("");
  const [focusedInput,      setFocusedInput]     = useState(null);
  const [deliveryModes,     setDeliveryModes]    = useState([]);
  const [showDeliveryPopup, setShowDeliveryPopup]= useState(false);
  const [selectedMode,      setSelectedMode]     = useState("");
  const [limitAlert,        setLimitAlert]       = useState(null); // { name, limit }
  const navigate = useNavigate();
  const role = localStorage.getItem("role");

  useEffect(() => {
    if (!localStorage.getItem("token")) { navigate("/login"); return; }
    fetchAll();
    // Poll menu every 5s — picks up stockLimit/availability changes made by admin instantly
    const poll = setInterval(() => getAllMenu().then(r => setMenu(r.data)).catch(() => {}), 5000);
    return () => clearInterval(poll);
  }, [navigate]);

  const fetchAll = () => {
    setLoading(true);
    Promise.all([
      getAllMenu().then(r => setMenu(r.data)),
      getAllCategories().then(r => setCategories(r.data)).catch(() => {}),
      getDeliveryModes().then(r => setDeliveryModes(r.data)).catch(() => {}),
    ]).finally(() => setLoading(false));
  };

  const catNames = [
    "All",
    ...Array.from(new Set([
      ...categories.map(c => c.name).filter(Boolean),
      ...menu.map(getCatName).filter(Boolean),
    ])),
  ];

  const filtered = menu
    .filter(i => selectedCat === "All" || getCatName(i).toLowerCase() === selectedCat.toLowerCase())
    .filter(i => i.name?.toLowerCase().includes(search.toLowerCase()));

  const getQty = (itemId) => cart.find(c => c.id === itemId)?.qty || 0;

  const setQty = (item, delta) => {
    const limit = item.stockLimit ?? -1;
    setCart(prev => {
      const existing = prev.find(c => c.id === item.id);
      const currentQty = existing?.qty || 0;
      const newQty = currentQty + delta;
      if (newQty <= 0) return prev.filter(c => c.id !== item.id);
      // Enforce limit when adding (+1)
      if (delta > 0 && limit >= 0 && newQty > limit) {
        setLimitAlert({ name: item.name, limit });
        return prev; // block the add
      }
      if (existing) return prev.map(c => c.id === item.id ? { ...c, qty: newQty } : c);
      const safeItem = { id: item.id, name: item.name, price: item.price, description: item.description || "", qty: 1, category: getCatName(item) };
      return [...prev, safeItem];
    });
  };

  const cartTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  // "Continue →" opens delivery popup
  const handlePlaceOrder = () => { if (cart.length) setShowDeliveryPopup(true); };

  // Final confirm after mode selected
  const handleConfirmOrder = async () => {
    if (!selectedMode) return;
    try {
      const username  = localStorage.getItem("username") || "";
      const userEmail = localStorage.getItem("userEmail") || "";
      // map cart items to include category string
      const cartWithCategory = cart.map(item => ({
        ...item,
        category: getCatName(item) || item.category || ""
      }));
      await addOrder({ items: cartWithCategory, total: cartTotal, deliveryMode: selectedMode, username, userEmail });
      setOrderMsg("Order placed! 🎉");
      setCart([]); setShowCart(false); setShowDeliveryPopup(false); setSelectedMode("");
      setTimeout(() => setOrderMsg(""), 4000);
    } catch { setOrderMsg("Failed to place order."); }
  };

  const handleAddItem = async (e) => {
    e.preventDefault();
    try {
      await addMenuItem({ ...newItem, price: parseFloat(newItem.price) });
      setNewItem({ name:"", price:"", categoryName:"", description:"" });
      setShowAddForm(false);
      const [rm, rc] = await Promise.all([getAllMenu(), getAllCategories()]);
      setMenu(rm.data); setCategories(rc.data);
    } catch(err) { console.error(err); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this item?")) return;
    try { await deleteMenuItem(id); const r = await getAllMenu(); setMenu(r.data); }
    catch(err) { console.error(err); }
  };

  const openEdit = (item) => {
    let resolvedCatName = "";
    if (item.category) {
      if (typeof item.category === "string") resolvedCatName = item.category;
      else if (item.category.id) {
        const match = categories.find(c => c.id === item.category.id);
        resolvedCatName = match ? match.name : (item.category.name || "");
      }
    }
    setEditItem({ id:item.id, name:item.name, price:item.price, description:item.description||"", categoryName:resolvedCatName });
  };

  const handleEditSave = async (e) => {
    e.preventDefault();
    try {
      await updateMenuItem(editItem.id, { name:editItem.name, price:parseFloat(editItem.price), description:editItem.description, categoryName:editItem.categoryName });
      setEditItem(null);
      const [rm, rc] = await Promise.all([getAllMenu(), getAllCategories()]);
      setMenu(rm.data); setCategories(rc.data);
    } catch(err) { console.error(err); }
  };

  const inp = (name) => ({
    background:"var(--input-bg)", border:focusedInput===name?"1.5px solid #f5a623":"1.5px solid var(--input-border)",
    boxShadow:focusedInput===name?"0 0 0 3px rgba(245,166,35,0.1)":"none",
    color:"var(--input-color)", borderRadius:"9px", padding:"10px 14px", fontSize:"14px", fontFamily:FONT, outline:"none", width:"100%",
  });

  const QtyControl = ({ item, size="md" }) => {
    const qty = getQty(item.id);
    const big = size === "lg";
    const btnStyle = (color) => ({
      width: big?"36px":"30px", height:big?"36px":"30px",
      background: color==="red" ? "rgba(232,84,84,0.15)" : "rgba(245,166,35,0.15)",
      border: color==="red" ? "1px solid rgba(232,84,84,0.3)" : "1px solid rgba(245,166,35,0.3)",
      color: color==="red" ? "#e85454" : "#f5a623",
      borderRadius:"8px", display:"inline-flex", alignItems:"center", justifyContent:"center",
      cursor:"pointer", fontSize: big?"18px":"16px", fontWeight:"700", fontFamily:FONT, flexShrink:0,
    });
    return (
      <div style={{ display:"flex", alignItems:"center", gap:big?"12px":"8px" }}>
        <button onClick={()=>setQty(item,-1)} style={btnStyle("red")}>−</button>
        <span style={{ color:"var(--text-primary)", fontSize:big?"16px":"14px", fontWeight:"700", minWidth:"20px", textAlign:"center", fontFamily:FONT_H }}>{qty}</span>
        <button onClick={()=>setQty(item,1)} style={btnStyle("orange")}>+</button>
      </div>
    );
  };

  return (
    <div style={{ minHeight:"100vh", background:"var(--bg-base)", fontFamily:FONT }}>
      <UserNavbar />

      {/* ── Header ── */}
      <div style={{ padding:"36px 40px 20px", display:"flex", justifyContent:"space-between", alignItems:"flex-end", flexWrap:"wrap", gap:"16px", borderBottom:"1px solid rgba(245,166,35,0.06)" }}>
        <div>
          <h1 style={{ fontFamily:FONT_H, fontSize:"36px", fontWeight:"900", color:"var(--text-primary)" }}>Our Menu</h1>
          <p style={{ color:"var(--text-muted)", fontSize:"14px", marginTop:"4px" }}>{filtered.length} of {menu.length} items</p>
        </div>
        <div style={{ display:"flex", gap:"10px", alignItems:"center", flexWrap:"wrap" }}>
          <input placeholder="🔍  Search..." value={search} onChange={e=>setSearch(e.target.value)}
            onFocus={()=>setFocusedInput("search")} onBlur={()=>setFocusedInput(null)}
            style={{ ...inp("search"), width:"200px" }} />
          {role === "Admin" && (
            <button onClick={()=>{ setShowAddForm(!showAddForm); setEditItem(null); }}
              style={{ background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"10px 18px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
              {showAddForm ? "Cancel" : "+ Add Item"}
            </button>
          )}
          {role !== "Admin" && (
            <button onClick={()=>setShowCart(true)}
              style={{ background:"rgba(245,166,35,0.12)", border:"1.5px solid rgba(245,166,35,0.25)", color:"#f5a623", padding:"10px 18px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT, position:"relative" }}>
              🛒 Cart
              {cartCount > 0 && (
                <span style={{ position:"absolute", top:"-8px", right:"-8px", background:"#e8420a", color:"#fff", fontSize:"10px", fontWeight:"700", width:"18px", height:"18px", borderRadius:"50%", display:"inline-flex", alignItems:"center", justifyContent:"center" }}>{cartCount}</span>
              )}
            </button>
          )}
        </div>
      </div>

      {/* ── Category Filter Bar ── */}
      <div style={{ padding:"16px 40px", display:"flex", gap:"10px", flexWrap:"wrap", alignItems:"center", borderBottom:"1px solid rgba(245,166,35,0.06)", marginBottom:"28px" }}>
        <span style={{ color:"var(--text-muted)", fontSize:"12px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px" }}>Filter:</span>
        {catNames.map(cat => {
          const cc = getCatColorByName(cat, categories);
          const isActive = selectedCat === cat;
          return (
            <button key={cat} onClick={()=>setSelectedCat(cat)} style={{
              background: isActive ? cc : "var(--bg-card2)",
              border: isActive ? "none" : `1.5px solid ${cc}33`,
              color: isActive ? "#fff" : cc,
              padding:"8px 18px", borderRadius:"99px", fontSize:"13px", fontWeight:"600",
              cursor:"pointer", fontFamily:FONT,
              boxShadow: isActive ? `0 2px 14px ${cc}55` : "none",
            }}>
              {cat === "All" ? "🍽️ All Items" : cat}
            </button>
          );
        })}
      </div>

      {/* ── Order Success ── */}
      {orderMsg && (
        <div style={{ margin:"0 40px 24px", background:"rgba(76,175,125,0.1)", border:"1px solid rgba(76,175,125,0.3)", color:"#4caf7d", padding:"13px 20px", borderRadius:"10px", display:"flex", justifyContent:"space-between", alignItems:"center", fontSize:"14px" }}>
          <span>{orderMsg}</span>
          <span onClick={()=>navigate("/orders")} style={{ cursor:"pointer", fontWeight:"600", textDecoration:"underline" }}>View Orders →</span>
        </div>
      )}

      {/* ── Add Item Form (Admin) ── */}
      {showAddForm && role === "Admin" && (
        <div style={{ margin:"0 40px 28px", background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:"14px", padding:"24px" }}>
          <h3 style={{ fontFamily:FONT_H, fontSize:"18px", color:"var(--text-primary)", marginBottom:"16px" }}>Add New Item</h3>
          <form onSubmit={handleAddItem}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1fr", gap:"12px", marginBottom:"12px" }}>
              <input placeholder="Item name *" value={newItem.name} required onChange={e=>setNewItem({...newItem,name:e.target.value})} onFocus={()=>setFocusedInput("an")} onBlur={()=>setFocusedInput(null)} style={inp("an")} />
              <input placeholder="Price *" type="number" step="0.01" min="0" value={newItem.price} required onChange={e=>setNewItem({...newItem,price:e.target.value})} onFocus={()=>setFocusedInput("ap")} onBlur={()=>setFocusedInput(null)} style={inp("ap")} />
              <select value={newItem.categoryName} onChange={e=>setNewItem({...newItem,categoryName:e.target.value})} style={{ ...inp("ac"), cursor:"pointer" }}>
                <option value="">-- Category --</option>
                {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
              </select>
              <input placeholder="Description" value={newItem.description} onChange={e=>setNewItem({...newItem,description:e.target.value})} onFocus={()=>setFocusedInput("ad")} onBlur={()=>setFocusedInput(null)} style={inp("ad")} />
            </div>
            <div style={{ display:"flex", justifyContent:"flex-end" }}>
              <button type="submit" style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"11px 28px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>+ Add Item</button>
            </div>
          </form>
        </div>
      )}

      {loading && <div style={{ width:"36px", height:"36px", border:"3px solid rgba(255,220,120,0.1)", borderTopColor:"#f5a623", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"60px auto" }} />}

      {/* ── Menu Grid ── */}
      {!loading && (
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(250px,1fr))", gap:"20px", padding:"0 40px 60px" }}>
          {filtered.map((item, i) => {
            const qty = getQty(item.id);
            const catColor = getCatColor(item) || "#f5a623";
            const catBg = catColor + "30";
            const catBorder = catColor + "80";
            return (
              <div key={item.id} style={{ background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:"16px", overflow:"hidden", animation:`fadeUp 0.45s ease ${i*0.05}s both`, display:"flex", flexDirection:"column" }}>
                <div style={{ height:"110px", background:`linear-gradient(135deg,#1e1a16,#252018)`, borderBottom:`2px solid ${catColor}22`, display:"flex", alignItems:"center", justifyContent:"center", position:"relative", flexShrink:0 }}>
                  <span style={{ fontSize:"52px" }}>{getEmoji(item.id)}</span>
                  {getCatName(item) && (
                    <span style={{ position:"absolute", top:"10px", right:"10px", background:catBg, border:`1px solid ${catBorder}`, color:catColor, fontSize:"10px", fontWeight:"700", padding:"3px 10px", borderRadius:"99px", textTransform:"uppercase", letterSpacing:"0.5px" }}>
                      {getCatName(item)}
                    </span>
                  )}
                </div>
                <div style={{ padding:"16px 18px", display:"flex", flexDirection:"column", flex:1 }}>
                  <h3 style={{ fontFamily:FONT_H, fontSize:"17px", fontWeight:"700", color:"var(--text-primary)", marginBottom:"6px" }}>{item.name}</h3>
                  {item.description && <p style={{ color:"var(--text-secondary)", fontSize:"13px", lineHeight:"1.5", marginBottom:"10px", flex:1 }}>{item.description}</p>}
                  {!item.description && <div style={{ flex:1 }} />}
                  <p style={{ color:"#f5a623", fontSize:"20px", fontWeight:"700", marginBottom:"14px", fontFamily:FONT_H }}>₹{parseFloat(item.price).toFixed(2)}</p>

                  {role !== "Admin" ? (() => {
                    const limit = item.stockLimit ?? -1;
                    const notAvailable = limit === 0;
                    const atLimit = limit > 0 && qty >= limit;
                    if (notAvailable) return (
                      <div style={{ width:"100%", background:"rgba(100,100,100,0.12)", border:"1.5px solid rgba(150,150,150,0.2)", borderRadius:"9px", padding:"11px", textAlign:"center", color:"var(--text-muted)", fontSize:"13px", fontWeight:"600", cursor:"not-allowed" }}>
                        🚫 Not Available
                      </div>
                    );
                    return qty === 0 ? (
                      <button onClick={()=>setQty(item,1)}
                        style={{ width:"100%", background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"11px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
                        Add to Cart
                      </button>
                    ) : (
                      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", background:"rgba(245,166,35,0.06)", border:`1.5px solid ${atLimit?"rgba(232,84,84,0.35)":"rgba(245,166,35,0.2)"}`, borderRadius:"10px", padding:"8px 14px" }}>
                        <span style={{ color: atLimit?"#e85454":"var(--text-secondary)", fontSize:"12px", fontWeight:"600" }}>{atLimit ? `⚠️ Max ${limit}` : "In cart"}</span>
                        <QtyControl item={item} size="md" />
                      </div>
                    );
                  })() : (
                    <div style={{ display:"flex", gap:"8px" }}>
                      <button onClick={()=>openEdit(item)} style={{ flex:1, background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"10px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>✏️ Edit</button>
                      <button onClick={()=>handleDelete(item.id)} style={{ flex:1, background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.3)", color:"#e85454", padding:"10px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>🗑 Delete</button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div style={{ gridColumn:"1/-1", textAlign:"center", color:"var(--text-muted)", padding:"60px 20px" }}>
              <div style={{ fontSize:"48px", marginBottom:"12px" }}>🍽️</div>
              <p style={{ fontSize:"16px" }}>No items in <strong style={{ color:"var(--text-secondary)" }}>{selectedCat}</strong></p>
              {selectedCat !== "All" && (
                <button onClick={()=>setSelectedCat("All")} style={{ marginTop:"14px", background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"8px 20px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Show all items</button>
              )}
            </div>
          )}
        </div>
      )}

      {/* ── Edit Modal (Admin) ── */}
      {editItem && (
        <div onClick={()=>setEditItem(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(4px)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", animation:"fadeIn 0.2s ease", padding:"20px" }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"var(--bg-card)", border:"1px solid var(--border-strong)", borderRadius:"18px", padding:"32px", width:"100%", maxWidth:"480px", boxShadow:"0 24px 64px rgba(0,0,0,0.6)" }}>
            <h2 style={{ fontFamily:FONT_H, fontSize:"22px", color:"var(--text-primary)", marginBottom:"22px" }}>Edit Item</h2>
            <form onSubmit={handleEditSave} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
              {[{n:"en",label:"Item Name",key:"name",type:"text"},{n:"ep",label:"Price",key:"price",type:"number"},{n:"ed",label:"Description",key:"description",type:"text"}].map(f=>(
                <div key={f.n}>
                  <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"var(--text-secondary)", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>{f.label}</label>
                  <input type={f.type} value={editItem[f.key]||""} required={["en","ep"].includes(f.n)}
                    onChange={e=>setEditItem({...editItem,[f.key]:e.target.value})}
                    onFocus={()=>setFocusedInput(f.n)} onBlur={()=>setFocusedInput(null)}
                    style={{ ...inp(f.n), boxSizing:"border-box" }} />
                </div>
              ))}
              <div>
                <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"var(--text-secondary)", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Category</label>
                <select value={editItem.categoryName} onChange={e=>setEditItem({...editItem,categoryName:e.target.value})} style={{ ...inp("ec"), cursor:"pointer", boxSizing:"border-box" }}>
                  <option value="">-- Category --</option>
                  {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
              </div>
              <div style={{ display:"flex", gap:"10px", marginTop:"6px" }}>
                <button type="button" onClick={()=>setEditItem(null)} style={{ flex:1, background:"transparent", border:"1.5px solid rgba(255,220,120,0.15)", color:"var(--text-secondary)", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Cancel</button>
                <button type="submit" style={{ flex:2, background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Delivery Mode Popup ── */}
      {showDeliveryPopup && (
        <div onClick={()=>setShowDeliveryPopup(false)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.82)", backdropFilter:"blur(6px)", zIndex:4000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"var(--bg-card)", border:"1px solid rgba(245,166,35,0.2)", borderRadius:"20px", width:"100%", maxWidth:"400px", padding:"32px", boxShadow:"0 32px 80px rgba(0,0,0,0.7)" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"24px" }}>
              <h2 style={{ fontFamily:FONT_H, fontSize:"22px", fontWeight:"700", color:"var(--text-primary)", margin:0 }}>🚚 Delivery Mode</h2>
              <button onClick={()=>setShowDeliveryPopup(false)} style={{ background:"none", border:"none", color:"var(--text-muted)", fontSize:"20px", cursor:"pointer" }}>✕</button>
            </div>
            <p style={{ color:"var(--text-muted)", fontSize:"14px", marginBottom:"20px" }}>How would you like to receive your order?</p>
            <div style={{ display:"flex", flexDirection:"column", gap:"10px", marginBottom:"24px" }}>
              {deliveryModes.length === 0 ? (
                <div style={{ color:"var(--text-muted)", fontSize:"14px", textAlign:"center", padding:"20px" }}>No delivery modes available. Ask admin to add them.</div>
              ) : deliveryModes.map(dm => (
                <label key={dm.id} style={{ display:"flex", alignItems:"flex-start", gap:"14px", background:selectedMode===dm.name?"rgba(245,166,35,0.08)":"var(--bg-card2)", border:selectedMode===dm.name?"1.5px solid rgba(245,166,35,0.4)":"1.5px solid rgba(255,220,120,0.08)", borderRadius:"12px", padding:"16px", cursor:"pointer", transition:"all 0.2s" }}>
                  <input type="radio" name="deliveryMode" value={dm.name} checked={selectedMode===dm.name} onChange={()=>setSelectedMode(dm.name)} style={{ marginTop:"2px", accentColor:"#f5a623" }} />
                  <div>
                    <div style={{ color:"var(--text-primary)", fontWeight:"600", fontSize:"15px" }}>🚚 {dm.name}</div>
                    {dm.description && <div style={{ color:"var(--text-muted)", fontSize:"13px", marginTop:"3px" }}>{dm.description}</div>}
                  </div>
                </label>
              ))}
            </div>
            <button onClick={handleConfirmOrder} disabled={!selectedMode}
              style={{ width:"100%", background:selectedMode?"linear-gradient(135deg,#f5a623,#e8420a)":"rgba(255,220,120,0.1)", border:"none", color:selectedMode?"#fff":"var(--text-muted)", padding:"14px", borderRadius:"11px", fontSize:"15px", fontWeight:"700", cursor:selectedMode?"pointer":"not-allowed", fontFamily:FONT, transition:"all 0.2s" }}>
              Place Order
            </button>
          </div>
        </div>
      )}

      {/* ── Cart Sidebar ── */}
      {showCart && (
        <div onClick={()=>setShowCart(false)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.7)", backdropFilter:"blur(4px)", zIndex:2000, display:"flex", justifyContent:"flex-end", animation:"fadeIn 0.2s ease" }}>
          <div onClick={e=>e.stopPropagation()} style={{ width:"360px", background:"var(--bg-card)", borderLeft:"1px solid rgba(255,220,120,0.1)", height:"100%", display:"flex", flexDirection:"column", animation:"slideIn 0.3s ease" }}>
            <div style={{ padding:"24px", borderBottom:"1px solid var(--border))", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <h2 style={{ fontFamily:FONT_H, fontSize:"22px", fontWeight:"700", color:"var(--text-primary)" }}>Your Cart</h2>
              <button onClick={()=>setShowCart(false)} style={{ background:"none", border:"none", color:"var(--text-muted)", fontSize:"18px", cursor:"pointer" }}>✕</button>
            </div>
            {cart.length === 0 ? (
              <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", color:"var(--text-muted)" }}>
                <div style={{ fontSize:"48px", marginBottom:"12px" }}>🛒</div>
                <p>Your cart is empty</p>
              </div>
            ) : (
              <>
                <div style={{ flex:1, overflowY:"auto", padding:"16px" }}>
                  {cart.map(item => (
                    <div key={item.id} style={{ background:"var(--bg-card2)", borderRadius:"12px", marginBottom:"10px", padding:"14px 16px", border:"1px solid var(--border)" }}>
                      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"10px" }}>
                        <div>
                          <div style={{ color:"var(--text-primary)", fontSize:"14px", fontWeight:"600", marginBottom:"3px" }}>{item.name}</div>
                          <div style={{ color:"var(--text-muted)", fontSize:"12px" }}>₹{parseFloat(item.price).toFixed(2)} each</div>
                        </div>
                        <div style={{ color:"#f5a623", fontSize:"15px", fontWeight:"700" }}>₹{(item.price * item.qty).toFixed(2)}</div>
                      </div>
                      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                        <QtyControl item={item} size="lg" />
                        <button onClick={()=>setCart(prev=>prev.filter(c=>c.id!==item.id))} style={{ background:"none", border:"none", color:"var(--text-muted)", cursor:"pointer", fontSize:"12px", fontFamily:FONT }}>Remove</button>
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{ padding:"20px 24px", borderTop:"1px solid var(--border)" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"16px" }}>
                    <span style={{ color:"var(--text-secondary)", fontSize:"16px", fontWeight:"600" }}>Total</span>
                    <span style={{ color:"#f5a623", fontSize:"22px", fontWeight:"700", fontFamily:FONT_H }}>₹{cartTotal.toFixed(2)}</span>
                  </div>
                  <button onClick={handlePlaceOrder}
                    style={{ width:"100%", background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"14px", borderRadius:"11px", fontSize:"15px", fontWeight:"700", cursor:"pointer", fontFamily:FONT, boxShadow:"0 4px 20px rgba(245,166,35,0.3)" }}>
                    Continue →
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ── Limit reached popup ── */}
      {limitAlert && (
        <div onClick={() => setLimitAlert(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(6px)", zIndex:6000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"var(--bg-card)", border:"1.5px solid rgba(232,84,84,0.4)", borderRadius:"20px", padding:"36px 40px", maxWidth:"380px", width:"100%", textAlign:"center", boxShadow:"0 24px 60px rgba(0,0,0,0.7)" }}>
            <div style={{ fontSize:"48px", marginBottom:"16px" }}>⚠️</div>
            <h2 style={{ fontFamily:FONT_H, fontSize:"22px", color:"var(--text-primary)", marginBottom:"10px" }}>Limit Reached</h2>
            <p style={{ color:"var(--text-secondary)", fontSize:"15px", lineHeight:"1.6", marginBottom:"24px" }}>
              You've reached the maximum limit of <strong style={{ color:"#f5a623" }}>{limitAlert.limit}</strong> for <strong style={{ color:"var(--text-primary)" }}>"{limitAlert.name}"</strong>.
            </p>
            <button onClick={() => setLimitAlert(null)} style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"12px 40px", borderRadius:"10px", fontSize:"15px", fontWeight:"700", cursor:"pointer", fontFamily:FONT }}>
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Menu;



// import { useEffect, useState } from "react";
// import { getAllMenu, addMenuItem, deleteMenuItem, updateMenuItem, getAllCategories, addCategory } from "../service/menu";
// import { addOrder, getDeliveryModes } from "../service/order";
// import { useNavigate } from "react-router-dom";
// import UserNavbar from "../components/UserNavbar";

// const EMOJIS = ["","🍕","🧀","🍗","🍰","🍖","🥓","🫑","🧅","🌶️","🥩","🌮"];
// const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
// const FONT_H = "Georgia,'Times New Roman',serif";

// const getCatName = (item) => {
//   if (!item.category) return "";
//   const raw = typeof item.category === "string" ? item.category : (item.category.name || "");
//   return raw.trim();
// };
// const getCatColor = (item) => {
//   if (!item.category || typeof item.category === "string") return null;
//   return item.category.color || null;
// };
// const getCatColorByName = (catName, categoriesList) => {
//   if (!catName || catName === "All") return "#f5a623";
//   const match = categoriesList.find(c => c.name.toLowerCase() === catName.toLowerCase());
//   return match?.color || "#f5a623";
// };
// const getEmoji = (itemId) => EMOJIS[Math.abs(Number(itemId) % EMOJIS.length)];

// function Menu() {
//   const [menu,              setMenu]             = useState([]);
//   const [categories,        setCategories]       = useState([]);
//   const [cart,              setCart]             = useState([]);
//   const [loading,           setLoading]          = useState(true);
//   const [search,            setSearch]           = useState("");
//   const [selectedCat,       setSelectedCat]      = useState("All");
//   const [showCart,          setShowCart]         = useState(false);
//   const [showAddForm,       setShowAddForm]      = useState(false);
//   const [newItem,           setNewItem]          = useState({ name:"", price:"", categoryName:"", description:"" });
//   const [editItem,          setEditItem]         = useState(null);
//   const [orderMsg,          setOrderMsg]         = useState("");
//   const [focusedInput,      setFocusedInput]     = useState(null);
//   const [deliveryModes,     setDeliveryModes]    = useState([]);
//   const [showDeliveryPopup, setShowDeliveryPopup]= useState(false);
//   const [selectedMode,      setSelectedMode]     = useState("");
//   const navigate = useNavigate();
//   const role = localStorage.getItem("role");

//   useEffect(() => {
//     if (!localStorage.getItem("token")) { navigate("/login"); return; }
//     fetchAll();
//   }, [navigate]);

//   const fetchAll = () => {
//     setLoading(true);
//     Promise.all([
//       getAllMenu().then(r => setMenu(r.data)),
//       getAllCategories().then(r => setCategories(r.data)).catch(() => {}),
//       getDeliveryModes().then(r => setDeliveryModes(r.data)).catch(() => {}),
//     ]).finally(() => setLoading(false));
//   };

//   const catNames = [
//     "All",
//     ...Array.from(new Set([
//       ...categories.map(c => c.name).filter(Boolean),
//       ...menu.map(getCatName).filter(Boolean),
//     ])),
//   ];

//   const filtered = menu
//     .filter(i => selectedCat === "All" || getCatName(i).toLowerCase() === selectedCat.toLowerCase())
//     .filter(i => i.name?.toLowerCase().includes(search.toLowerCase()));

//   const getQty = (itemId) => cart.find(c => c.id === itemId)?.qty || 0;

//   const setQty = (item, delta) => {
//     setCart(prev => {
//       const existing = prev.find(c => c.id === item.id);
//       const newQty = (existing?.qty || 0) + delta;
//       if (newQty <= 0) return prev.filter(c => c.id !== item.id);
//       if (existing)    return prev.map(c => c.id === item.id ? { ...c, qty: newQty } : c);
//       const safeItem = { id: item.id, name: item.name, price: item.price, description: item.description || "", qty: 1 };
//       return [...prev, safeItem];
//     });
//   };

//   const cartTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
//   const cartCount = cart.reduce((s, i) => s + i.qty, 0);

//   // "Continue →" opens delivery popup
//   const handlePlaceOrder = () => { if (cart.length) setShowDeliveryPopup(true); };

//   // Final confirm after mode selected
//   const handleConfirmOrder = async () => {
//     if (!selectedMode) return;
//     try {
//       const username  = localStorage.getItem("username") || "";
//       const userEmail = localStorage.getItem("userEmail") || "";
//       // map cart items to include category string
//       const cartWithCategory = cart.map(item => ({
//         ...item,
//         category: getCatName(item) || item.category || ""
//       }));
//       await addOrder({ items: cartWithCategory, total: cartTotal, deliveryMode: selectedMode, username, userEmail });
//       setOrderMsg("Order placed! 🎉");
//       setCart([]); setShowCart(false); setShowDeliveryPopup(false); setSelectedMode("");
//       setTimeout(() => setOrderMsg(""), 4000);
//     } catch { setOrderMsg("Failed to place order."); }
//   };

//   const handleAddItem = async (e) => {
//     e.preventDefault();
//     try {
//       await addMenuItem({ ...newItem, price: parseFloat(newItem.price) });
//       setNewItem({ name:"", price:"", categoryName:"", description:"" });
//       setShowAddForm(false);
//       const [rm, rc] = await Promise.all([getAllMenu(), getAllCategories()]);
//       setMenu(rm.data); setCategories(rc.data);
//     } catch(err) { console.error(err); }
//   };

//   const handleDelete = async (id) => {
//     if (!window.confirm("Delete this item?")) return;
//     try { await deleteMenuItem(id); const r = await getAllMenu(); setMenu(r.data); }
//     catch(err) { console.error(err); }
//   };

//   const openEdit = (item) => {
//     let resolvedCatName = "";
//     if (item.category) {
//       if (typeof item.category === "string") resolvedCatName = item.category;
//       else if (item.category.id) {
//         const match = categories.find(c => c.id === item.category.id);
//         resolvedCatName = match ? match.name : (item.category.name || "");
//       }
//     }
//     setEditItem({ id:item.id, name:item.name, price:item.price, description:item.description||"", categoryName:resolvedCatName });
//   };

//   const handleEditSave = async (e) => {
//     e.preventDefault();
//     try {
//       await updateMenuItem(editItem.id, { name:editItem.name, price:parseFloat(editItem.price), description:editItem.description, categoryName:editItem.categoryName });
//       setEditItem(null);
//       const [rm, rc] = await Promise.all([getAllMenu(), getAllCategories()]);
//       setMenu(rm.data); setCategories(rc.data);
//     } catch(err) { console.error(err); }
//   };

//   const inp = (name) => ({
//     background:"var(--input-bg)", border:focusedInput===name?"1.5px solid #f5a623":"1.5px solid var(--input-border)",
//     boxShadow:focusedInput===name?"0 0 0 3px rgba(245,166,35,0.1)":"none",
//     color:"var(--input-color)", borderRadius:"9px", padding:"10px 14px", fontSize:"14px", fontFamily:FONT, outline:"none", width:"100%",
//   });

//   const QtyControl = ({ item, size="md" }) => {
//     const qty = getQty(item.id);
//     const big = size === "lg";
//     const btnStyle = (color) => ({
//       width: big?"36px":"30px", height:big?"36px":"30px",
//       background: color==="red" ? "rgba(232,84,84,0.15)" : "rgba(245,166,35,0.15)",
//       border: color==="red" ? "1px solid rgba(232,84,84,0.3)" : "1px solid rgba(245,166,35,0.3)",
//       color: color==="red" ? "#e85454" : "#f5a623",
//       borderRadius:"8px", display:"inline-flex", alignItems:"center", justifyContent:"center",
//       cursor:"pointer", fontSize: big?"18px":"16px", fontWeight:"700", fontFamily:FONT, flexShrink:0,
//     });
//     return (
//       <div style={{ display:"flex", alignItems:"center", gap:big?"12px":"8px" }}>
//         <button onClick={()=>setQty(item,-1)} style={btnStyle("red")}>−</button>
//         <span style={{ color:"var(--text-primary)", fontSize:big?"16px":"14px", fontWeight:"700", minWidth:"20px", textAlign:"center", fontFamily:FONT_H }}>{qty}</span>
//         <button onClick={()=>setQty(item,1)} style={btnStyle("orange")}>+</button>
//       </div>
//     );
//   };

//   return (
//     <div style={{ minHeight:"100vh", background:"var(--bg-base)", fontFamily:FONT }}>
//       <UserNavbar />

//       {/* ── Header ── */}
//       <div style={{ padding:"36px 40px 20px", display:"flex", justifyContent:"space-between", alignItems:"flex-end", flexWrap:"wrap", gap:"16px", borderBottom:"1px solid rgba(245,166,35,0.06)" }}>
//         <div>
//           <h1 style={{ fontFamily:FONT_H, fontSize:"36px", fontWeight:"900", color:"var(--text-primary)" }}>Our Menu</h1>
//           <p style={{ color:"var(--text-muted)", fontSize:"14px", marginTop:"4px" }}>{filtered.length} of {menu.length} items</p>
//         </div>
//         <div style={{ display:"flex", gap:"10px", alignItems:"center", flexWrap:"wrap" }}>
//           <input placeholder="🔍  Search..." value={search} onChange={e=>setSearch(e.target.value)}
//             onFocus={()=>setFocusedInput("search")} onBlur={()=>setFocusedInput(null)}
//             style={{ ...inp("search"), width:"200px" }} />
//           {role === "Admin" && (
//             <button onClick={()=>{ setShowAddForm(!showAddForm); setEditItem(null); }}
//               style={{ background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"10px 18px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
//               {showAddForm ? "Cancel" : "+ Add Item"}
//             </button>
//           )}
//           {role !== "Admin" && (
//             <button onClick={()=>setShowCart(true)}
//               style={{ background:"rgba(245,166,35,0.12)", border:"1.5px solid rgba(245,166,35,0.25)", color:"#f5a623", padding:"10px 18px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT, position:"relative" }}>
//               🛒 Cart
//               {cartCount > 0 && (
//                 <span style={{ position:"absolute", top:"-8px", right:"-8px", background:"#e8420a", color:"#fff", fontSize:"10px", fontWeight:"700", width:"18px", height:"18px", borderRadius:"50%", display:"inline-flex", alignItems:"center", justifyContent:"center" }}>{cartCount}</span>
//               )}
//             </button>
//           )}
//         </div>
//       </div>

//       {/* ── Category Filter Bar ── */}
//       <div style={{ padding:"16px 40px", display:"flex", gap:"10px", flexWrap:"wrap", alignItems:"center", borderBottom:"1px solid rgba(245,166,35,0.06)", marginBottom:"28px" }}>
//         <span style={{ color:"var(--text-muted)", fontSize:"12px", fontWeight:"600", textTransform:"uppercase", letterSpacing:"0.5px" }}>Filter:</span>
//         {catNames.map(cat => {
//           const cc = getCatColorByName(cat, categories);
//           const isActive = selectedCat === cat;
//           return (
//             <button key={cat} onClick={()=>setSelectedCat(cat)} style={{
//               background: isActive ? cc : "var(--bg-card2)",
//               border: isActive ? "none" : `1.5px solid ${cc}33`,
//               color: isActive ? "#fff" : cc,
//               padding:"8px 18px", borderRadius:"99px", fontSize:"13px", fontWeight:"600",
//               cursor:"pointer", fontFamily:FONT,
//               boxShadow: isActive ? `0 2px 14px ${cc}55` : "none",
//             }}>
//               {cat === "All" ? "🍽️ All Items" : cat}
//             </button>
//           );
//         })}
//       </div>

//       {/* ── Order Success ── */}
//       {orderMsg && (
//         <div style={{ margin:"0 40px 24px", background:"rgba(76,175,125,0.1)", border:"1px solid rgba(76,175,125,0.3)", color:"#4caf7d", padding:"13px 20px", borderRadius:"10px", display:"flex", justifyContent:"space-between", alignItems:"center", fontSize:"14px" }}>
//           <span>{orderMsg}</span>
//           <span onClick={()=>navigate("/orders")} style={{ cursor:"pointer", fontWeight:"600", textDecoration:"underline" }}>View Orders →</span>
//         </div>
//       )}

//       {/* ── Add Item Form (Admin) ── */}
//       {showAddForm && role === "Admin" && (
//         <div style={{ margin:"0 40px 28px", background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:"14px", padding:"24px" }}>
//           <h3 style={{ fontFamily:FONT_H, fontSize:"18px", color:"var(--text-primary)", marginBottom:"16px" }}>Add New Item</h3>
//           <form onSubmit={handleAddItem}>
//             <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1fr", gap:"12px", marginBottom:"12px" }}>
//               <input placeholder="Item name *" value={newItem.name} required onChange={e=>setNewItem({...newItem,name:e.target.value})} onFocus={()=>setFocusedInput("an")} onBlur={()=>setFocusedInput(null)} style={inp("an")} />
//               <input placeholder="Price *" type="number" step="0.01" min="0" value={newItem.price} required onChange={e=>setNewItem({...newItem,price:e.target.value})} onFocus={()=>setFocusedInput("ap")} onBlur={()=>setFocusedInput(null)} style={inp("ap")} />
//               <select value={newItem.categoryName} onChange={e=>setNewItem({...newItem,categoryName:e.target.value})} style={{ ...inp("ac"), cursor:"pointer" }}>
//                 <option value="">-- Category --</option>
//                 {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
//               </select>
//               <input placeholder="Description" value={newItem.description} onChange={e=>setNewItem({...newItem,description:e.target.value})} onFocus={()=>setFocusedInput("ad")} onBlur={()=>setFocusedInput(null)} style={inp("ad")} />
//             </div>
//             <div style={{ display:"flex", justifyContent:"flex-end" }}>
//               <button type="submit" style={{ background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"11px 28px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>+ Add Item</button>
//             </div>
//           </form>
//         </div>
//       )}

//       {loading && <div style={{ width:"36px", height:"36px", border:"3px solid rgba(255,220,120,0.1)", borderTopColor:"#f5a623", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"60px auto" }} />}

//       {/* ── Menu Grid ── */}
//       {!loading && (
//         <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(250px,1fr))", gap:"20px", padding:"0 40px 60px" }}>
//           {filtered.map((item, i) => {
//             const qty = getQty(item.id);
//             const catColor = getCatColor(item) || "#f5a623";
//             const catBg = catColor + "30";
//             const catBorder = catColor + "80";
//             return (
//               <div key={item.id} style={{ background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:"16px", overflow:"hidden", animation:`fadeUp 0.45s ease ${i*0.05}s both`, display:"flex", flexDirection:"column" }}>
//                 <div style={{ height:"110px", background:`linear-gradient(135deg,#1e1a16,#252018)`, borderBottom:`2px solid ${catColor}22`, display:"flex", alignItems:"center", justifyContent:"center", position:"relative", flexShrink:0 }}>
//                   <span style={{ fontSize:"52px" }}>{getEmoji(item.id)}</span>
//                   {getCatName(item) && (
//                     <span style={{ position:"absolute", top:"10px", right:"10px", background:catBg, border:`1px solid ${catBorder}`, color:catColor, fontSize:"10px", fontWeight:"700", padding:"3px 10px", borderRadius:"99px", textTransform:"uppercase", letterSpacing:"0.5px" }}>
//                       {getCatName(item)}
//                     </span>
//                   )}
//                 </div>
//                 <div style={{ padding:"16px 18px", display:"flex", flexDirection:"column", flex:1 }}>
//                   <h3 style={{ fontFamily:FONT_H, fontSize:"17px", fontWeight:"700", color:"var(--text-primary)", marginBottom:"6px" }}>{item.name}</h3>
//                   {item.description && <p style={{ color:"var(--text-secondary)", fontSize:"13px", lineHeight:"1.5", marginBottom:"10px", flex:1 }}>{item.description}</p>}
//                   {!item.description && <div style={{ flex:1 }} />}
//                   <p style={{ color:"#f5a623", fontSize:"20px", fontWeight:"700", marginBottom:"14px", fontFamily:FONT_H }}>₹{parseFloat(item.price).toFixed(2)}</p>

//                   {role !== "Admin" ? (
//                     qty === 0 ? (
//                       <button onClick={()=>setQty(item,1)}
//                         style={{ width:"100%", background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"11px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>
//                         Add to Cart
//                       </button>
//                     ) : (
//                       <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", background:"rgba(245,166,35,0.06)", border:"1.5px solid rgba(245,166,35,0.2)", borderRadius:"10px", padding:"8px 14px" }}>
//                         <span style={{ color:"var(--text-secondary)", fontSize:"12px", fontWeight:"600" }}>In cart</span>
//                         <QtyControl item={item} size="md" />
//                       </div>
//                     )
//                   ) : (
//                     <div style={{ display:"flex", gap:"8px" }}>
//                       <button onClick={()=>openEdit(item)} style={{ flex:1, background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"10px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>✏️ Edit</button>
//                       <button onClick={()=>handleDelete(item.id)} style={{ flex:1, background:"rgba(232,84,84,0.1)", border:"1px solid rgba(232,84,84,0.3)", color:"#e85454", padding:"10px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>🗑 Delete</button>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             );
//           })}
//           {filtered.length === 0 && (
//             <div style={{ gridColumn:"1/-1", textAlign:"center", color:"var(--text-muted)", padding:"60px 20px" }}>
//               <div style={{ fontSize:"48px", marginBottom:"12px" }}>🍽️</div>
//               <p style={{ fontSize:"16px" }}>No items in <strong style={{ color:"var(--text-secondary)" }}>{selectedCat}</strong></p>
//               {selectedCat !== "All" && (
//                 <button onClick={()=>setSelectedCat("All")} style={{ marginTop:"14px", background:"rgba(245,166,35,0.1)", border:"1.5px solid rgba(245,166,35,0.3)", color:"#f5a623", padding:"8px 20px", borderRadius:"9px", fontSize:"13px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Show all items</button>
//               )}
//             </div>
//           )}
//         </div>
//       )}

//       {/* ── Edit Modal (Admin) ── */}
//       {editItem && (
//         <div onClick={()=>setEditItem(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(4px)", zIndex:3000, display:"flex", alignItems:"center", justifyContent:"center", animation:"fadeIn 0.2s ease", padding:"20px" }}>
//           <div onClick={e=>e.stopPropagation()} style={{ background:"var(--bg-card)", border:"1px solid var(--border-strong)", borderRadius:"18px", padding:"32px", width:"100%", maxWidth:"480px", boxShadow:"0 24px 64px rgba(0,0,0,0.6)" }}>
//             <h2 style={{ fontFamily:FONT_H, fontSize:"22px", color:"var(--text-primary)", marginBottom:"22px" }}>Edit Item</h2>
//             <form onSubmit={handleEditSave} style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
//               {[{n:"en",label:"Item Name",key:"name",type:"text"},{n:"ep",label:"Price",key:"price",type:"number"},{n:"ed",label:"Description",key:"description",type:"text"}].map(f=>(
//                 <div key={f.n}>
//                   <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"var(--text-secondary)", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>{f.label}</label>
//                   <input type={f.type} value={editItem[f.key]||""} required={["en","ep"].includes(f.n)}
//                     onChange={e=>setEditItem({...editItem,[f.key]:e.target.value})}
//                     onFocus={()=>setFocusedInput(f.n)} onBlur={()=>setFocusedInput(null)}
//                     style={{ ...inp(f.n), boxSizing:"border-box" }} />
//                 </div>
//               ))}
//               <div>
//                 <label style={{ display:"block", fontSize:"11px", fontWeight:"700", color:"var(--text-secondary)", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:"6px" }}>Category</label>
//                 <select value={editItem.categoryName} onChange={e=>setEditItem({...editItem,categoryName:e.target.value})} style={{ ...inp("ec"), cursor:"pointer", boxSizing:"border-box" }}>
//                   <option value="">-- Category --</option>
//                   {categories.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
//                 </select>
//               </div>
//               <div style={{ display:"flex", gap:"10px", marginTop:"6px" }}>
//                 <button type="button" onClick={()=>setEditItem(null)} style={{ flex:1, background:"transparent", border:"1.5px solid rgba(255,220,120,0.15)", color:"var(--text-secondary)", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Cancel</button>
//                 <button type="submit" style={{ flex:2, background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"12px", borderRadius:"9px", fontSize:"14px", fontWeight:"600", cursor:"pointer", fontFamily:FONT }}>Save Changes</button>
//               </div>
//             </form>
//           </div>
//         </div>
//       )}

//       {/* ── Delivery Mode Popup ── */}
//       {showDeliveryPopup && (
//         <div onClick={()=>setShowDeliveryPopup(false)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.82)", backdropFilter:"blur(6px)", zIndex:4000, display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
//           <div onClick={e=>e.stopPropagation()} style={{ background:"var(--bg-card)", border:"1px solid rgba(245,166,35,0.2)", borderRadius:"20px", width:"100%", maxWidth:"400px", padding:"32px", boxShadow:"0 32px 80px rgba(0,0,0,0.7)" }}>
//             <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"24px" }}>
//               <h2 style={{ fontFamily:FONT_H, fontSize:"22px", fontWeight:"700", color:"var(--text-primary)", margin:0 }}>🚚 Delivery Mode</h2>
//               <button onClick={()=>setShowDeliveryPopup(false)} style={{ background:"none", border:"none", color:"var(--text-muted)", fontSize:"20px", cursor:"pointer" }}>✕</button>
//             </div>
//             <p style={{ color:"var(--text-muted)", fontSize:"14px", marginBottom:"20px" }}>How would you like to receive your order?</p>
//             <div style={{ display:"flex", flexDirection:"column", gap:"10px", marginBottom:"24px" }}>
//               {deliveryModes.length === 0 ? (
//                 <div style={{ color:"var(--text-muted)", fontSize:"14px", textAlign:"center", padding:"20px" }}>No delivery modes available. Ask admin to add them.</div>
//               ) : deliveryModes.map(dm => (
//                 <label key={dm.id} style={{ display:"flex", alignItems:"flex-start", gap:"14px", background:selectedMode===dm.name?"rgba(245,166,35,0.08)":"var(--bg-card2)", border:selectedMode===dm.name?"1.5px solid rgba(245,166,35,0.4)":"1.5px solid rgba(255,220,120,0.08)", borderRadius:"12px", padding:"16px", cursor:"pointer", transition:"all 0.2s" }}>
//                   <input type="radio" name="deliveryMode" value={dm.name} checked={selectedMode===dm.name} onChange={()=>setSelectedMode(dm.name)} style={{ marginTop:"2px", accentColor:"#f5a623" }} />
//                   <div>
//                     <div style={{ color:"var(--text-primary)", fontWeight:"600", fontSize:"15px" }}>🚚 {dm.name}</div>
//                     {dm.description && <div style={{ color:"var(--text-muted)", fontSize:"13px", marginTop:"3px" }}>{dm.description}</div>}
//                   </div>
//                 </label>
//               ))}
//             </div>
//             <button onClick={handleConfirmOrder} disabled={!selectedMode}
//               style={{ width:"100%", background:selectedMode?"linear-gradient(135deg,#f5a623,#e8420a)":"rgba(255,220,120,0.1)", border:"none", color:selectedMode?"#fff":"var(--text-muted)", padding:"14px", borderRadius:"11px", fontSize:"15px", fontWeight:"700", cursor:selectedMode?"pointer":"not-allowed", fontFamily:FONT, transition:"all 0.2s" }}>
//               Place Order
//             </button>
//           </div>
//         </div>
//       )}

//       {/* ── Cart Sidebar ── */}
//       {showCart && (
//         <div onClick={()=>setShowCart(false)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.7)", backdropFilter:"blur(4px)", zIndex:2000, display:"flex", justifyContent:"flex-end", animation:"fadeIn 0.2s ease" }}>
//           <div onClick={e=>e.stopPropagation()} style={{ width:"360px", background:"var(--bg-card)", borderLeft:"1px solid rgba(255,220,120,0.1)", height:"100%", display:"flex", flexDirection:"column", animation:"slideIn 0.3s ease" }}>
//             <div style={{ padding:"24px", borderBottom:"1px solid var(--border))", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
//               <h2 style={{ fontFamily:FONT_H, fontSize:"22px", fontWeight:"700", color:"var(--text-primary)" }}>Your Cart</h2>
//               <button onClick={()=>setShowCart(false)} style={{ background:"none", border:"none", color:"var(--text-muted)", fontSize:"18px", cursor:"pointer" }}>✕</button>
//             </div>
//             {cart.length === 0 ? (
//               <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", color:"var(--text-muted)" }}>
//                 <div style={{ fontSize:"48px", marginBottom:"12px" }}>🛒</div>
//                 <p>Your cart is empty</p>
//               </div>
//             ) : (
//               <>
//                 <div style={{ flex:1, overflowY:"auto", padding:"16px" }}>
//                   {cart.map(item => (
//                     <div key={item.id} style={{ background:"var(--bg-card2)", borderRadius:"12px", marginBottom:"10px", padding:"14px 16px", border:"1px solid var(--border)" }}>
//                       <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"10px" }}>
//                         <div>
//                           <div style={{ color:"var(--text-primary)", fontSize:"14px", fontWeight:"600", marginBottom:"3px" }}>{item.name}</div>
//                           <div style={{ color:"var(--text-muted)", fontSize:"12px" }}>₹{parseFloat(item.price).toFixed(2)} each</div>
//                         </div>
//                         <div style={{ color:"#f5a623", fontSize:"15px", fontWeight:"700" }}>₹{(item.price * item.qty).toFixed(2)}</div>
//                       </div>
//                       <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
//                         <QtyControl item={item} size="lg" />
//                         <button onClick={()=>setCart(prev=>prev.filter(c=>c.id!==item.id))} style={{ background:"none", border:"none", color:"var(--text-muted)", cursor:"pointer", fontSize:"12px", fontFamily:FONT }}>Remove</button>
//                       </div>
//                     </div>
//                   ))}
//                 </div>
//                 <div style={{ padding:"20px 24px", borderTop:"1px solid var(--border)" }}>
//                   <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"16px" }}>
//                     <span style={{ color:"var(--text-secondary)", fontSize:"16px", fontWeight:"600" }}>Total</span>
//                     <span style={{ color:"#f5a623", fontSize:"22px", fontWeight:"700", fontFamily:FONT_H }}>₹{cartTotal.toFixed(2)}</span>
//                   </div>
//                   <button onClick={handlePlaceOrder}
//                     style={{ width:"100%", background:"linear-gradient(135deg,#f5a623,#e8420a)", border:"none", color:"#fff", padding:"14px", borderRadius:"11px", fontSize:"15px", fontWeight:"700", cursor:"pointer", fontFamily:FONT, boxShadow:"0 4px 20px rgba(245,166,35,0.3)" }}>
//                     Continue →
//                   </button>
//                 </div>
//               </>
//             )}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// export default Menu;
