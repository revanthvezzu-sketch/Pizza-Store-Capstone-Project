import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllOrders, getAllBills } from "../service/order";
import { getAllMenu, getAllCategories } from "../service/menu";
import AdminNavbar from "../components/AdminNavbar";

const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";
const BAR_COLORS = ["#f5a623","#6495ed","#4caf7d","#e8420a","#a78bfa","#f472b6","#34d399","#fb923c","#60a5fa","#a3e635"];

// Extract category name regardless of whether it's a string or object
const resolveCat = (rawCat, menuItem) => {
  // 1. Use the stored string on the order item if present
  if (rawCat && typeof rawCat === "string" && rawCat.trim()) return rawCat.trim();
  // 2. Fall back to current menu item's category
  if (menuItem?.category) {
    const c = menuItem.category;
    if (typeof c === "string" && c.trim()) return c.trim();
    if (c?.name && c.name.trim()) return c.name.trim();
  }
  return "Uncategorized";
};

function RevenuePage() {
  const [orders,     setOrders]     = useState([]);
  const [bills,      setBills]      = useState([]);
  const [menuItems,  setMenuItems]  = useState([]);  // for category fallback
  const [categories, setCategories] = useState([]);  // all real categories
  const [loading,    setLoading]    = useState(true);
  const [selCat,     setSelCat]     = useState("All");
  const navigate = useNavigate();

  useEffect(() => {
    if (!localStorage.getItem("token") || localStorage.getItem("role") !== "Admin") {
      navigate("/login"); return;
    }
    Promise.allSettled([getAllOrders(), getAllBills(), getAllMenu(), getAllCategories()])
      .then(([or, br, mr, cr]) => {
        if (or.status === "fulfilled") setOrders(or.value.data   || []);
        if (br.status === "fulfilled") setBills(br.value.data    || []);
        if (mr.status === "fulfilled") setMenuItems(mr.value.data || []);
        if (cr.status === "fulfilled") setCategories(cr.value.data || []);
        setLoading(false);
      });
  }, []);

  // ── Build lookup: menuItemId → menu item (for category fallback) ──
  const menuMap = menuItems.reduce((m, item) => { m[item.id] = item; return m; }, {});

  // ── Bills that count as revenue: everything EXCEPT explicitly DENIED ──
  // null/empty billStatus = old data created before the field existed → treat as approved
  const approvedBills = bills.filter(b => (b.billStatus || "").toUpperCase() !== "DENIED");

  const orderMap = orders.reduce((m, o) => { m[o.id] = o; return m; }, {});

  // ── Build a set of denied order IDs ──
  const deniedOrderIds = new Set(
    bills.filter(b => (b.billStatus || "").toUpperCase() === "DENIED").map(b => b.orderId)
  );

  // ── Build item stats ──
  // orderCount  = times item appeared in any NON-DENIED order (demand metric)
  // totalQty    = units sold only in APPROVED orders (fulfilment metric)
  // totalRevenue= revenue only from APPROVED orders
  const itemStatsMap = {};

  orders.forEach(order => {
    if (!Array.isArray(order.items)) return;
    const isDenied   = deniedOrderIds.has(order.id);
    const isApproved = approvedBills.some(b => b.orderId === order.id);

    order.items.forEach(it => {
      const key     = it.name || `Item #${it.menuItemId}`;
      const menuRef = menuMap[it.menuItemId];
      const cat     = resolveCat(it.category, menuRef);

      if (!itemStatsMap[key]) {
        itemStatsMap[key] = { name: key, category: cat, totalQty: 0, totalRevenue: 0, orderCount: 0 };
      }

      // orderCount: count all orders EXCEPT denied ones
      if (!isDenied) {
        itemStatsMap[key].orderCount += 1;
      }

      // totalQty + revenue: ONLY approved orders
      if (isApproved) {
        itemStatsMap[key].totalQty     += (it.quantity || 1);
        itemStatsMap[key].totalRevenue += parseFloat(it.price || 0) * (it.quantity || 1);
      }
    });
  });

  const allItemStats = Object.values(itemStatsMap).sort((a, b) => b.totalRevenue - a.totalRevenue);

  // ── Build category list: from actual data + all known categories from menu service ──
  const dataCats   = Array.from(new Set(allItemStats.map(i => i.category).filter(Boolean)));
  const menuCats   = categories.map(c => typeof c === "string" ? c : (c.name || "")).filter(Boolean);
  const mergedCats = Array.from(new Set([...dataCats, ...menuCats])).sort();
  const allCategories = ["All", ...mergedCats];

  // ── Filter ──
  const filteredItems = selCat === "All"
    ? allItemStats
    : allItemStats.filter(i => i.category === selCat);

  const totalRevenue    = approvedBills.reduce((s, b) => s + parseFloat(b.grandTotal || 0), 0);
  const categoryRevenue = filteredItems.reduce((s, i) => s + i.totalRevenue, 0);
  const maxRevenue      = filteredItems.length > 0 ? Math.max(...filteredItems.map(i => i.totalRevenue)) : 1;
  const maxQty          = filteredItems.length > 0 ? Math.max(...filteredItems.map(i => i.totalQty))     : 1;
  const totalQty        = filteredItems.reduce((s, i) => s + i.totalQty, 0);

  const topByOrders  = [...filteredItems].sort((a, b) => b.orderCount  - a.orderCount)[0];
  const topByQty     = [...filteredItems].sort((a, b) => b.totalQty    - a.totalQty)[0];
  const topByRevenue = filteredItems[0];

  // Recent revenue per approved order (up to 20, oldest→newest for left-to-right chart)
  const recentRevenue = [...approvedBills].slice(0, 20).reverse().map(b => ({
    label: `#${b.orderId}`,
    value: parseFloat(b.grandTotal || 0),
  }));
  const maxOrderRev = recentRevenue.length > 0 ? Math.max(...recentRevenue.map(r => r.value)) : 1;

  // Chart dimensions
  const CHART_H    = 300;   // total container height px
  const BAR_H      = 200;   // usable bar height px
  const TOP_PAD    = 50;    // space above bars for value labels
  const BOT_PAD    = 50;    // space below bars for x-axis labels

  if (loading) return (
    <div style={{ minHeight:"100vh", background:"var(--bg-base)", fontFamily:FONT }}>
      <AdminNavbar />
      <div style={{ width:"42px", height:"42px", border:"3px solid rgba(255,220,120,0.1)", borderTopColor:"#f5a623", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"140px auto" }} />
    </div>
  );

  return (
    <div style={{ minHeight:"100vh", background:"var(--bg-base)", fontFamily:FONT }}>
      <AdminNavbar />

      {/* ── Header ── */}
      <div style={{ padding:"36px 40px 24px", display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:"20px", borderBottom:"1px solid rgba(245,166,35,0.06)", marginBottom:"32px" }}>
        <div>
          <button onClick={()=>navigate("/admin")} style={{ background:"transparent", border:"1px solid rgba(255,220,120,0.2)", color:"var(--text-secondary)", padding:"9px 20px", borderRadius:"9px", fontSize:"15px", cursor:"pointer", fontFamily:FONT, marginBottom:"16px" }}>
            ← Back to Dashboard
          </button>
          <h1 style={{ fontFamily:FONT_H, fontSize:"42px", fontWeight:"900", color:"var(--text-primary)" }}>Revenue Analytics</h1>
          <p style={{ color:"var(--text-secondary)", fontSize:"17px", marginTop:"8px" }}>
            {approvedBills.length} approved order{approvedBills.length!==1?"s":""} &nbsp;•&nbsp; {allItemStats.length} unique items &nbsp;•&nbsp; {allCategories.length-1} categories
          </p>
        </div>
        <div style={{ background:"linear-gradient(135deg,rgba(245,166,35,0.18),rgba(232,66,10,0.1))", border:"1px solid rgba(245,166,35,0.3)", borderRadius:"20px", padding:"28px 40px", textAlign:"center" }}>
          <div style={{ color:"var(--text-secondary)", fontSize:"14px", textTransform:"uppercase", letterSpacing:"1.5px", marginBottom:"6px" }}>Total Revenue</div>
          <div style={{ color:"#f5a623", fontSize:"48px", fontWeight:"700", fontFamily:FONT_H }}>₹{totalRevenue.toFixed(2)}</div>
        </div>
      </div>

      <div style={{ padding:"0 40px 80px" }}>

        {/* ── Category Filter ── */}
        <div style={{ background:"var(--bg-card)", border:"1px solid var(--border-strong)", borderRadius:"18px", padding:"26px 30px", marginBottom:"32px" }}>
          <div style={{ color:"var(--text-primary)", fontSize:"18px", fontWeight:"700", marginBottom:"18px" }}>🗂️ Filter by Category</div>
          <div style={{ display:"flex", flexWrap:"wrap", gap:"12px" }}>
            {allCategories.map((cat, ci) => {
              const color  = ci === 0 ? "#f5a623" : BAR_COLORS[ci % BAR_COLORS.length];
              const active = selCat === cat;
              const catItems = cat === "All" ? allItemStats : allItemStats.filter(i => i.category === cat);
              const catRev   = catItems.reduce((s,i) => s + i.totalRevenue, 0);
              const catQty   = catItems.reduce((s,i) => s + i.totalQty, 0);
              return (
                <label key={cat} style={{ display:"flex", alignItems:"center", gap:"10px", cursor:"pointer", background:active?`${color}20`:"var(--bg-card2)", border:active?`2px solid ${color}`:"1.5px solid var(--input-border)", borderRadius:"99px", padding:"11px 22px", transition:"all 0.15s", boxShadow:active?`0 0 12px ${color}30`:"none" }}>
                  <input type="radio" name="cat" checked={selCat===cat} onChange={()=>setSelCat(cat)} style={{ accentColor:color, width:"17px", height:"17px" }} />
                  <span style={{ color:active?color:"var(--text-secondary)", fontSize:"16px", fontWeight:active?"700":"500" }}>{cat}</span>
                  <span style={{ background:`${color}25`, color:color, fontSize:"13px", fontWeight:"700", padding:"3px 10px", borderRadius:"99px" }}>
                    ₹{catRev.toFixed(0)}
                  </span>
                  {cat !== "All" && (
                    <span style={{ background:"rgba(255,255,255,0.05)", color:"var(--text-muted)", fontSize:"13px", fontWeight:"600", padding:"3px 10px", borderRadius:"99px" }}>
                      ×{catQty}
                    </span>
                  )}
                </label>
              );
            })}
          </div>

          {selCat !== "All" && (
            <div style={{ marginTop:"20px", padding:"18px 22px", background:"rgba(245,166,35,0.07)", border:"1px solid rgba(245,166,35,0.18)", borderRadius:"12px", display:"flex", gap:"40px", flexWrap:"wrap" }}>
              {[
                { label:"Category Revenue", value:`₹${categoryRevenue.toFixed(2)}`, color:"#f5a623" },
                { label:"Items",            value:filteredItems.length,             color:"var(--text-primary)" },
                { label:"Units Sold",       value:totalQty,                         color:"#6495ed" },
                { label:"% of Total",       value:`${totalRevenue>0?((categoryRevenue/totalRevenue)*100).toFixed(1):0}%`, color:"#4caf7d" },
              ].map(m=>(
                <div key={m.label}>
                  <div style={{ color:"var(--text-muted)", fontSize:"13px", textTransform:"uppercase", letterSpacing:"0.5px" }}>{m.label}</div>
                  <div style={{ color:m.color, fontSize:"28px", fontWeight:"700", fontFamily:FONT_H, marginTop:"4px" }}>{m.value}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── CHART 1: Revenue per Order ── */}
        <div style={{ background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:"18px", padding:"32px", marginBottom:"28px" }}>
          <h2 style={{ fontFamily:FONT_H, fontSize:"26px", color:"var(--text-primary)", marginBottom:"8px" }}>Revenue per Order</h2>
          <p style={{ color:"var(--text-secondary)", fontSize:"16px", marginBottom:"30px" }}>Grand total for each approved order (last 20 shown)</p>

          {recentRevenue.length === 0 ? (
            <div style={{ textAlign:"center", color:"var(--text-muted)", padding:"70px", fontSize:"18px" }}>No approved orders yet</div>
          ) : (
            <div style={{ overflowX:"auto" }}>
              <div style={{ display:"flex", alignItems:"flex-end", gap:"14px", minWidth:`${recentRevenue.length*80}px`, height:`${CHART_H}px`, paddingBottom:`${BOT_PAD}px`, paddingTop:`${TOP_PAD}px`, position:"relative" }}>
                {/* Y-axis gridlines */}
                {[0.25,0.5,0.75,1].map(pct=>(
                  <div key={pct} style={{ position:"absolute", left:0, right:0, bottom:`${BOT_PAD+pct*BAR_H}px`, borderTop:"1px dashed rgba(255,220,120,0.1)", pointerEvents:"none" }}>
                    <span style={{ position:"absolute", left:0, top:"-13px", color:"var(--text-secondary)", fontSize:"14px", fontWeight:"600" }}>₹{(maxOrderRev*pct).toFixed(0)}</span>
                  </div>
                ))}
                {recentRevenue.map((r,ri)=>{
                  const h     = Math.max(8, (r.value/maxOrderRev)*BAR_H);
                  const isMax = r.value === maxOrderRev;
                  return (
                    <div key={ri} style={{ display:"flex", flexDirection:"column", alignItems:"center", flex:"0 0 64px" }}>
                      {/* Value label — always visible above bar */}
                      <div style={{ fontSize: isMax?"16px":"14px", fontWeight:"700", color:isMax?"#f5a623":"var(--text-primary)", marginBottom:"8px", whiteSpace:"nowrap", background:isMax?"rgba(245,166,35,0.18)":"rgba(255,255,255,0.05)", padding:"3px 8px", borderRadius:"6px" }}>
                        ₹{r.value.toFixed(0)}
                      </div>
                      <div style={{ width:"52px", height:`${h}px`, background:isMax?"linear-gradient(180deg,#f5a623,#e8420a)":"linear-gradient(180deg,rgba(245,166,35,0.65),rgba(232,66,10,0.4))", borderRadius:"8px 8px 3px 3px", boxShadow:isMax?"0 0 18px rgba(245,166,35,0.4)":"none", transition:"height 0.5s ease" }} />
                      <div style={{ fontSize:"14px", color:"var(--text-secondary)", marginTop:"10px", fontWeight:"600", whiteSpace:"nowrap" }}>{r.label}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* ── CHART 2: Revenue by Item (horizontal bars) ── */}
        <div style={{ background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:"18px", padding:"32px", marginBottom:"28px" }}>
          <h2 style={{ fontFamily:FONT_H, fontSize:"26px", color:"var(--text-primary)", marginBottom:"8px" }}>
            Revenue by Item {selCat!=="All"?`— ${selCat}`:"(All Categories)"}
          </h2>
          <p style={{ color:"var(--text-secondary)", fontSize:"16px", marginBottom:"30px" }}>Item-level revenue from approved orders</p>

          {filteredItems.length===0 ? (
            <div style={{ textAlign:"center", color:"var(--text-muted)", padding:"70px", fontSize:"18px" }}>No data for this category</div>
          ):(
            <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
              {filteredItems.map((item,ii)=>{
                const color    = BAR_COLORS[ii%BAR_COLORS.length];
                const widthPct = maxRevenue>0?(item.totalRevenue/maxRevenue)*100:0;
                const isTop    = ii===0;
                return (
                  <div key={item.name} style={{ display:"flex", alignItems:"center", gap:"16px" }}>
                    {/* Rank */}
                    <div style={{ width:"32px", flexShrink:0, textAlign:"center" }}>
                      <span style={{ color:isTop?"#f5a623":"var(--text-muted)", fontSize:"18px", fontWeight:"700" }}>#{ii+1}</span>
                    </div>
                    {/* Name + category */}
                    <div style={{ width:"170px", flexShrink:0 }}>
                      <div style={{ color:"var(--text-primary)", fontSize:"16px", fontWeight:"600", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{item.name}</div>
                      <div style={{ color:"var(--text-muted)", fontSize:"13px", marginTop:"3px" }}>📂 {item.category}</div>
                    </div>
                    {/* Bar */}
                    <div style={{ flex:1, background:"var(--bg-card2)", borderRadius:"10px", height:"44px", position:"relative" }}>
                      <div style={{ width:`${widthPct}%`, height:"100%", background:`linear-gradient(90deg,${color},${color}77)`, borderRadius:"10px", minWidth:"6px", transition:"width 0.6s ease" }} />
                      {/* Revenue value — shown outside bar if bar < 35%, inside if wider */}
                      <span style={{
                        position:"absolute",
                        ...(widthPct>35
                          ? { right:"10px", top:"50%", transform:"translateY(-50%)", color:"#fff" }
                          : { left:`calc(${widthPct}% + 10px)`, top:"50%", transform:"translateY(-50%)", color:"var(--text-primary)" }),
                        fontSize:"15px", fontWeight:"700", whiteSpace:"nowrap",
                        textShadow: widthPct>35?"0 1px 4px rgba(0,0,0,0.7)":"none",
                      }}>
                        ₹{item.totalRevenue.toFixed(2)}
                      </span>
                    </div>
                    {/* Qty + orders */}
                    <div style={{ width:"90px", flexShrink:0, textAlign:"right" }}>
                      <div style={{ color:color, fontSize:"16px", fontWeight:"700" }}>×{item.totalQty}</div>
                      <div style={{ color:"var(--text-muted)", fontSize:"13px", marginTop:"2px" }}>{item.orderCount} orders</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ── CHART 3: Units Sold (vertical bars) ── */}
        <div style={{ background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:"18px", padding:"32px", marginBottom:"28px" }}>
          <h2 style={{ fontFamily:FONT_H, fontSize:"26px", color:"var(--text-primary)", marginBottom:"8px" }}>
            Units Sold by Item {selCat!=="All"?`— ${selCat}`:""}
          </h2>
          <p style={{ color:"var(--text-secondary)", fontSize:"16px", marginBottom:"30px" }}>Quantity sold per item across all orders</p>

          {filteredItems.length===0 ? (
            <div style={{ textAlign:"center", color:"var(--text-muted)", padding:"70px", fontSize:"18px" }}>No data</div>
          ):(
            <div style={{ overflowX:"auto" }}>
              <div style={{ display:"flex", alignItems:"flex-end", gap:"16px", minWidth:`${filteredItems.length*90}px`, height:`${CHART_H}px`, paddingBottom:`${BOT_PAD}px`, paddingTop:`${TOP_PAD}px`, position:"relative" }}>
                {[0.25,0.5,0.75,1].map(pct=>(
                  <div key={pct} style={{ position:"absolute", left:0, right:0, bottom:`${BOT_PAD+pct*BAR_H}px`, borderTop:"1px dashed rgba(255,220,120,0.1)", pointerEvents:"none" }}>
                    <span style={{ position:"absolute", left:0, top:"-13px", color:"var(--text-secondary)", fontSize:"14px", fontWeight:"600" }}>{Math.round(maxQty*pct)}</span>
                  </div>
                ))}
                {[...filteredItems].sort((a,b)=>b.totalQty-a.totalQty).map((item,ii)=>{
                  const color = BAR_COLORS[ii%BAR_COLORS.length];
                  const h     = Math.max(8,(item.totalQty/maxQty)*BAR_H);
                  const isMax = item.totalQty===maxQty;
                  return (
                    <div key={item.name} style={{ display:"flex", flexDirection:"column", alignItems:"center", flex:"0 0 76px" }}>
                      {/* Value — always shown, highlighted if max */}
                      <div style={{ fontSize:isMax?"17px":"15px", fontWeight:"700", color:isMax?color:"var(--text-primary)", marginBottom:"8px", whiteSpace:"nowrap", background:isMax?`${color}22`:"rgba(255,255,255,0.05)", padding:"3px 10px", borderRadius:"6px" }}>
                        {item.totalQty}
                      </div>
                      <div style={{ width:"60px", height:`${h}px`, background:`linear-gradient(180deg,${color},${color}55)`, borderRadius:"8px 8px 3px 3px", boxShadow:isMax?`0 0 16px ${color}50`:"none", transition:"height 0.5s ease" }} />
                      <div style={{ fontSize:"13px", color:"var(--text-secondary)", marginTop:"10px", textAlign:"center", width:"80px", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", fontWeight:"500" }}>
                        {item.name}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* ── ANALYSIS ── */}
        <div style={{ background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:"18px", padding:"36px", marginBottom:"28px" }}>
          <h2 style={{ fontFamily:FONT_H, fontSize:"30px", color:"var(--text-primary)", marginBottom:"10px" }}>📊 Revenue Analysis</h2>
          <p style={{ color:"var(--text-secondary)", fontSize:"16px", marginBottom:"32px" }}>
            {selCat==="All" ? "Insights across all categories" : `Insights for: ${selCat}`}
          </p>

          {filteredItems.length===0 ? (
            <div style={{ textAlign:"center", color:"var(--text-muted)", padding:"70px", fontSize:"18px" }}>No data to analyze</div>
          ):(
            <>
              {/* Key metrics */}
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(210px,1fr))", gap:"18px", marginBottom:"36px" }}>
                {[
                  { label:"Revenue",       value:`₹${categoryRevenue.toFixed(2)}`, icon:"💰", color:"#f5a623" },
                  { label:"Units Sold",    value:totalQty,                          icon:"🛒", color:"#6495ed" },
                  { label:"Unique Items",  value:filteredItems.length,              icon:"🍕", color:"#4caf7d" },
                  { label:"Avg / Item",    value:`₹${filteredItems.length>0?(categoryRevenue/filteredItems.length).toFixed(2):"0"}`, icon:"📈", color:"#a78bfa" },
                ].map(m=>(
                  <div key={m.label} style={{ background:"var(--bg-card2)", border:"1px solid rgba(255,220,120,0.07)", borderRadius:"14px", padding:"22px", textAlign:"center" }}>
                    <div style={{ fontSize:"32px", marginBottom:"12px" }}>{m.icon}</div>
                    <div style={{ color:m.color, fontSize:"28px", fontWeight:"700", fontFamily:FONT_H }}>{m.value}</div>
                    <div style={{ color:"var(--text-muted)", fontSize:"14px", textTransform:"uppercase", letterSpacing:"0.5px", marginTop:"8px" }}>{m.label}</div>
                  </div>
                ))}
              </div>

              {/* Insight banners */}
              <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
                {topByOrders && (
                  <div style={{ background:"rgba(245,166,35,0.07)", border:"1px solid rgba(245,166,35,0.2)", borderRadius:"14px", padding:"22px 28px", display:"flex", alignItems:"center", gap:"20px" }}>
                    <span style={{ fontSize:"40px" }}>🏆</span>
                    <div>
                      <div style={{ color:"#f5a623", fontWeight:"700", fontSize:"17px" }}>Most Ordered Item
                        <span style={{ color:"var(--text-muted)", fontWeight:"400", fontSize:"13px", marginLeft:"10px" }}>(times placed in any non-denied order)</span>
                      </div>
                      <div style={{ color:"var(--text-primary)", fontSize:"22px", fontWeight:"700", marginTop:"4px" }}>"{topByOrders.name}"</div>
                      <div style={{ color:"var(--text-secondary)", fontSize:"15px", marginTop:"6px" }}>
                        Placed in <strong style={{ color:"#f5a623" }}>{topByOrders.orderCount}</strong> order{topByOrders.orderCount!==1?"s":""} &nbsp;•&nbsp; Category: <strong style={{ color:"var(--text-primary)" }}>{topByOrders.category}</strong>
                      </div>
                    </div>
                  </div>
                )}
                {topByQty && (
                  <div style={{ background:"rgba(100,149,237,0.07)", border:"1px solid rgba(100,149,237,0.2)", borderRadius:"14px", padding:"22px 28px", display:"flex", alignItems:"center", gap:"20px" }}>
                    <span style={{ fontSize:"40px" }}>📦</span>
                    <div>
                      <div style={{ color:"#6495ed", fontWeight:"700", fontSize:"17px" }}>Most Units Sold
                        <span style={{ color:"var(--text-muted)", fontWeight:"400", fontSize:"13px", marginLeft:"10px" }}>(quantity fulfilled in approved orders only)</span>
                      </div>
                      <div style={{ color:"var(--text-primary)", fontSize:"22px", fontWeight:"700", marginTop:"4px" }}>"{topByQty.name}"</div>
                      <div style={{ color:"var(--text-secondary)", fontSize:"15px", marginTop:"6px" }}>
                        <strong style={{ color:"#6495ed" }}>{topByQty.totalQty}</strong> units actually delivered &nbsp;•&nbsp; ₹{topByQty.totalRevenue.toFixed(2)} revenue
                      </div>
                    </div>
                  </div>
                )}
                {topByRevenue && (
                  <div style={{ background:"rgba(76,175,125,0.07)", border:"1px solid rgba(76,175,125,0.2)", borderRadius:"14px", padding:"22px 28px", display:"flex", alignItems:"center", gap:"20px" }}>
                    <span style={{ fontSize:"40px" }}>💵</span>
                    <div>
                      <div style={{ color:"#4caf7d", fontWeight:"700", fontSize:"17px" }}>Highest Revenue Item</div>
                      <div style={{ color:"var(--text-primary)", fontSize:"22px", fontWeight:"700", marginTop:"4px" }}>"{topByRevenue.name}"</div>
                      <div style={{ color:"var(--text-secondary)", fontSize:"15px", marginTop:"6px" }}>
                        <strong style={{ color:"#4caf7d" }}>₹{topByRevenue.totalRevenue.toFixed(2)}</strong> &nbsp;•&nbsp; {((topByRevenue.totalRevenue/Math.max(categoryRevenue,1))*100).toFixed(1)}% of {selCat==="All"?"total":"category"} revenue
                      </div>
                    </div>
                  </div>
                )}

                {/* Category breakdown when All selected */}
                {selCat==="All" && mergedCats.length>0 && (
                  <div style={{ background:"rgba(167,139,250,0.07)", border:"1px solid rgba(167,139,250,0.2)", borderRadius:"14px", padding:"22px 28px" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:"14px", marginBottom:"20px" }}>
                      <span style={{ fontSize:"36px" }}>📂</span>
                      <div style={{ color:"#a78bfa", fontWeight:"700", fontSize:"20px" }}>Revenue by Category</div>
                    </div>
                    <div style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
                      {mergedCats.map((cat,ci)=>{
                        const catItems = allItemStats.filter(i=>i.category===cat);
                        const catRev   = catItems.reduce((s,i)=>s+i.totalRevenue,0);
                        const catPct   = totalRevenue>0?(catRev/totalRevenue)*100:0;
                        const color    = BAR_COLORS[(ci+1)%BAR_COLORS.length];
                        return (
                          <div key={cat} style={{ display:"flex", alignItems:"center", gap:"16px" }}>
                            <span style={{ width:"130px", color:color, fontSize:"15px", fontWeight:"600", flexShrink:0 }}>{cat}</span>
                            <div style={{ flex:1, background:"var(--bg-card2)", borderRadius:"7px", height:"26px", overflow:"hidden" }}>
                              <div style={{ width:`${catPct}%`, height:"100%", background:color, borderRadius:"7px", minWidth:"4px", transition:"width 0.6s" }} />
                            </div>
                            <span style={{ width:"160px", textAlign:"right", color:"var(--text-primary)", fontSize:"15px", fontWeight:"600", flexShrink:0 }}>
                              ₹{catRev.toFixed(2)} <span style={{ color:"var(--text-muted)", fontSize:"14px" }}>({catPct.toFixed(1)}%)</span>
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Full data table */}
                <div style={{ background:"var(--bg-card2)", borderRadius:"14px", overflow:"hidden", marginTop:"8px" }}>
                  <div style={{ background:"rgba(255,220,120,0.05)", padding:"16px 22px", display:"grid", gridTemplateColumns:"0.3fr 1fr 0.8fr 0.5fr 0.5fr 0.9fr", gap:"8px" }}>
                    {["#","Item","Category","Qty","Orders","Revenue"].map(h=>(
                      <span key={h} style={{ color:"var(--text-secondary)", fontSize:"14px", fontWeight:"700", textTransform:"uppercase", letterSpacing:"0.4px" }}>{h}</span>
                    ))}
                  </div>
                  {filteredItems.map((item,ii)=>(
                    <div key={item.name} style={{ padding:"15px 22px", display:"grid", gridTemplateColumns:"0.3fr 1fr 0.8fr 0.5fr 0.5fr 0.9fr", gap:"8px", borderTop:"1px solid rgba(255,220,120,0.05)", alignItems:"center" }}>
                      <span style={{ color:ii===0?"#f5a623":"var(--text-muted)", fontSize:"15px", fontWeight:"700" }}>#{ii+1}</span>
                      <span style={{ color:"var(--text-primary)", fontSize:"15px", fontWeight:"600", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{item.name}</span>
                      <span style={{ color:"var(--text-muted)", fontSize:"14px" }}>{item.category}</span>
                      <span style={{ color:BAR_COLORS[ii%BAR_COLORS.length], fontSize:"16px", fontWeight:"700" }}>×{item.totalQty}</span>
                      <span style={{ color:"var(--text-secondary)", fontSize:"15px" }}>{item.orderCount}</span>
                      <span style={{ color:"#f5a623", fontSize:"16px", fontWeight:"700" }}>₹{item.totalRevenue.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default RevenuePage;
