import { useEffect, useState } from "react";
import { getAllBills, getAllOrders } from "../service/order";
import { useNavigate } from "react-router-dom";
import AdminNavbar from "../components/AdminNavbar";
import BillPopup from "../components/BillPopup";

const FONT   = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
const FONT_H = "Georgia,'Times New Roman',serif";
const BILL_STATUS_STYLE = {
  APPROVED: { bg:"rgba(76,175,125,0.12)", color:"#4caf7d", border:"rgba(76,175,125,0.3)", label:"✅ Approved" },
  DENIED:   { bg:"rgba(232,84,84,0.1)",   color:"#e85454", border:"rgba(232,84,84,0.3)",  label:"❌ Denied"  },
};

function AdminBillsPage() {
  const [bills,    setBills]    = useState([]);
  const [orders,   setOrders]   = useState({});
  const [loading,  setLoading]  = useState(true);
  const [search,   setSearch]   = useState("");
  const [selected, setSelected] = useState(null);
  const [focused,  setFocused]  = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!localStorage.getItem("token") || localStorage.getItem("role") !== "Admin") { navigate("/login"); return; }
    Promise.allSettled([getAllBills(), getAllOrders()]).then(([br, or]) => {
      if (br.status === "fulfilled") setBills(br.value.data);
      if (or.status === "fulfilled") {
        const map = {};
        or.value.data.forEach(o => { map[o.id] = o; });
        setOrders(map);
      }
      setLoading(false);
    });
  }, []);

  const grouped = bills.reduce((acc, bill) => {
    const key = bill.username || "Unknown";
    if (!acc[key]) acc[key] = [];
    acc[key].push(bill);
    return acc;
  }, {});

  const filteredGroups = Object.entries(grouped).filter(([username]) =>
    !search.trim() || username.toLowerCase().includes(search.toLowerCase())
  );

  // Exclude only explicitly DENIED — null/empty billStatus means old data (treat as approved)
  const totalRevenue = bills.filter(b=>(b.billStatus||"").toUpperCase()!=="DENIED").reduce((s,b)=>s+parseFloat(b.grandTotal||0),0);
  const inp = { background:"var(--bg-card2)", border:focused?"1.5px solid #f5a623":"1.5px solid var(--input-border)", boxShadow:focused?"0 0 0 3px rgba(245,166,35,0.1)":"none", color:"var(--text-primary)", borderRadius:"9px", padding:"10px 16px", fontSize:"14px", fontFamily:FONT, outline:"none", width:"260px" };

  return (
    <div style={{ minHeight:"100vh", background:"var(--bg-base)", fontFamily:FONT }}>
      <AdminNavbar />
      {selected && <BillPopup bill={selected.bill} order={selected.order} onClose={()=>setSelected(null)} />}

      <div style={{ padding:"36px 40px 24px", display:"flex", justifyContent:"space-between", alignItems:"flex-end", flexWrap:"wrap", gap:"16px", borderBottom:"1px solid rgba(245,166,35,0.06)", marginBottom:"28px" }}>
        <div>
          <h1 style={{ fontFamily:FONT_H, fontSize:"36px", fontWeight:"900", color:"var(--text-primary)" }}>All Bills</h1>
          <p style={{ color:"var(--text-muted)", fontSize:"14px", marginTop:"4px" }}>{bills.length} bills • {Object.keys(grouped).length} customers</p>
        </div>
        <div style={{ display:"flex", gap:"16px", alignItems:"center", flexWrap:"wrap" }}>
          <div style={{ background:"linear-gradient(135deg,rgba(245,166,35,0.15),rgba(232,66,10,0.1))", border:"1px solid rgba(245,166,35,0.2)", borderRadius:"12px", padding:"12px 20px" }}>
            <div style={{ color:"var(--text-secondary)", fontSize:"11px", textTransform:"uppercase", letterSpacing:"1px" }}>Approved Revenue</div>
            <div style={{ color:"#f5a623", fontSize:"22px", fontWeight:"700", fontFamily:FONT_H }}>₹{totalRevenue.toFixed(2)}</div>
          </div>
          <div style={{ background:"rgba(232,84,84,0.08)", border:"1px solid rgba(232,84,84,0.2)", borderRadius:"12px", padding:"12px 20px" }}>
            <div style={{ color:"var(--text-secondary)", fontSize:"11px", textTransform:"uppercase", letterSpacing:"1px" }}>Denied Bills</div>
            <div style={{ color:"#e85454", fontSize:"22px", fontWeight:"700", fontFamily:FONT_H }}>{bills.filter(b=>(b.billStatus||"").toUpperCase()==="DENIED").length}</div>
          </div>
          <input placeholder="🔍 Search by username..." value={search} onChange={e=>setSearch(e.target.value)}
            onFocus={()=>setFocused(true)} onBlur={()=>setFocused(false)} style={inp} />
        </div>
      </div>

      {loading && <div style={{ width:"36px", height:"36px", border:"3px solid rgba(255,220,120,0.1)", borderTopColor:"#f5a623", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"60px auto" }} />}

      {!loading && filteredGroups.length === 0 && (
        <div style={{ textAlign:"center", color:"var(--text-muted)", padding:"80px" }}>
          <div style={{ fontSize:"52px", marginBottom:"16px" }}>🧾</div>
          <p style={{ fontSize:"16px" }}>{search ? `No bills found for "${search}"` : "No bills yet"}</p>
        </div>
      )}

      {!loading && (
        <div style={{ padding:"0 40px 60px", display:"flex", flexDirection:"column", gap:"20px" }}>
          {filteredGroups.map(([username, userBills], gi) => {
            const userTotal = userBills.filter(b=>(b.billStatus||"").toUpperCase()!=="DENIED").reduce((s,b)=>s+parseFloat(b.grandTotal||0),0);
            return (
              <div key={username} style={{ background:"var(--bg-card)", border:"1px solid var(--border)", borderRadius:"16px", overflow:"hidden", animation:`fadeUp 0.4s ease ${gi*0.05}s both` }}>
                <div style={{ background:"var(--bg-card2)", borderBottom:"1px solid var(--border)", padding:"16px 22px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div style={{ display:"flex", alignItems:"center", gap:"12px" }}>
                    <div style={{ width:"38px", height:"38px", background:"rgba(245,166,35,0.12)", border:"1px solid rgba(245,166,35,0.25)", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"16px" }}>👤</div>
                    <div>
                      <div style={{ color:"var(--text-primary)", fontWeight:"700", fontSize:"15px" }}>{username}</div>
                      <div style={{ color:"var(--text-muted)", fontSize:"12px" }}>
                        {userBills[0]?.userEmail && <span>📧 {userBills[0].userEmail} • </span>}
                        {userBills.length} bill{userBills.length!==1?"s":""}
                      </div>
                    </div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ color:"var(--text-muted)", fontSize:"11px", textTransform:"uppercase", letterSpacing:"0.5px" }}>Revenue</div>
                    <div style={{ color:"#f5a623", fontSize:"18px", fontWeight:"700", fontFamily:FONT_H }}>₹{userTotal.toFixed(2)}</div>
                  </div>
                </div>

                <div style={{ padding:"14px 22px", display:"flex", flexDirection:"column", gap:"10px" }}>
                  {userBills.map(bill => {
                    const bs    = BILL_STATUS_STYLE[(bill.billStatus||"APPROVED").toUpperCase()] || BILL_STATUS_STYLE.APPROVED;
                    const order = orders[bill.orderId];
                    const items = order?.items || [];
                    return (
                      <div key={bill.id} onClick={()=>setSelected({ bill, order })}
                        style={{ background:"var(--bg-card3)", border:"1px solid rgba(255,220,120,0.05)", borderRadius:"12px", padding:"14px 16px", cursor:"pointer", transition:"border-color 0.2s" }}
                        onMouseEnter={e=>e.currentTarget.style.borderColor="rgba(245,166,35,0.25)"}
                        onMouseLeave={e=>e.currentTarget.style.borderColor="rgba(255,220,120,0.05)"}>

                        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:"12px", marginBottom: items.length>0 ? "10px" : 0 }}>
                          <div style={{ display:"flex", alignItems:"center", gap:"12px", flexWrap:"wrap" }}>
                            <span style={{ fontSize:"16px" }}>🧾</span>
                            <div>
                              <div style={{ color:"var(--text-primary)", fontWeight:"600", fontSize:"14px" }}>Bill #{bill.id} — Order #{bill.orderId}</div>
                              <div style={{ color:"var(--text-muted)", fontSize:"12px", marginTop:"2px" }}>
                                🚚 {bill.deliveryMode||"—"}
                                {bill.createdAt && ` • ${new Date(bill.createdAt).toLocaleDateString()}`}
                              </div>
                            </div>
                            <span style={{ background:bs.bg, border:`1px solid ${bs.border}`, color:bs.color, fontSize:"11px", fontWeight:"700", padding:"3px 10px", borderRadius:"99px" }}>{bs.label}</span>
                          </div>
                          <div style={{ textAlign:"right" }}>
                            <div style={{ color:"var(--text-muted)", fontSize:"11px" }}>Items: ₹{parseFloat(bill.itemsTotal||0).toFixed(2)} + GST: ₹{parseFloat(bill.gst||0).toFixed(2)}</div>
                            <div style={{ color:"#f5a623", fontWeight:"700", fontSize:"16px", fontFamily:FONT_H }}>₹{parseFloat(bill.grandTotal||0).toFixed(2)}</div>
                          </div>
                        </div>

                        {/* Items + category */}
                        {items.length > 0 && (
                          <div style={{ background:"var(--bg-card2)", borderRadius:"8px", padding:"8px 12px" }}>
                            {items.slice(0,4).map((it,idx)=>(
                              <div key={idx} style={{ display:"flex", justifyContent:"space-between", padding:"4px 0", borderBottom:idx<Math.min(items.length,4)-1?"1px solid rgba(255,220,120,0.04)":"none" }}>
                                <div>
                                  <span style={{ color:"var(--text-secondary)", fontSize:"12px" }}>×{it.quantity||1} {it.name}</span>
                                  {it.category && <span style={{ color:"var(--text-muted)", fontSize:"10px", marginLeft:"8px" }}>📂{it.category}</span>}
                                </div>
                                <span style={{ color:"#f5a623", fontSize:"11px" }}>₹{(parseFloat(it.price||0)*(it.quantity||1)).toFixed(2)}</span>
                              </div>
                            ))}
                            {items.length > 4 && <div style={{ color:"var(--text-muted)", fontSize:"10px", marginTop:"4px" }}>+{items.length-4} more</div>}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default AdminBillsPage;
