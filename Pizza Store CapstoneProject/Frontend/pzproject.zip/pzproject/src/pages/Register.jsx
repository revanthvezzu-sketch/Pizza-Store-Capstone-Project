// Register is handled inside Login.jsx via page state
// This file re-exports for routing compatibility
export { default } from "./Login";
