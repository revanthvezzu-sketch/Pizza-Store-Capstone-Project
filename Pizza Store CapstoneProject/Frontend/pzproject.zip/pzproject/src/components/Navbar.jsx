import { Link, useNavigate, useLocation } from "react-router-dom";
import { logout } from "../service/auth";
import { useState } from "react";
import { useTheme } from "../context/ThemeContext";

function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const token = localStorage.getItem("token");
  const role  = localStorage.getItem("role");
  const [hovered, setHovered] = useState(null);
  const { isDark, toggleTheme } = useTheme();

  const handleLogout = () => {
    logout();
    localStorage.removeItem("role");
    navigate("/login");
  };

  const isActive = (path) => location.pathname === path;
  const navLinks = [
    { path: "/menu",   label: "Menu"      },
    { path: "/orders", label: "Orders"    },
    ...(role === "Admin" ? [{ path: "/admin", label: "Dashboard" }] : []),
  ];

  if (!token) return null;

  return (
    <>
      <nav style={{
        position:"fixed", top:0, left:0, right:0, height:"64px",
        background:"var(--nav-bg)", backdropFilter:"blur(18px)",
        borderBottom:"1px solid var(--nav-border)",
        display:"flex", alignItems:"center", justifyContent:"space-between",
        padding:"0 36px", zIndex:1000,
        fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif",
        transition:"background 0.25s, border-color 0.25s",
      }}>
        <Link to="/menu" style={{ display:"flex", alignItems:"center", gap:"10px", textDecoration:"none" }}>
          <span style={{ fontSize:"22px" }}>🍕</span>
          <span style={{ fontFamily:"Georgia,'Times New Roman',serif", fontSize:"20px", fontWeight:"900", color:"var(--accent)" }}>Pizzeria</span>
          {role === "Admin" && (
            <span style={{ background:"rgba(245,166,35,0.15)", border:"1px solid rgba(245,166,35,0.3)", color:"var(--accent)", fontSize:"10px", fontWeight:"700", padding:"2px 9px", borderRadius:"99px", letterSpacing:"1px", textTransform:"uppercase" }}>Admin</span>
          )}
        </Link>

        <div style={{ display:"flex", gap:"4px" }}>
          {navLinks.map(({ path, label }) => (
            <Link key={path} to={path} style={{
              color: isActive(path) ? "var(--text-primary)" : "var(--text-secondary)",
              textDecoration:"none", padding:"6px 16px", borderRadius:"8px",
              fontSize:"14px", fontWeight:"500",
              background: isActive(path) ? "rgba(245,166,35,0.1)" : "transparent",
              transition:"background 0.2s, color 0.2s",
            }}>{label}</Link>
          ))}
        </div>

        <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
          <button
            onClick={toggleTheme}
            title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
            style={{
              background:"var(--toggle-bg)",
              border:"1.5px solid var(--toggle-border)",
              color:"var(--toggle-color)",
              width:"38px", height:"38px", borderRadius:"10px",
              display:"flex", alignItems:"center", justifyContent:"center",
              cursor:"pointer", fontSize:"17px", transition:"all 0.2s",
            }}>
            {isDark ? "☀️" : "🌙"}
          </button>
          <button
            onClick={handleLogout}
            onMouseEnter={() => setHovered("logout")}
            onMouseLeave={() => setHovered(null)}
            style={{
              background: hovered === "logout" ? "rgba(232,66,10,0.15)" : "transparent",
              border:"1.5px solid rgba(232,66,10,0.4)", color:"#e8420a",
              padding:"7px 18px", borderRadius:"8px", fontSize:"13px", fontWeight:"600",
              cursor:"pointer", fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif",
              transition:"background 0.2s",
            }}
          >Logout</button>
        </div>
      </nav>
      <div style={{ height:"64px" }} />
    </>
  );
}

export default Navbar;
