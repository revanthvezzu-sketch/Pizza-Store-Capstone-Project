function Button({ children, onClick, type = "button", variant = "primary", size = "md", disabled = false, fullWidth = false }) {
  const sizes = { sm:"8px 14px", md:"11px 22px", lg:"14px 28px" };
  const fontSizes = { sm:"13px", md:"14px", lg:"15px" };

  const variants = {
    primary:   { background:"linear-gradient(135deg,#f5a623,#e8420a)", color:"#fff", border:"none", boxShadow:"0 4px 16px rgba(245,166,35,0.3)" },
    secondary: { background:"rgba(232,66,10,0.1)", color:"#e8420a", border:"1.5px solid rgba(232,66,10,0.3)" },
    danger:    { background:"rgba(232,84,84,0.12)", color:"#e85454", border:"1.5px solid rgba(232,84,84,0.3)" },
    ghost:     { background:"transparent", color:"var(--text-secondary)", border:"1.5px solid rgba(255,220,120,0.15)" },
  };

  return (
    <button type={type} onClick={onClick} disabled={disabled} style={{
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif", fontWeight:"600",
      borderRadius:"9px", cursor: disabled ? "not-allowed" : "pointer",
      transition:"all 0.2s", display:"inline-flex", alignItems:"center",
      justifyContent:"center", gap:"8px", opacity: disabled ? 0.5 : 1,
      width: fullWidth ? "100%" : "auto",
      padding: sizes[size], fontSize: fontSizes[size],
      ...variants[variant],
    }}>
      {children}
    </button>
  );
}

export default Button;
