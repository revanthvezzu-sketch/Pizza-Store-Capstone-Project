function Card({ title, description, children, badge, badgeColor, image }) {
  return (
    <div style={{
      background:"var(--bg-card)", border:"1px solid var(--border)",
      borderRadius:"16px", overflow:"hidden",
      transition:"transform 0.2s, box-shadow 0.2s",
    }}>
      {image && (
        <div style={{ height:"120px", background:"linear-gradient(135deg,#1e1a16,#252018)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"48px" }}>
          {image}
        </div>
      )}
      <div style={{ padding:"18px" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:"8px", marginBottom:"6px" }}>
          <span style={{ color:"var(--text-primary)", fontWeight:"700", fontSize:"16px" }}>{title}</span>
          {badge && (
            <span style={{ background: badgeColor || "rgba(245,166,35,0.15)", color: badgeColor ? "#fff" : "#f5a623", border:`1px solid ${badgeColor || "rgba(245,166,35,0.3)"}`, fontSize:"11px", fontWeight:"600", padding:"3px 10px", borderRadius:"99px", whiteSpace:"nowrap" }}>
              {badge}
            </span>
          )}
        </div>
        {description && <p style={{ color:"var(--text-secondary)", fontSize:"13px", lineHeight:"1.5" }}>{description}</p>}
        {children && <div style={{ marginTop:"14px", display:"flex", gap:"8px", flexWrap:"wrap" }}>{children}</div>}
      </div>
    </div>
  );
}

export default Card;
