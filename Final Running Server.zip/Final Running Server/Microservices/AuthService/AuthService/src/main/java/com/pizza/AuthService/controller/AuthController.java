package com.pizza.AuthService.controller;

import com.pizza.AuthService.dto.LoginResponseDTO;
import com.pizza.AuthService.dto.RegisterRequestDTO;
import com.pizza.AuthService.model.User;
import com.pizza.AuthService.repository.UserRepository;
import com.pizza.AuthService.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {

    @Autowired private UserRepository  userRepository;
    @Autowired private JwtUtil         jwtUtil;
    @Autowired private PasswordEncoder passwordEncoder;

    /**
     * POST /auth/register
     * Accepts: { username, password, email, lastName, role }
     * lastName is saved to DB but never returned in any response.
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequestDTO dto) {
        if (dto.getUsername() == null || dto.getUsername().isBlank())
            throw new IllegalArgumentException("Username is required");

        if (dto.getPassword() == null || dto.getPassword().isBlank())
            throw new IllegalArgumentException("Password is required");

        if (userRepository.findByUsername(dto.getUsername()).isPresent())
            throw new IllegalArgumentException("Username already exists");

        User user = new User();
        user.setUsername(dto.getUsername());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setEmail(dto.getEmail() != null ? dto.getEmail() : "");
        user.setLastName(dto.getLastName());   // ✅ stored in DB, never returned
        user.setRole(dto.getRole() != null ? dto.getRole() : "user");
        userRepository.save(user);

        // ✅ Response does NOT include lastName
        return ResponseEntity.ok(Map.of("message", "Registered successfully"));
    }

    /**
     * POST /auth/login
     * Returns: LoginResponseDTO { token, userId, username, email, role }
     * lastName is intentionally excluded from the response.
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");

        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isEmpty())
            return ResponseEntity.status(401).body(Map.of("message", "Invalid credentials"));

        User user = userOpt.get();
        if (!passwordEncoder.matches(password, user.getPassword()))
            return ResponseEntity.status(401).body(Map.of("message", "Invalid credentials"));

        // ✅ userId embedded in JWT so OrderService can extract it — no DTO trust
        String token = jwtUtil.generateToken(user.getUsername(), user.getRole(), user.getId());

        // ✅ LoginResponseDTO has no lastName field — hidden from response
        LoginResponseDTO response = new LoginResponseDTO(
            token,
            user.getId(),
            user.getUsername(),
            user.getEmail(),
            user.getRole()
        );

        return ResponseEntity.ok(response);
    }
}
