package com.pizza.AuthService.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    private String email;

    // ✅ Stored in DB but never exposed in API responses — hidden via DTO
    @Column(name = "last_name")
    private String lastName;

    @Column(nullable = false)
    private String role = "user";

    public int getId()                        { return id; }
    public void setId(int id)                 { this.id = id; }

    public String getUsername()               { return username; }
    public void setUsername(String username)  { this.username = username; }

    public String getPassword()               { return password; }
    public void setPassword(String password)  { this.password = password; }

    public String getEmail()                  { return email; }
    public void setEmail(String email)        { this.email = email; }

    public String getLastName()               { return lastName; }
    public void setLastName(String lastName)  { this.lastName = lastName; }

    public String getRole()                   { return role; }
    public void setRole(String role)          { this.role = role != null ? role.toLowerCase() : "user"; }
}
