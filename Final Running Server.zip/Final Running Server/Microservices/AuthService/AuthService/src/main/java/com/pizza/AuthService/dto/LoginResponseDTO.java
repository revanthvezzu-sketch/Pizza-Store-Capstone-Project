package com.pizza.AuthService.dto;

/**
 * DTO for POST /auth/login response.
 * lastName is intentionally excluded — it is stored in DB but never sent to client.
 */
public class LoginResponseDTO {

    private String token;
    private int    userId;
    private String username;
    private String email;
    private String role;
    // ✅ lastName is NOT here — hidden from all API responses

    public LoginResponseDTO() {}

    public LoginResponseDTO(String token, int userId, String username, String email, String role) {
        this.token    = token;
        this.userId   = userId;
        this.username = username;
        this.email    = email;
        this.role     = role;
    }

    public String getToken()                  { return token; }
    public void   setToken(String token)      { this.token = token; }

    public int    getUserId()                 { return userId; }
    public void   setUserId(int userId)       { this.userId = userId; }

    public String getUsername()               { return username; }
    public void   setUsername(String u)       { this.username = u; }

    public String getEmail()                  { return email; }
    public void   setEmail(String email)      { this.email = email; }

    public String getRole()                   { return role; }
    public void   setRole(String role)        { this.role = role; }
}
