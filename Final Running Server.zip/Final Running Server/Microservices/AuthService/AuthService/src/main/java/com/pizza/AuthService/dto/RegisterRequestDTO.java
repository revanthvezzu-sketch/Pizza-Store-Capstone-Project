package com.pizza.AuthService.dto;

/**
 * DTO for POST /auth/register
 * lastName is accepted from frontend and saved to DB,
 * but is never returned in any API response.
 */
public class RegisterRequestDTO {

    private String username;
    private String password;
    private String email;
    private String lastName;   // ✅ accepted, stored, never returned
    private String role;

    public String getUsername()               { return username; }
    public void setUsername(String username)  { this.username = username; }

    public String getPassword()               { return password; }
    public void setPassword(String password)  { this.password = password; }

    public String getEmail()                  { return email; }
    public void setEmail(String email)        { this.email = email; }

    public String getLastName()               { return lastName; }
    public void setLastName(String lastName)  { this.lastName = lastName; }

    public String getRole()                   { return role; }
    public void setRole(String role)          { this.role = role; }
}
