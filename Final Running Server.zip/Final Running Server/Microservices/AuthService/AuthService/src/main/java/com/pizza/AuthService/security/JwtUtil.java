package com.pizza.AuthService.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.Map;

/**
 * JWT utility for AuthService.
 * SECRET must match OrderService and MenuService exactly.
 * userId is embedded as a claim so downstream services can extract it.
 */
@Service
public class JwtUtil {

    // ✅ Matches OrderService & MenuService secret
    private static final String SECRET =
            "pizza_store_super_secret_key_12345678901234567890";

    private static final long EXPIRATION = 1000L * 60 * 60 * 10; // 10 hours

    private Key getKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }

    /**
     * Generates token with role AND userId embedded as claims.
     * userId allows OrderService to set order.userId without relying on DTO.
     */
    public String generateToken(String username, String role, long userId) {
        return Jwts.builder()
                .setSubject(username)
                .addClaims(Map.of(
                    "role",   role != null ? role.toLowerCase() : "user",
                    "userId", userId
                ))
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
                .signWith(getKey())
                .compact();
    }

    public String extractUsername(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getKey())
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }
}
