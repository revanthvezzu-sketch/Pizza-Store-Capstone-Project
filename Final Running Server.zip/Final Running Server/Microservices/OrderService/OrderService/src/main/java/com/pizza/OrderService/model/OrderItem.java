package com.pizza.OrderService.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long menuItemId;
    private String name;
    private Integer quantity;
    private Double price;
    private String category;   // NEW: category name stored at order time

    @ManyToOne
    @JoinColumn(name = "order_id")
    @JsonIgnore
    private Order order;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getMenuItemId() { return menuItemId; }
    public void setMenuItemId(Long menuItemId) { this.menuItemId = menuItemId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public Order getOrder() { return order; }
    public void setOrder(Order order) { this.order = order; }
}




//package com.pizza.OrderService.model;
//
//import jakarta.persistence.*;
//import com.fasterxml.jackson.annotation.JsonIgnore;
//
//@Entity
//public class OrderItem {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private Long menuItemId;   // maps from cart item's 'id'
//    private String name;       // item name from cart
//    private Integer quantity;  // maps from cart item's 'qty'
//    private Double price;
//
//    @ManyToOne
//    @JoinColumn(name = "order_id")
//    @JsonIgnore                // prevent circular serialization
//    private Order order;
//
//    public Long getId() { return id; }
//    public void setId(Long id) { this.id = id; }
//
//    public Long getMenuItemId() { return menuItemId; }
//    public void setMenuItemId(Long menuItemId) { this.menuItemId = menuItemId; }
//
//    public String getName() { return name; }
//    public void setName(String name) { this.name = name; }
//
//    public Integer getQuantity() { return quantity; }
//    public void setQuantity(Integer quantity) { this.quantity = quantity; }
//
//    public Double getPrice() { return price; }
//    public void setPrice(Double price) { this.price = price; }
//
//    public Order getOrder() { return order; }
//    public void setOrder(Order order) { this.order = order; }
//}
