package com.pizza.OrderService.dto;

import java.util.List;

/**
 * DTO for incoming order requests from the frontend.
 * userId and username are intentionally NOT trusted from here —
 * they are extracted from the JWT token in the controller.
 */
public class OrderRequestDTO {

    private List<CartItemDTO> items;
    private double total;
    private String deliveryMode;
    private String userEmail; // optional — frontend may send this

    public List<CartItemDTO> getItems()                   { return items; }
    public void setItems(List<CartItemDTO> items)         { this.items = items; }

    public double getTotal()                              { return total; }
    public void setTotal(double total)                    { this.total = total; }

    public String getDeliveryMode()                       { return deliveryMode; }
    public void setDeliveryMode(String deliveryMode)      { this.deliveryMode = deliveryMode; }

    public String getUserEmail()                          { return userEmail; }
    public void setUserEmail(String userEmail)            { this.userEmail = userEmail; }

    public static class CartItemDTO {
        private Long   id;
        private String name;
        private double price;
        private int    qty;
        private String category;
        private String description;

        public Long   getId()                       { return id; }
        public void   setId(Long id)                { this.id = id; }
        public String getName()                     { return name; }
        public void   setName(String name)          { this.name = name; }
        public double getPrice()                    { return price; }
        public void   setPrice(double price)        { this.price = price; }
        public int    getQty()                      { return qty; }
        public void   setQty(int qty)               { this.qty = qty; }
        public String getCategory()                 { return category; }
        public void   setCategory(String category)  { this.category = category; }
        public String getDescription()              { return description; }
        public void   setDescription(String d)      { this.description = d; }
    }
}
