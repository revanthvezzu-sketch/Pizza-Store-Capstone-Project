package com.pizza.OrderService.repository;

import com.pizza.OrderService.model.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface BillRepository extends JpaRepository<Bill, Long> {
    List<Bill> findByUsernameOrderByCreatedAtDesc(String username);
    List<Bill> findAllByOrderByCreatedAtDesc();
    Optional<Bill> findByOrderId(Long orderId);
}
