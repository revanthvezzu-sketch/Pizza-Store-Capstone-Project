package com.pizza.OrderService.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "bills")
public class Bill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long orderId;
    private Long userId;
    private String username;
    private String userEmail;

    // Separate bill status: APPROVED or DENIED (independent of order status)
    @Column(name = "bill_status")
    private String billStatus; // "APPROVED" | "DENIED"

    private double itemsTotal;
    private double gst;
    private double deliveryFee;
    private double convenienceFee;
    private double grandTotal;

    private String deliveryMode;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }
    public String getBillStatus() { return billStatus; }
    public void setBillStatus(String billStatus) { this.billStatus = billStatus; }
    public double getItemsTotal() { return itemsTotal; }
    public void setItemsTotal(double itemsTotal) { this.itemsTotal = itemsTotal; }
    public double getGst() { return gst; }
    public void setGst(double gst) { this.gst = gst; }
    public double getDeliveryFee() { return deliveryFee; }
    public void setDeliveryFee(double deliveryFee) { this.deliveryFee = deliveryFee; }
    public double getConvenienceFee() { return convenienceFee; }
    public void setConvenienceFee(double convenienceFee) { this.convenienceFee = convenienceFee; }
    public double getGrandTotal() { return grandTotal; }
    public void setGrandTotal(double grandTotal) { this.grandTotal = grandTotal; }
    public String getDeliveryMode() { return deliveryMode; }
    public void setDeliveryMode(String deliveryMode) { this.deliveryMode = deliveryMode; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}




//package com.pizza.OrderService.model;
//
//import jakarta.persistence.*;
//import java.time.LocalDateTime;
//
//@Entity
//@Table(name = "bills")
//public class Bill {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private Long orderId;
//    private Long userId;
//    private String username;
//    private String userEmail;
//
//    private double itemsTotal;      // sum of item price × qty
//    private double gst;             // 5% of itemsTotal
//    private double deliveryFee;     // ₹10 fixed
//    private double convenienceFee;  // ₹15 fixed
//    private double grandTotal;      // itemsTotal + gst + deliveryFee + convenienceFee
//
//    private String deliveryMode;
//
//    @Column(name = "created_at")
//    private LocalDateTime createdAt;
//
//    @PrePersist
//    public void prePersist() {
//        this.createdAt = LocalDateTime.now();
//    }
//
//    public Long getId() { return id; }
//    public void setId(Long id) { this.id = id; }
//
//    public Long getOrderId() { return orderId; }
//    public void setOrderId(Long orderId) { this.orderId = orderId; }
//
//    public Long getUserId() { return userId; }
//    public void setUserId(Long userId) { this.userId = userId; }
//
//    public String getUsername() { return username; }
//    public void setUsername(String username) { this.username = username; }
//
//    public String getUserEmail() { return userEmail; }
//    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }
//
//    public double getItemsTotal() { return itemsTotal; }
//    public void setItemsTotal(double itemsTotal) { this.itemsTotal = itemsTotal; }
//
//    public double getGst() { return gst; }
//    public void setGst(double gst) { this.gst = gst; }
//
//    public double getDeliveryFee() { return deliveryFee; }
//    public void setDeliveryFee(double deliveryFee) { this.deliveryFee = deliveryFee; }
//
//    public double getConvenienceFee() { return convenienceFee; }
//    public void setConvenienceFee(double convenienceFee) { this.convenienceFee = convenienceFee; }
//
//    public double getGrandTotal() { return grandTotal; }
//    public void setGrandTotal(double grandTotal) { this.grandTotal = grandTotal; }
//
//    public String getDeliveryMode() { return deliveryMode; }
//    public void setDeliveryMode(String deliveryMode) { this.deliveryMode = deliveryMode; }
//
//    public LocalDateTime getCreatedAt() { return createdAt; }
//    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
//}
