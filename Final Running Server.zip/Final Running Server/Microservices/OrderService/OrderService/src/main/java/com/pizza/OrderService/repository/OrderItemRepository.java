package com.pizza.OrderService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.pizza.OrderService.model.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem,Long>{

}