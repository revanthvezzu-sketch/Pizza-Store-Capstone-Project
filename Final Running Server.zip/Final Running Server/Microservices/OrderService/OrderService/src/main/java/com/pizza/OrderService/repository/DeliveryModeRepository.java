package com.pizza.OrderService.repository;

import com.pizza.OrderService.model.DeliveryMode;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DeliveryModeRepository extends JpaRepository<DeliveryMode, Long> {
    List<DeliveryMode> findByActiveTrue();
}
