package com.pizza.OrderService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pizza.OrderService.dto.OrderRequestDTO;
import com.pizza.OrderService.model.*;
import com.pizza.OrderService.repository.*;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    @Autowired private OrderRepository       orderRepo;
    @Autowired private BillRepository        billRepo;
    @Autowired private DeliveryModeRepository deliveryModeRepo;

    /**
     * Place an order.
     * userId and username always come from JWT — never trusted from DTO.
     */
    public Order placeOrder(OrderRequestDTO dto, String usernameFromJwt, Long userIdFromJwt) {
        if (userIdFromJwt == null) {
            throw new IllegalArgumentException("userId is missing from token — cannot place order");
        }

        Order order = new Order();
        order.setUserId(userIdFromJwt);          // ✅ always from JWT
        order.setUsername(usernameFromJwt);       // ✅ always from JWT
        order.setUserEmail(dto.getUserEmail());   // optional, from request body
        order.setDeliveryMode(dto.getDeliveryMode());
        order.setStatus("PLACED");
        order.setTotalAmount(dto.getTotal());

        List<OrderItem> orderItems = new ArrayList<>();
        if (dto.getItems() != null) {
            for (OrderRequestDTO.CartItemDTO cartItem : dto.getItems()) {
                OrderItem oi = new OrderItem();
                oi.setMenuItemId(cartItem.getId());
                oi.setName(cartItem.getName());
                oi.setPrice(cartItem.getPrice());
                oi.setQuantity(cartItem.getQty());
                oi.setCategory(cartItem.getCategory());
                oi.setOrder(order);
                orderItems.add(oi);
            }
        }
        order.setItems(orderItems);
        return orderRepo.save(order);
    }

    public List<Order> getAllOrders() {
        return orderRepo.findAllByOrderByCreatedAtDesc();
    }

    public List<Order> getOrdersByUsername(String username) {
        return orderRepo.findByUsernameOrderByCreatedAtDesc(username);
    }

    public List<Order> getOrdersByUser(Long userId) {
        return orderRepo.findByUserId(userId);
    }

    public Order updateStatus(Long id, String status) {
        Order order = orderRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Order not found: " + id));
        order.setStatus(status);
        return orderRepo.save(order);
    }

    // APPROVE: order → PREPARING, bill → APPROVED
    public Bill approveOrder(Long orderId) {
        Order order = orderRepo.findById(orderId)
            .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
        order.setStatus("PREPARING");
        orderRepo.save(order);
        return generateBill(order, "APPROVED");
    }

    // DENY: order → CANCELLED, bill → DENIED
    public Bill denyOrder(Long orderId) {
        Order order = orderRepo.findById(orderId)
            .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
        order.setStatus("CANCELLED");
        orderRepo.save(order);
        return generateBill(order, "DENIED");
    }

    public Bill generateBill(Order order, String billStatus) {
        java.util.Optional<Bill> existing = billRepo.findByOrderId(order.getId());
        if (existing.isPresent()) {
            Bill b = existing.get();
            b.setBillStatus(billStatus);
            return billRepo.save(b);
        }

        double itemsTotal     = order.getItems().stream()
            .mapToDouble(i -> i.getPrice() * i.getQuantity()).sum();
        double gst            = Math.round(itemsTotal * 0.05 * 100.0) / 100.0;
        double deliveryFee    = 10.0;
        double convenienceFee = 15.0;
        double grandTotal     = Math.round((itemsTotal + gst + deliveryFee + convenienceFee) * 100.0) / 100.0;

        Bill bill = new Bill();
        bill.setOrderId(order.getId());
        bill.setUserId(order.getUserId());
        bill.setUsername(order.getUsername());
        bill.setUserEmail(order.getUserEmail());
        bill.setBillStatus(billStatus);
        bill.setItemsTotal(itemsTotal);
        bill.setGst(gst);
        bill.setDeliveryFee(deliveryFee);
        bill.setConvenienceFee(convenienceFee);
        bill.setGrandTotal(grandTotal);
        bill.setDeliveryMode(order.getDeliveryMode());
        return billRepo.save(bill);
    }

    public Bill getBillByOrderId(Long orderId) {
        return billRepo.findByOrderId(orderId).orElse(null);
    }

    public List<Bill> getBillsByUsername(String username) {
        return billRepo.findByUsernameOrderByCreatedAtDesc(username);
    }

    public List<Bill> getAllBills() {
        return billRepo.findAllByOrderByCreatedAtDesc();
    }

    public void cancelOrder(Long id) {
        orderRepo.deleteById(id);
    }

    public double getRevenue() {
        return billRepo.findAllByOrderByCreatedAtDesc().stream()
            .filter(b -> "APPROVED".equalsIgnoreCase(b.getBillStatus()))
            .mapToDouble(Bill::getGrandTotal).sum();
    }

    public List<DeliveryMode> getActiveDeliveryModes() {
        return deliveryModeRepo.findByActiveTrue();
    }

    public List<DeliveryMode> getAllDeliveryModes() {
        return deliveryModeRepo.findAll();
    }

    public DeliveryMode saveDeliveryMode(DeliveryMode dm) {
        return deliveryModeRepo.save(dm);
    }

    public DeliveryMode updateDeliveryMode(Long id, DeliveryMode dm) {
        DeliveryMode existing = deliveryModeRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("DeliveryMode not found: " + id));
        existing.setName(dm.getName());
        existing.setDescription(dm.getDescription());
        existing.setActive(dm.isActive());
        return deliveryModeRepo.save(existing);
    }

    public void deleteDeliveryMode(Long id) {
        deliveryModeRepo.deleteById(id);
    }
}
