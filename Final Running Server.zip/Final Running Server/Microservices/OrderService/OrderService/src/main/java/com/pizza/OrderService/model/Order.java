package com.pizza.OrderService.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ✅ Fixed: removed wrong ANTLR @NotNull import, using JPA nullable=false instead
    @Column(nullable = false)
    private Long userId;

    private String username;
    private String userEmail;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<OrderItem> items = new ArrayList<>();

    private double totalAmount;
    private String deliveryMode;
    private String status;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        if (this.status == null)    this.status = "PLACED";
        if (this.createdAt == null) this.createdAt = LocalDateTime.now();
    }

    public Long getId()                          { return id; }
    public void setId(Long id)                   { this.id = id; }

    public Long getUserId()                      { return userId; }
    public void setUserId(Long userId)           { this.userId = userId; }

    public String getUsername()                  { return username; }
    public void setUsername(String username)     { this.username = username; }

    public String getUserEmail()                 { return userEmail; }
    public void setUserEmail(String userEmail)   { this.userEmail = userEmail; }

    public List<OrderItem> getItems()            { return items; }
    public void setItems(List<OrderItem> items)  { this.items = items; }

    public double getTotalAmount()                     { return totalAmount; }
    public void setTotalAmount(double totalAmount)     { this.totalAmount = totalAmount; }

    public String getDeliveryMode()                    { return deliveryMode; }
    public void setDeliveryMode(String deliveryMode)   { this.deliveryMode = deliveryMode; }

    public String getStatus()                    { return status; }
    public void setStatus(String status)         { this.status = status; }

    public LocalDateTime getCreatedAt()                    { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt)      { this.createdAt = createdAt; }
}
