package com.pizza.OrderService.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    // ✅ Must match AuthService and MenuService exactly
    private static final String SECRET =
            "pizza_store_super_secret_key_12345678901234567890";

    private Key getKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }

    private Claims getClaims(String token) {
        return Jwts.parserBuilder()
                   .setSigningKey(getKey())
                   .build()
                   .parseClaimsJws(token)
                   .getBody();
    }

    public String extractUsername(String token) {
        return getClaims(token).getSubject();
    }

    public String extractRole(String token) {
        try {
            Object r = getClaims(token).get("role");
            return r != null ? r.toString().toLowerCase() : "user";
        } catch (Exception e) {
            return "user";
        }
    }

    /**
     * ✅ Extract userId from JWT claim.
     * AuthService embeds userId at login so we never rely on the request DTO.
     */
    public Long extractUserId(String token) {
        Object id = getClaims(token).get("userId");
        if (id instanceof Integer) return ((Integer) id).longValue();
        if (id instanceof Long)    return (Long) id;
        return null;
    }

    public boolean validateToken(String token) {
        try { return !getClaims(token).getExpiration().before(new Date()); }
        catch (Exception e) { return false; }
    }
}
