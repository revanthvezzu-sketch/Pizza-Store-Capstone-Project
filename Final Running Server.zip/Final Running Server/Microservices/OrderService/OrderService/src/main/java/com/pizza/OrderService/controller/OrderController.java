package com.pizza.OrderService.controller;

import com.pizza.OrderService.dto.OrderRequestDTO;
import com.pizza.OrderService.model.Bill;
import com.pizza.OrderService.model.DeliveryMode;
import com.pizza.OrderService.model.Order;
import com.pizza.OrderService.service.OrderService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // Place order — userId and username both come from JWT, never from DTO
    @PostMapping
    public ResponseEntity<Order> placeOrder(@RequestBody OrderRequestDTO dto,
                                             HttpServletRequest request) {
        String username = (String) request.getAttribute("username");
        Long   userId   = (Long)   request.getAttribute("userId"); // ✅ from JWT
        return ResponseEntity.ok(orderService.placeOrder(dto, username, userId));
    }

    // My orders (user)
    @GetMapping("/my")
    public ResponseEntity<List<Order>> getMyOrders(HttpServletRequest request) {
        String username = (String) request.getAttribute("username");
        return ResponseEntity.ok(orderService.getOrdersByUsername(username));
    }

    // All orders (admin)
    @GetMapping("/all")
    public ResponseEntity<List<Order>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Order>> getOrdersByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(orderService.getOrdersByUser(userId));
    }

    // Update status (admin)
    @PutMapping("/{id}/status")
    public ResponseEntity<Order> updateOrderStatus(@PathVariable Long id,
                                                    @RequestBody String status) {
        String cleaned = status.replace("\"", "").trim();
        return ResponseEntity.ok(orderService.updateStatus(id, cleaned));
    }

    // APPROVE order → PREPARING + bill APPROVED
    @PutMapping("/{id}/approve")
    public ResponseEntity<Map<String, Object>> approveOrder(@PathVariable Long id) {
        Bill bill = orderService.approveOrder(id);
        Order order = orderService.getAllOrders().stream()
            .filter(o -> o.getId().equals(id)).findFirst().orElse(null);
        return ResponseEntity.ok(Map.of("order", order != null ? order : Map.of(), "bill", bill));
    }

    // DENY order → CANCELLED + bill DENIED
    @PutMapping("/{id}/deny")
    public ResponseEntity<Map<String, Object>> denyOrder(@PathVariable Long id) {
        Bill bill = orderService.denyOrder(id);
        Order order = orderService.getAllOrders().stream()
            .filter(o -> o.getId().equals(id)).findFirst().orElse(null);
        return ResponseEntity.ok(Map.of("order", order != null ? order : Map.of(), "bill", bill));
    }

    // Cancel order
    @DeleteMapping("/{id}")
    public ResponseEntity<String> cancelOrder(@PathVariable Long id) {
        orderService.cancelOrder(id);
        return ResponseEntity.ok("Order cancelled");
    }

    // Revenue
    @GetMapping("/revenue")
    public ResponseEntity<Double> getRevenue() {
        return ResponseEntity.ok(orderService.getRevenue());
    }

    // Bills
    @GetMapping("/bills/my")
    public ResponseEntity<List<Bill>> getMyBills(HttpServletRequest request) {
        String username = (String) request.getAttribute("username");
        return ResponseEntity.ok(orderService.getBillsByUsername(username));
    }

    @GetMapping("/bills/all")
    public ResponseEntity<List<Bill>> getAllBills() {
        return ResponseEntity.ok(orderService.getAllBills());
    }

    @GetMapping("/bills/order/{orderId}")
    public ResponseEntity<?> getBillByOrder(@PathVariable Long orderId,
                                             HttpServletRequest request) {
        String username = (String) request.getAttribute("username");
        Bill bill = orderService.getBillByOrderId(orderId);
        if (bill == null) return ResponseEntity.notFound().build();
        String role = (String) request.getAttribute("role");
        if (!"admin".equals(role) && !username.equals(bill.getUsername())) {
            return ResponseEntity.status(403).build();
        }
        return ResponseEntity.ok(bill);
    }

    // Delivery Modes
    @GetMapping("/delivery-modes")
    public ResponseEntity<List<DeliveryMode>> getDeliveryModes() {
        return ResponseEntity.ok(orderService.getActiveDeliveryModes());
    }

    @GetMapping("/delivery-modes/all")
    public ResponseEntity<List<DeliveryMode>> getAllDeliveryModes() {
        return ResponseEntity.ok(orderService.getAllDeliveryModes());
    }

    @PostMapping("/delivery-modes")
    public ResponseEntity<DeliveryMode> addDeliveryMode(@RequestBody DeliveryMode dm) {
        return ResponseEntity.ok(orderService.saveDeliveryMode(dm));
    }

    @PutMapping("/delivery-modes/{id}")
    public ResponseEntity<DeliveryMode> updateDeliveryMode(@PathVariable Long id,
                                                            @RequestBody DeliveryMode dm) {
        return ResponseEntity.ok(orderService.updateDeliveryMode(id, dm));
    }

    @DeleteMapping("/delivery-modes/{id}")
    public ResponseEntity<String> deleteDeliveryMode(@PathVariable Long id) {
        orderService.deleteDeliveryMode(id);
        return ResponseEntity.ok("Deleted");
    }
}
