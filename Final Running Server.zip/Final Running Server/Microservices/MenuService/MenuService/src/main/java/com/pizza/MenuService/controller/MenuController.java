package com.pizza.MenuService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.pizza.MenuService.dto.MenuItemRequestDTO;
import com.pizza.MenuService.model.Category;
import com.pizza.MenuService.model.MenuItem;
import com.pizza.MenuService.repository.MenuRepository;
import com.pizza.MenuService.service.MenuService;

import java.util.List;
@RestController
@RequestMapping("/menu")
public class MenuController {

    @Autowired
    private MenuRepository menuRepo;

    @Autowired
    private MenuService menuService;

    // GET /menu/items
    @GetMapping("/items")
    public ResponseEntity<List<MenuItem>> getAllItems() {
        return ResponseEntity.ok(menuRepo.findAll());
    }

    // POST /menu/items
    @PostMapping("/items")
    public ResponseEntity<MenuItem> addItem(@RequestBody MenuItemRequestDTO dto) {
        return ResponseEntity.ok(menuService.addItem(dto));
    }

    // PUT /menu/items/{id}
    @PutMapping("/items/{id}")
    public ResponseEntity<MenuItem> updateItem(@PathVariable Long id,
                                               @RequestBody MenuItemRequestDTO dto) {
        return ResponseEntity.ok(menuService.updateItem(id, dto));
    }

    // DELETE /menu/items/{id}
    @DeleteMapping("/items/{id}")
    public ResponseEntity<String> deleteItem(@PathVariable Long id) {
        menuRepo.deleteById(id);
        return ResponseEntity.ok("Deleted");
    }

    // GET /menu/items/category/{categoryId}
    @GetMapping("/items/category/{categoryId}")
    public ResponseEntity<List<MenuItem>> getItemsByCategory(@PathVariable Long categoryId) {
        return ResponseEntity.ok(menuRepo.findByCategoryId(categoryId));
    }

    // GET /menu/categories
    @GetMapping("/categories")
    public ResponseEntity<List<Category>> getAllCategories() {
        return ResponseEntity.ok(menuService.getAllCategories());
    }

    // GET /menu/categories/{id}
    @GetMapping("/categories/{id}")
    public ResponseEntity<Category> getCategoryById(@PathVariable Long id) {
        return ResponseEntity.ok(menuService.getCategoryById(id));
    }

    // POST /menu/categories
    @PostMapping("/categories")
    public ResponseEntity<Category> addCategory(@RequestBody Category category) {
        return ResponseEntity.ok(menuService.addCategory(category));
    }

    // PUT /menu/categories/{id}
    @PutMapping("/categories/{id}")
    public ResponseEntity<Category> updateCategory(@PathVariable Long id,
                                                   @RequestBody Category updated) {
        return ResponseEntity.ok(menuService.updateCategory(id, updated));
    }

    // DELETE /menu/categories/{id}
    @DeleteMapping("/categories/{id}")
    public ResponseEntity<String> deleteCategory(@PathVariable Long id) {
        menuService.deleteCategory(id);
        return ResponseEntity.ok("Deleted");
    }
}
