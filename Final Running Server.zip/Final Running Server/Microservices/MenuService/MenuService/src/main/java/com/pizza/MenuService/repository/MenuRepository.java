package com.pizza.MenuService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.pizza.MenuService.model.MenuItem;

import java.util.List;

public interface MenuRepository extends JpaRepository<MenuItem, Long> {

	List<MenuItem> findByCategoryId(Long categoryId);
}
