package com.pizza.MenuService.dto;

// Matches exactly what the frontend sends:
// { name, price, description, categoryName }
public class MenuItemRequestDTO {

    private String name;
    private double price;
    private String description;
    private String categoryName;   // plain string from frontend
    
    private int stockLimit = -1;
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }
    
    public int getStockLimit() { return stockLimit; }
    public void setStockLimit(int stockLimit) { this.stockLimit = stockLimit; }
}
