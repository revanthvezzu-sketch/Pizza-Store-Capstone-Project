package com.pizza.MenuService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pizza.MenuService.model.Category;
import com.pizza.MenuService.model.MenuItem;
import com.pizza.MenuService.repository.CategoryRepository;
import com.pizza.MenuService.repository.MenuRepository;
import com.pizza.MenuService.dto.MenuItemRequestDTO;

@Service
public class MenuService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private MenuRepository menuRepository;

    /**
     * Find category by name (case-insensitive) or create a new one.
     * @Transactional ensures the returned entity is in the current session
     * so JPA can correctly set the FK on MenuItem.
     */
    @Transactional
    public Category findOrCreateCategory(String categoryName) {
        if (categoryName == null || categoryName.isBlank()) return null;
        String trimmed = categoryName.trim();
        return categoryRepository.findByNameIgnoreCase(trimmed)
            .orElseGet(() -> {
                Category c = new Category();
                c.setName(trimmed);
                return categoryRepository.save(c);
            });
    }

    /** Add a new MenuItem from DTO, resolving/creating the Category. */
    @Transactional
    public MenuItem addItem(MenuItemRequestDTO dto) {
        MenuItem item = new MenuItem();
        item.setName(dto.getName());
        item.setDescription(dto.getDescription());
        item.setPrice(dto.getPrice());
        item.setStockLimit(dto.getStockLimit()); // -1 by default = unlimited
        item.setCategory(findOrCreateCategory(dto.getCategoryName()));
        return menuRepository.save(item);
    }

    /** Update existing MenuItem from DTO. */
    @Transactional
    public MenuItem updateItem(Long id, MenuItemRequestDTO dto) {
        MenuItem item = menuRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Item not found: " + id));
        item.setName(dto.getName());
        item.setDescription(dto.getDescription());
        item.setPrice(dto.getPrice());
        item.setStockLimit(dto.getStockLimit());
        item.setCategory(findOrCreateCategory(dto.getCategoryName()));
        return menuRepository.save(item);
    }

    // ── Categories ──
    public Category addCategory(Category category) {
        return categoryRepository.save(category);
    }

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    public Category getCategoryById(Long id) {
        return categoryRepository.findById(id).orElse(null);
    }

    @Transactional
    public Category updateCategory(Long id, Category updated) {
        Category cat = categoryRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Category not found: " + id));
        if (updated.getName() != null && !updated.getName().isBlank())
            cat.setName(updated.getName().trim());
        if (updated.getColor() != null)
            cat.setColor(updated.getColor());
        if (updated.getDescription() != null)
            cat.setDescription(updated.getDescription());
        return categoryRepository.save(cat);
    }

    public void deleteCategory(Long id) {
        categoryRepository.deleteById(id);
    }
}
