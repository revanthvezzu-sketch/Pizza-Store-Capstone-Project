package com.pizza.MenuService.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    // Must match AuthService JWTService secret exactly
    private static final String SECRET =
            "pizza_store_super_secret_key_12345678901234567890";

    private Key getKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }

    private Claims getClaims(String token) {
        return Jwts.parserBuilder()
                   .setSigningKey(getKey())
                   .build()
                   .parseClaimsJws(token)
                   .getBody();
    }

    public String extractUsername(String token) {
        return getClaims(token).getSubject();
    }

    public String extractRole(String token) {
        try {
            Object r = getClaims(token).get("role");
            return r != null ? r.toString().toLowerCase() : "user";
        } catch (Exception e) {
            return "user";
        }
    }

    public boolean validateToken(String token) {
        try { return !getClaims(token).getExpiration().before(new Date()); }
        catch (Exception e) { return false; }
    }
}